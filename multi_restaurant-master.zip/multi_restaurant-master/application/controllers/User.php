<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class User extends Iglobe_Controller {

	public function __construct() {
			parent::__construct();
			// Load form helper library 
			$this->load->helper('form');
			// Load form validation library
			$this->load->library('form_validation');
			$this->load->model('User_model');
	}

	function __destruct() {
		parent::__destruct();

  }

	public function list() {
		$this->is_admin();
		$list=$this->User_model->getUserList();
		$data['data']=$list;
		$this->smarty->display( 'user/list.tpl',$data);
		
	}


	public function Details() {
		$this->is_admin();
		$request=$this->input->post();
		if($request['id']>0)
		{
			$user_data=$this->User_model->Details($request['id']);
		}

		$user_type=$this->User_model->user_type();


		$data['data']=$user_data;
		$data['user_type']=$user_type;
		//echo "<pre>";print_r($data);exit;
		$this->smarty->display( 'user/details.tpl',$data);
	}


	public function update()
	{
		$this->is_admin();	
			$request=$this->input->post();
			$user_id=$request['id'];
			unset($request['ajax']);
			unset($request['id']);
			if($user_id==1)
			{
				unset($request['type']);
				unset($request['status']);

			}

			

			if(!$request['password'])
			{
				unset($request['password']);
			}
			else {
				$request['password']=md5($request['password']);
			}

			if($user_id>0)
			{
				$this->form_validation->set_rules('first_name', 'First Name', 'required');
				$this->form_validation->set_rules('email', 'Email', 'valid_email');
				unset($request['phone']);
				if ($this->form_validation->run() == FALSE)
		        {
		            $this->JsonOut(array('message'=>validation_errors()),500); 
		        }
				$is_update=$this->User_model->update($request,$user_id);
			}
			else {
				$this->form_validation->set_rules('first_name', 'First Name', 'required');
				$this->form_validation->set_rules('email', 'Email', 'valid_email|is_unique[users.email]');
				$this->form_validation->set_rules('phone', 'Phone Numer', 'required|integer|min_length[9]|max_length[13]|is_unique[users.phone]');
				if ($this->form_validation->run() == FALSE)
		        {
		            $this->JsonOut(array('message'=>validation_errors()),500); 
		        }
					$insert_id=$this->User_model->insert($request);

			}

			if($insert_id)
			{
				$this->JsonOut(array('message'=>'updated','insert_id'=>$insert_id));
			}
			else {
				$this->JsonOut(array('message'=>'success'));
			}
		

	}


	public function sudo($user_id)
  {
    $this->is_admin();
    $user_details = $this->User_model->Details($user_id);
    if (is_array($user_details))
    {
            $sess_array = array('username' => '');
            $this->session->unset_userdata('logged_in', $sess_array);
            $session_data = $user_details;
            $this->session->set_userdata('logged_in', $session_data);
            echo "<script>window.location.href='".$this->config->item('base_url')."';</script>";
            header("location: ".$this->config->item('base_url'));
            exit;

      }
    
    
  }



}
