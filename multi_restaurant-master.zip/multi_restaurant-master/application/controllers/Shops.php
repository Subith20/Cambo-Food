<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Shops extends Iglobe_Controller {

	public function __construct() {
			parent::__construct();
			// Load form helper library
			$this->load->helper('form');
			// Load form validation library
			$this->load->library('form_validation');
			$this->load->model('Generic_model');
			$this->load->model('Shops_model');
			$this->load->model('User_model');
			$this->load->model('Products_model');
			$this->load->model('Time_sheet_model');

	}

	function __destruct() {
		parent::__destruct();

  }

  	public function index() {

		$this->list();
	}
	public function list() {
		$data['user_type']=$this->getUser('type');
		$this->smarty->display( 'shops/list.tpl',$data);
	}
	public function list_datatable() {

		if($this->getUser('type')==1)
		{
			$list=$this->Shops_model->GetShopsDatatable();
		}
		else {
			$list=$this->Shops_model->myShopList($this->getUser('id'));
		}

		
		$result=[];
		$bash_url=$this->config->item('base_url');
		if($this->getUser('type')==1)
		{
			foreach ($list as $value) {
		         $data_file_data=$this->Generic_model->UploadFilesList('shop',$value['id']);
		         $img_list='';
		         $data_file_data=reset($data_file_data);
		         if($data_file_data['file_name'])
		         {
		          $img_list=$data_file_data['file_name'];
		         }
				$result[]=array(
					$value['id'],
					'<img class="list_img" src="'.$img_list.'">',
					$value['name'].'<div class="shop_type">'.$value['type_name'].'</div>',
					$value['phone'].($value['mobile']?', '.$value['mobile']:''),
					$value['commission'].' %',
					$value['discount_percentage'].' %',
					'<div class="row-action-btn">
							<div class="custom-control custom-switch custom-switch-on-success ">
	                            <input type="checkbox" class="custom-control-input shop_switch" shop-id="'.$value['id'].'" id="shop_switch_'.$value['id'].'" '.($value['is_available']==1?'checked':'').'>
	                            <label class="custom-control-label" for="shop_switch_'.$value['id'].'"></label>
	                        </div>
	                        <button type="button" class="btn btn-info row-edit-btn" id="product_row_'.$value['id'].'" data-id="'.$value['id'].'"><i class="fas fa-edit"></i></button>
	                        <button type="button" class="btn btn-danger" onclick="'."CallDeleteModal('calldelete(".$value['id'].")');".'"><i class="fas fa-trash-alt"></i></button><div><button class="goto-product btn btn-primary" onclick="shop_products('.$value['id'].');">Products</button>
	                        <button class="goto-orders btn btn-warning" onclick="shop_orders('.$value['id'].');">Orders</button></div>
	                </div>'
					
				);
			}
		}
		else {
			foreach ($list as $value) {
	         $data_file_data=$this->Generic_model->UploadFilesList('shop',$value['id']);
	         $img_list='';
	         $data_file_data=reset($data_file_data);
	         if($data_file_data['file_name'])
	         {
	          $img_list=$data_file_data['file_name'];
	         }
			$result[]=array(
				$value['id'],
				'<img class="list_img" src="'.$img_list.'">',
				$value['name'].'<div class="shop_type">'.$value['type_name'].'</div>',
				$value['phone'].($value['mobile']?', '.$value['mobile']:''),
				$value['discount_percentage'].' %',
				'<div class="row-action-btn">
						<div class="custom-control custom-switch custom-switch-on-success ">
                            <input type="checkbox" class="custom-control-input shop_switch" shop-id="'.$value['id'].'" id="shop_switch_'.$value['id'].'" '.($value['is_available']==1?'checked':'').'>
                            <label class="custom-control-label" for="shop_switch_'.$value['id'].'"></label>
                        </div>
                        <div><button class="goto-product btn btn-primary" onclick="shop_products('.$value['id'].');">Products</button>
                        <button class="goto-orders btn btn-warning" onclick="shop_orders('.$value['id'].');">Orders</button></div>
                </div>'
				
			);
		}
		}
		
		$this->JsonOut($result);
	}

	

	public function update()
	{
		if($this->getUser('type')>1)
		{
			$this->JsonOut(array('message'=>'Not allowed'),500);
		}
		$request=$this->input->post();
		$id=$request['id'];
		$drivers=explode(',', $request['drives']);
		unset($request['ajax']);
		unset($request['id']);
		unset($request['product_img']);
		unset($request['drives']);

		//echo "<pre>";print_r($request);exit;
		$this->form_validation->set_rules('name', 'Shop Name', 'required');
		$this->form_validation->set_rules('type', 'Shop Type', 'required');
		$this->form_validation->set_rules('latitude', 'Latitude', 'required');
		$this->form_validation->set_rules('longitude', 'Longitude', 'required');
		$this->form_validation->set_rules('address', 'Address', 'required');
		$this->form_validation->set_rules('phone', 'Phone', 'required');
		$this->form_validation->set_rules('user_id', 'Manager', 'required|integer');

		
		if ($this->form_validation->run() == FALSE)
        {
            $this->JsonOut(array('message'=>validation_errors()),500); 
        }
        $GetShopsTypeDetails=$this->Shops_model->GetShopsTypeDetails($request['type']);
        //echo "<pre>";print_r($GetShopsTypeDetails);exit;
        $request['type_name']=$GetShopsTypeDetails['type_name'];
        $request['type_group_id']=$GetShopsTypeDetails['type_group_id'];
        $request['type_group_name']=$GetShopsTypeDetails['type_group_name'];

		if($id>0)
		{
			$is_update=$this->Shops_model->update($request,$id);
		}
		else {
			$insert_id=$this->Shops_model->new($request);
		}

		$data_id=$id>0?$id:$insert_id;
		if($data_id>0)
		{

			if($_FILES['product_img']['name'])
			{
				if($id>0)
				{
					$this->RemoveUploadFiles('all','shop',$id);
				}

				$file_data['check_file_type']="image"; // image, PDF, Document
				$file_data['model_type']="shop";// user, asset, lead, product, service
				$file_data['related_id']=$data_id;
				$file_data['input_name']="product_img"; // $_FILE name
				$file_data['display_name']=preg_replace("/[^a-zA-Z]+/", "_", $request['name']);
				$upload_result['product_img']=$this->fileUploader($file_data);
			}

			if($drivers[0])
			{
				foreach ($drivers as $driver_id) {
					if($driver_id>0)
					{
						$shop_drivers[]=array('shop_id'=>$data_id,'user_id'=>$driver_id);
					}
					
				}

				if($shop_drivers)
				{
					$this->Shops_model->removeShopDrivers($data_id);
					$this->Shops_model->insert_shop_driver($shop_drivers);
				}
			}
			else {
				$this->Shops_model->removeShopDrivers($data_id);
			}
		}

		if($insert_id)
		{
			$this->JsonOut(array('message'=>'Added','insert_id'=>$insert_id));
		}
		else {
			$this->JsonOut(array('message'=>'Updated'));
		}

	}

	public function updateAllShoptypes()
	{
		if($this->getUser('type')>1)
		{
			$this->JsonOut(array('message'=>'Not allowed'),500);
		}
		$shops_list=$this->Shops_model->GetShopsList();
		foreach ($shops_list as $value) {
			$GetShopsTypeDetails=$this->Shops_model->GetShopsTypeDetails($value['type']);
	        $request['type_name']=$GetShopsTypeDetails['type_name'];
    	    $request['type_group_id']=$GetShopsTypeDetails['type_group_id'];
        	$request['type_group_name']=$GetShopsTypeDetails['type_group_name'];
			$this->Shops_model->update($request,$value['id']);
		}

		$this->JsonOut(array('message'=>'success'));

	}

	public function StatusUpdate()
	{

		$request=$this->input->post();
		//echo "<pre>";print_r($request);exit;
		$id=$request['id'];
		unset($request['ajax']);
		unset($request['id']);
		
		$checkOwnerPermission=$this->Shops_model->checkOwnerPermission($this->getUser('id'),$id);
		if($this->getUser('type')>1 and ($id==null or !$checkOwnerPermission))
		{
			$this->JsonOut(array('message'=>'Check Permission'),500); 
			//echo '<div style="font-size: 29px;text-align: center;margin-top: 100px;color: #c1c1c1;">Page Not Found!<br><i class="fas fa-info-circle" style="font-size:48px;color:#ddd"></i></div>';exit;
		}

		if($id>0)
		{

			
			$is_update=$this->Shops_model->update($request,$id);
		}

		if($is_update)
		{
			$this->JsonOut(array('message'=>'Updated'));
		}
		else {
			$this->JsonOut(array('message'=>'Server error'),500); 
		}

	}



	public function RemoveImage()
	{
		if($this->getUser('type')>1)
		{
			$this->JsonOut(array('message'=>'Not allowed'),500);
		}
		$request=$this->input->post();
		if(!$request['shop_id'] || !$request['id'])
		{
			$this->JsonOut(array('message'=>'invalid input'),500);
		}
		else {

			$this->RemoveUploadFiles($request['id'],'shop',$request['shop_id']);
			$this->JsonOut(array('message'=>'success'));
		}
	}

	public function delete() {
		if($this->getUser('type')>1)
		{
			$this->JsonOut(array('message'=>'Not allowed'),500);
		}

			$request=$this->input->post();
			$id=$request['id'];
			if($id>0)
			{
				$delete_data['is_deleted']=1;

				$is_update=$this->Shops_model->update($delete_data,$id);
				$this->RemoveUploadFiles('all','shop',$id);
				//$this->RemoveUploadFiles('all','products',$request['id']);
			}
			 $this->JsonOut(array('message'=>'success'));
	}

	public function details($id=0) {
		$this->is_admin();
		//$request=$this->input->post();

		$manager_id=0;
		if($id>0)
		{
			$row_data=$this->Shops_model->GetDetails($id);
			$shop_drivers_tbp=$this->Shops_model->ShopDriverList($id);
			foreach ($shop_drivers_tbp as $value) {
				$shop_drivers[]=$value['user_id'];
			}
			$manager_id=$row_data['user_id'];

		}

		$row_data['type']=explode(',', $row_data['type']);

		$data['time_list']=$this->Time_sheet_model->GetShopTimeSelectionList($manager_id);
		$data['data']=$row_data;
		$data['user_list']=$this->User_model->getManager();
		$driver=$this->User_model->getAllDrivers();
		
		foreach ($driver as $key=>$value) {
			if(in_array($value['id'],$shop_drivers))
			{
				$driver[$key]['selected']=1;
			}
		}
		
		$data['driver_list']=$driver;
		if($id>0)
		{
			$data_file_data=$this->Generic_model->UploadFilesList('shop',$id);
	        $img_list='';
	        $data_file_data=reset($data_file_data);
	        if($data_file_data['file_name'])
	        {
	          $data['images']=$data_file_data;
	        }
		}
		$data['type']=$this->Shops_model->GetShopsTypeList();
		//echo "<pre>";print_r($data);exit;
		$this->smarty->display('shops/details.tpl',$data);
	}


}
