<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

// Load the Rest Controller library


class UserAuth extends MY_Controller {

    public function __construct() {
        parent::__construct();
        // Load the user model
        $this->load->model('User_model');

    }

    
    public function logout_get()
    {

      $user_id=$this->_apiuser->user_id;
      $key=$this->_apiuser->key;
      $result=$this->User_model->deleteKey($user_id,$key);
      if ($result) 
      {
        $this->response([true,'Logout',array()], REST_Controller::HTTP_OK);
      }
      else {
        $this->response([false,'Server error',array('request'=>$this->httpRequest)], REST_Controller::HTTP_OK);
      }
    }

    
    private function _insert_key($key, $data)
    {
        $data['key'] = $key;
        $result = $this->User_model->insert_token($data);
        return $result;
    }
    private function _generate_key()
  	{

  		do {
  			// Generate a random salt
  			$salt = base_convert(bin2hex($this->security->get_random_bytes(64)), 16, 36);

  			// If an error occurred, then fall back to the previous method
  			if ($salt === FALSE) {
  				$salt = hash('sha256', time() . mt_rand());
  			}

  			$new_key = substr($salt, 0, config_item('rest_key_length'));
  		} while ($this->_key_exists($new_key));

  		return $new_key;
  	}

    private function _key_exists($key)
  	{
  		return $this->rest->db
  			->where(config_item('rest_key_column'), $key)
  			->count_all_results(config_item('rest_keys_table')) > 0;
  	}



    public function auth_post()
		{
      $phone=$this->httpRequest->phone;
      $pass=$this->httpRequest->password;
      $device_token=$this->httpRequest->device_token;
      $device_details=$this->httpRequest->device_details;
			if($phone!=null && $pass!=null)
			{
        $userData=$this->User_model->login($phone,md5($pass));
        if ($userData['id']>0 && $userData['type']==4)
        {
 					$key = $this->_generate_key();
          $apiKey_data = array(
                  'user_id' => $userData['id'],
                  'level' => 1,
                  'ignore_limits' => 1,
                  'ip_addresses' => $this->input->ip_address(),
                  'device_token'=>$this->httpRequest->device_token,
                  'geolocation'=>$this->httpRequest->geolocation,
                  'user_type'=>5,
                  'device_details'=>$device_details
              );

             //print_r($apiKey_data);exit;

              $insert_token = $this->_insert_key($key, $apiKey_data);
              if ($insert_token) {
                  $userData['api_key'] = $key;

                  $this->response([true,'success',$userData], REST_Controller::HTTP_OK);
              }
              else {
                  $this->response([false,'Server error',array('request'=>$this->httpRequest)], REST_Controller::HTTP_OK);
              }
          }
          else {
              $this->response([false,'Invalid Phone / password',array('request'=>$this->httpRequest)], REST_Controller::HTTP_OK);
          }
		}
		else {
      $this->response([false,'Invalid input',array()], REST_Controller::HTTP_OK);
		}

	}

}
