<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');


class User extends MY_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('User_model');
		$this->load->model('Generic_model');
		$this->load->model('Settings_model');
	}


	public function details_get()
    {
      $user_id=$this->_apiuser->user_id;
      $result=$this->User_model->Details($user_id);
      if ($result) 
      {
        $this->response([true,'Success',$result], REST_Controller::HTTP_OK);
      }
      else {
        $this->response([false,'Server error',array('request'=>$this->httpRequest)], REST_Controller::HTTP_OK);
      }
    }
   

	public function update_status_post() {
		$status=$this->httpRequest->status;
		$id=$this->_apiuser->user_id;
		$result=$this->User_model->update(array('status'=>$status),$id);
		if($result!=false)
		{	
		    $this->response([TRUE,'success',array()], REST_Controller::HTTP_OK);
        }
		else
		{
		    $this->response([false,'No Data',array()], REST_Controller::HTTP_OK);
		}

	}

	public function settings_get() {
		$result=$this->userApiSettings();
		$this->response([TRUE,'success',$result], REST_Controller::HTTP_OK);
	}


}
