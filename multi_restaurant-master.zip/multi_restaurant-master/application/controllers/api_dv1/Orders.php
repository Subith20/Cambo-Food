<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

// Load the Rest Controller library


class Orders extends MY_Controller {

    public function __construct() {
        parent::__construct();

        // Load the user model
        $this->load->model('Orders_model');
        $this->load->model('products_model');
        $this->load->model('Customer_model');
        $this->load->model('User_model');
        // Load form validation library

    }


    public function GetOrdertList_get() {
      $user_id=$this->_apiuser->user_id;
      $order_list=$this->Orders_model->GetDriverOrdertList(array('driver_id'=>$user_id));
      if($order_list!=false)
      {
          $this->response([TRUE,'success',$order_list], REST_Controller::HTTP_OK);
      }
      else {
          $this->response([TRUE,'No Data',array()], REST_Controller::HTTP_OK);
      }
    }

    public function GetActiveOrdert_get() {
      $user_id=$this->_apiuser->user_id;
      $order_list=$this->Orders_model->GetDriverOrdertList(array('driver_id'=>$user_id,'status'=>'1,2,3'));
      if($order_list!=false)
      {
          $this->response([TRUE,'success',$order_list], REST_Controller::HTTP_OK);
      }
      else {
          $this->response([TRUE,'No Data',array()], REST_Controller::HTTP_OK);
      }
    } 


   

    public function StatusUpdate_post() {
      $request=$this->httpRequest;
      $driver_id=$this->_apiuser->user_id;
      $order_id=$request->id;
      $payment_mode=$request->payment_mode;
      $status=$request->status;

      if($order_id>0 && ($status==3 || $status==4))
      {
        if($status==4 && $payment_mode)
        {
          $result=$this->Orders_model->DriverStatusUpdate($driver_id,$order_id,$status,$payment_mode);
        }
        else {
          $result=$this->Orders_model->DriverStatusUpdate($driver_id,$order_id,$status);
        }
      }
      else {
          $this->response([FALSE,'Invalid input',array()], REST_Controller::HTTP_OK);
      }
      


      if($result)
      {
        
        $this->response([TRUE,'success',array()], REST_Controller::HTTP_OK);
      }
      else {
          $this->response([FALSE,'No Data',array()], REST_Controller::HTTP_OK);
      }
    }

  public function reached_shop_post()
  {
    $status=$this->httpRequest->status;
    $id=$this->httpRequest->id;
    $driver_id=$this->_apiuser->user_id;
    $status=$status==1?1:0;
    $result=$this->Orders_model->driverReachedUpdate($id,$driver_id,$status);
    if($result!=false)
    { 
        $this->response([TRUE,'success',array()], REST_Controller::HTTP_OK);
    }
    else
    {
        $this->response([false,'Invalid request',array()], REST_Controller::HTTP_OK);
    }
  }

}
