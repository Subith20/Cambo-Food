<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Products extends Iglobe_Controller {

	public function __construct() {
			parent::__construct();
			// Load form helper library
			$this->load->helper('form');
			// Load form validation library
			$this->load->library('form_validation');
			$this->load->model('Generic_model');
			$this->load->model('Products_model');
			$this->load->model('Shops_model');
			$this->load->model('Time_sheet_model');

	}

	function __destruct() {
		parent::__destruct();

  }

  	public function index() {

		$this->list();
	}
	public function list($shop_id=null) {

		//$checkOwnerPermission=$this->Shops_model->checkOwnerPermission($this->getUser('id'),$shop_id);

		if($this->getUser('type')>3 and $this->getUser('type')!=5)
		{
			echo '<div style="font-size: 29px;text-align: center;margin-top: 100px;color: #c1c1c1;">Page Not Found!<br><i class="fas fa-info-circle" style="font-size:48px;color:#ddd"></i></div>';exit;
		}

		if($this->getUser('type')==5)
		{
			$this->manager_list($shop_id);exit;
		}

		$data['shop_id']=$shop_id;
		$this->smarty->display( 'products/list.tpl',$data);
	}

	public function manager_list($shop_id=0)
	{
		$user_id=$this->getUser('id');
		if($this->getUser('type')==5 and $shop_id>0)
		{
			$checkOwnerPermission=$this->Shops_model->checkOwnerPermission($user_id,$shop_id);
			if($checkOwnerPermission)
			{
				$data['shop_details']=$this->Shops_model->GetDetails($shop_id);
				$data['product_cat']=$this->Products_model->ManagerProductCatList(array('user_id'=>$user_id,'shop_id'=>$shop_id));
				
			}
			else {
				echo '<div style="font-size: 29px;text-align: center;margin-top: 100px;color: #c1c1c1;">1Page Not Found!<br><i class="fas fa-info-circle" style="font-size:48px;color:#ddd"></i></div>';exit;
			}
			
		}
		else {
			echo '<div style="font-size: 29px;text-align: center;margin-top: 100px;color: #c1c1c1;">2Page Not Found!<br><i class="fas fa-info-circle" style="font-size:48px;color:#ddd"></i></div>';exit;
		}

		$data['shop_id']=$shop_id;
		$data['active_product_cat']=$data['product_cat'][0];
		unset($data['product_cat'][0]);
		//echo "<pre>";print_r($data['shop_details']);exit;
		$this->smarty->display( 'products/manager_list.tpl',$data);
	}

	public function list_datatable() {
		$request=$this->input->get();
		$shop_id=$request['shop_id']?$request['shop_id']:0;
		if($this->getUser('type')>1 and $shop_id==0)
		{
			$this->JsonOut(array());
		}
		$list=$this->Products_model->GetProductListDatatable($shop_id);
		$result=[];
		$bash_url=$this->config->item('base_url');
		foreach ($list as $value) {
			if(strlen($value['name'])>40)
	         {

	           $value['name']=substr($value['name'],0,38);
	           $value['name']=$value['name']."..";
	         }
	         /*$data_file_data=$this->Generic_model->UploadFilesList('products',$value['id']);
	         $img_list='';
	         $data_file_data=reset($data_file_data);
	         if($data_file_data['file_name'])
	         {
	          $img_list=$data_file_data['file_name'];
	         }*/

			$result[]=array(
				$value['id'],
				'<img class="list_img" src="'.$value['img'].'">',
				'<i class="fas fa-'.($value['type']==2?'drumstick-bite':($value['type']==3?'egg':'leaf')).'"></i> '.$value['name'].' ['.$value['type_name'].']',
				$value['shop_name'],
				$value['quantity'].($value['unit']?' '.$value['unit']:''),
				$value['cat_name'],
				number_format((float)$value['sale_price'], 2, '.', '').' / '.number_format((float)$value['mrp'], 2, '.', ''),
				'<div class="row-action-btn">
						<div class="custom-control custom-switch custom-switch-on-success ">
                            <input type="checkbox" class="custom-control-input product_switch" product-id="'.$value['id'].'" id="product_switch_'.$value['id'].'" '.($value['is_avail']==1?'checked':'').'>
                            <label class="custom-control-label" for="product_switch_'.$value['id'].'"></label>
                        </div>
                        <button type="button" class="btn btn-info row-edit-btn" id="product_row_'.$value['id'].'" data-id="'.$value['id'].'"><i class="fas fa-edit"></i></button>
                        <button type="button" class="btn btn-danger" onclick="'."CallDeleteModal('calldelete(".$value['id'].")');".'"><i class="fas fa-trash-alt"></i></button>
                </div>'
				
			);
		}
		$this->JsonOut($result);
	}



	public function manager_list_datatable() {
		$request=$this->input->get();
		$shop_id=$request['shop_id'];
		$cat_id=$request['cat_id'];
		$checkOwnerPermission=$this->Shops_model->checkOwnerPermission($this->getUser('id'),$shop_id);
		if($this->getUser('type')!=5 or $shop_id==0 or !$checkOwnerPermission or $cat_id==0)
		{
			$this->JsonOut(array());
		}

		$list=$this->Products_model->MangerProductListDatatable($shop_id,$cat_id);
		
		$this->JsonOut($list);
	}

	public function catlist() {


		

		//echo "<pre>";print_r($data);exit;
		$this->smarty->display( 'products/catlist.tpl',$data);
	}

	public function extras_details($id)
	{
		if($id>0)
		{
			$details=$this->Products_model->extras_details($id);
			$data['data']=$details;
		}
		
		//echo "<pre>";print_r($data);exit;
		$this->smarty->display( 'products/extras_details.tpl',$data);
	}

	public function extras_group_details($id)
	{
		if($id>0)
		{
			$details=$this->Products_model->extras_group_details($id);
			$data['data']=$details;
		}
		$data['extras_group_type']=$this->config->item('extras_group_type');
		//echo "<pre>";print_r($data);exit;
		$this->smarty->display( 'products/extras_group_details.tpl',$data);
	}

	public function catlist_datatable() {

		if($this->getUser('type')>1)
		{
			$list=$this->Products_model->listViewProductCat(array('owner_id'=>$this->getUser('id')));
		}
		else {
			$list=$this->Products_model->listViewProductCat();
		}
		
		$data['data']=$list;
		$result=[];
		$bash_url=$this->config->item('base_url');
		foreach ($list as $value) {

			if(strlen($value['name'])>40)
	         {

	           $value['name']=substr($value['name'],0,38);
	           $value['name']=$value['name']."..";
	         }
	         $data_file_data=$this->Generic_model->UploadFilesList('product_cat',$value['id']);
	         $img_list='';
	         $data_file_data=reset($data_file_data);
	         if($data_file_data['file_name'])
	         {
	          $img_list=$data_file_data['file_name'];
	         }

			$result[]=array(
				$value['id'],
				'<img class="list_img" src="'.$img_list.'">',
				$value['name'],
				'<span class="master-name-span '. ($value['master_id']==0?'is-master">Master Menu':'">'.$value['master_name']). '</span>',
				$value['status']==1?'Active':'Inactive',
				$value['product_count'],
				$value['is_home']==1?'Active':'Inactive',
				'<div class="row-action-btn">
						<div class="custom-control custom-switch custom-switch-on-success ">
                            <input type="checkbox" class="custom-control-input status_switch" row-id="'.$value['id'].'" id="product_switch_'.$value['id'].'" '.($value['status']==1?'checked':'').'>
                            <label class="custom-control-label" for="product_switch_'.$value['id'].'"></label>
                        </div>
                        <button type="button" class="btn btn-info row-edit-btn" id="product_row_'.$value['id'].'" data-id="'.$value['id'].'"><i class="fas fa-edit"></i></button>
                        <button type="button" class="btn btn-danger" onclick="'."CallDeleteModal('calldelete(".$value['id'].")');".'"><i class="fas fa-trash-alt"></i></button>
                </div>'
				
			);
		}
		$this->JsonOut($result);
	}

	public function specialProducts() {
		$this->is_admin();

		//$data['products']=$this->Products_model->SpecialList('all');

		//echo "<pre>";print_r($data);exit;
		$this->smarty->display( 'products/special_products.tpl');
	}

	public function specialProductsDetails($id=0) {
		$this->is_admin();

		if($id>0)
		{
			$data['details']=$this->Products_model->SpeciaDetails($id);
		}
		$data['spl_cat_list']=$this->Products_model->SpecialCatList('all');
		$data['product_list']=$this->Products_model->GetActiveProductList();

		//echo "<pre>";print_r($data);exit;
		$this->smarty->display( 'products/special_product_details.tpl',$data);
	}

	public function specialProducts_datatable() {
		$this->is_admin();

		$list=$this->Products_model->SpecialList();
		$result=[];
		$bash_url=$this->config->item('base_url');
		foreach ($list as $value) {

			if(strlen($value['name'])>40)
	         {

	           $value['name']=substr($value['name'],0,38);
	           $value['name']=$value['name']."..";
	         }
	         $data_file_data=$this->Generic_model->UploadFilesList('products',$value['product_id']);
	         $img_list='';
	         $data_file_data=reset($data_file_data);
	         if($data_file_data['file_name'])
	         {
	          $img_list=$data_file_data['file_name'];
	         }

			$result[]=array(
				$value['id'],
				'<img class="list_img" src="'.$img_list.'">',
				'<i class="fas fa-'.($value['type']==2?'drumstick-bite':($value['type']==1?'egg':'leaf')).'"></i> '.$value['name'].' ['.($value['type']==3?'Non Veg':($value['type']==2?'Egg':'Veg')).']',
				$value['special_cat_name'],
				//$value['special_cat_status']==1?'Active':'Inactive',
				$value['from']!='0000-00-00 00:00:00'?$value['from']:'-',
				$value['to']!='0000-00-00 00:00:00'?$value['to']:'-',
				'<div class="row-action-btn">
                        <button type="button" class="btn btn-info row-edit-btn" id="product_row_'.$value['id'].'" data-id="'.$value['id'].'"><i class="fas fa-edit"></i></button>
                        <button type="button" class="btn btn-danger" onclick="'."CallDeleteModal('calldelete(".$value['id'].")');".'"><i class="fas fa-trash-alt"></i></button>
                </div>'
				
			);
		}
		$this->JsonOut($result);
	}

	public function update()
	{
		$request=$this->input->post();
		$id=$request['id'];

		unset($request['ajax']);
		unset($request['id']);
		unset($request['product_img']);
		//echo "<pre>";
		//print_r($request);exit;
		$this->form_validation->set_rules('name', 'Name', 'required');
		$this->form_validation->set_rules('shop_id', 'shop', 'required|integer');
		$this->form_validation->set_rules('category_id', 'Category', 'required|integer');
		$this->form_validation->set_rules('mrp', 'MRP', 'required|numeric');
		$this->form_validation->set_rules('sale_price', 'Sale Price', 'numeric');
		$this->form_validation->set_rules('tax', 'Tax', 'numeric');
		if ($this->form_validation->run() == FALSE)
        {
            $this->JsonOut(array('message'=>validation_errors()),500); 
        }

		if($id>0)
		{
			$checkPermission=$this->Products_model->checkPermission($this->getUser('id'),$id);
			if($this->getUser('type')==1 or $checkPermission)
			{
				$is_update=$this->Products_model->update($request,$id);
			}
			else
			{
				$this->JsonOut(array('message'=>'Check Permission'),500); 
			}
			
		}
		else {
			$checkOwnerPermission=$this->Shops_model->checkOwnerPermission($this->getUser('id'),$request['shop_id']);
			if($this->getUser('type')==1 or $checkOwnerPermission)
			{
				$insert_id=$this->Products_model->new($request);
			}
			else
			{
				$this->JsonOut(array('message'=>'Check Permission'),500); 
			}

			
		}

		$data_id=$id>0?$id:$insert_id;
		if($data_id>0)
		{
			if($_FILES['product_img']['name'])
			{
				if($id>0)
				{
					$this->RemoveUploadFiles('all','products',$id);
				}
				
				$file_data['check_file_type']="image"; // image, PDF, Document
				$file_data['model_type']="products";// user, asset, lead, product, service
				$file_data['related_id']=$data_id;
				$file_data['input_name']="product_img"; // $_FILE name
				$file_data['display_name']=preg_replace("/[^a-zA-Z]+/", "_", $request['name']);
				$upload_result['product_img']=$this->fileUploader($file_data);
			}
		}

		if($insert_id)
		{
			$this->JsonOut(array('message'=>'Added','insert_id'=>$insert_id));
		}
		else {
			$this->JsonOut(array('message'=>'Updated'));
		}

	}

	public function productStatusUpdate()
	{
		$request=$this->input->post();
		$id=$request['id'];
		unset($request['ajax']);
		unset($request['id']);
		

		if($id>0)
		{
			$checkPermission=$this->Products_model->checkPermission($this->getUser('id'),$id);
			if($this->getUser('type')==1 or $checkPermission)
			{
				$is_update=$this->Products_model->update(array('is_avail'=>$request['is_avail']),$id);
			}
			else
			{
				$this->JsonOut(array('message'=>'Check Permission'),500); 
			}

			
		}

		if($is_update)
		{
			$this->JsonOut(array('message'=>'Updated'));
		}
		else {
			$this->JsonOut(array('message'=>'Server error'),500); 
		}

	}

	public function catStatusUpdate()
	{
		$request=$this->input->post();
		$id=$request['id'];
		unset($request['ajax']);
		unset($request['id']);
		
		$checkCatPermission=$this->Products_model->checkCatPermission($this->getUser('id'),$id);

		if($id>0 and ($checkCatPermission or $this->getUser('type')==1))
		{
			
			$is_update=$this->Products_model->updateCat(array('status'=>$request['status']),$id);
		}

		if($is_update)
		{
			$this->JsonOut(array('message'=>'Updated'));
		}
		else {
			$this->JsonOut(array('message'=>'Server error'),500); 
		}

	}

	public function special_product_update()
	{
		$request=$this->input->post();
		$id=$request['id'];
		unset($request['ajax']);
		unset($request['id']);
		//echo "<pre>";
		//print_r($request);exit;
		$this->form_validation->set_rules('from', 'From Date', 'required');
		$this->form_validation->set_rules('to', 'End Date', 'required');
		if ($this->form_validation->run() == FALSE)
        {
            $this->JsonOut(array('message'=>validation_errors()),500); 
        }

		if($id>0)
		{
			$is_update=$this->Products_model->special_product_update($request,$id);
		}
		else {
			$insert_id=$this->Products_model->special_product_new($request);
		}

		$data_id=$id>0?$id:$insert_id;


		if($insert_id)
		{
			$this->JsonOut(array('message'=>'Added','insert_id'=>$insert_id));
		}
		else {
			$this->JsonOut(array('message'=>'Updated'));
		}

	}

	public function saveExtras()
	{
		$request=$this->input->post();
		unset($request['ajax']);
		$id=$request['id'];
		unset($request['id']);
		$this->form_validation->set_rules('name', 'Name', 'required');
		$this->form_validation->set_rules('product_id', 'Product Details', 'required');
		$this->form_validation->set_rules('mrp', 'MRP', 'required');
		$this->form_validation->set_rules('price', 'Price', 'required');
		$this->form_validation->set_rules('group_id', 'Group Details', 'is_natural_no_zero|required');
		if ($this->form_validation->run() == FALSE)
        {
            $this->JsonOut(array('message'=>validation_errors()),500); 
        }

        //echo "<pre>";print_r($request);exit;
        if($id>0)
        {
        	$insert_id=$this->Products_model->extras_update($request,$id);
        }
        else {
        	$insert_id=$this->Products_model->extras_new($request);
        }
		

		if($insert_id)
		{
			$this->JsonOut(array('message'=>'Added','insert_id'=>$insert_id));
		}
		else {
			$this->JsonOut(array('message'=>'Server Error'),500);
		}

	}

	public function saveExtrasGroup()
	{
		$request=$this->input->post();
		unset($request['ajax']);
		$id=$request['id'];
		unset($request['id']);
		$this->form_validation->set_rules('name', 'Name', 'required');
		$this->form_validation->set_rules('maximum_order', 'Maximum Selection', 'is_natural_no_zero|required');
		if ($this->form_validation->run() == FALSE)
        {
            $this->JsonOut(array('message'=>validation_errors()),500); 
        }

        //echo "<pre>";print_r($request);exit;
        if($id>0)
        {
        	$insert_id=$this->Products_model->extras_group_update($request,$id);
        }
        else {
        	$insert_id=$this->Products_model->extras_group_new($request);
        }
		

		if($insert_id)
		{
			$this->JsonOut(array('message'=>'Added','insert_id'=>$insert_id));
		}
		else {
			$this->JsonOut(array('message'=>'Server Error'),500);
		}

	}

	public function extrasStatusUpdate()
	{
		$request=$this->input->post();
		unset($request['ajax']);
		$id=$request['id'];
		unset($request['id']);

		$this->form_validation->set_rules('id', 'Extras', 'required');
		$this->form_validation->set_rules('status', 'Status', 'required');
		if ($this->form_validation->run() == FALSE)
        {
            $this->JsonOut(array('message'=>validation_errors()),500); 
        }

        if($id>0)
        {
        	$details=$this->Products_model->extras_details($id);

        	if($details['is_stackable']==2 && $request['status']==0)
        	{
        		
        		$request['is_stackable']=0;
        		$request['stock_count']=0;
        	}
        }
		$result=$this->Products_model->extras_update($request,$id);

		if($result)
		{
			$this->JsonOut(array('message'=>'Updated'));
		}
		else {
			$this->JsonOut(array('message'=>'Server Error'),500);
		}
	}

	public function extrasDelete()
	{
		$request=$this->input->post();
		if($request['id']>0)
		{
			$result = $this->Products_model->extrasDelete($request['id']);

			if($result)
			{
				$this->JsonOut(array('message'=>'Deleted','insert_id'=>$insert_id));
			}
			else {
				$this->JsonOut(array('message'=>'Server Error'),500);
			}
		}
		$this->JsonOut(array('message'=>'invalid input'),500);
	}

	public function extrasGroupDelete()
	{
		$request=$this->input->post();
		if($request['id']>0)
		{
			$result = $this->Products_model->extras_group_delete($request['id']);

			if($result)
			{
				$this->JsonOut(array('message'=>'Deleted','insert_id'=>$insert_id));
			}
			else {
				$this->JsonOut(array('message'=>'Server Error'),500);
			}
		}
		$this->JsonOut(array('message'=>'invalid input'),500);
	}

	public function updateCat()
	{
		$request=$this->input->post();
		$id=$request['id'];
		unset($request['ajax']);
		unset($request['id']);
		unset($request['product_img']);
		$this->form_validation->set_rules('name', 'Name', 'required');

		if($this->getUser('type')>1)
		{

			$request['user_id']=$this->getUser('id');
		}

		if ($this->form_validation->run() == FALSE)
        {
            $this->JsonOut(array('message'=>validation_errors()),500); 
        }
		if($id>0)
		{
			$checkCatPermission=$this->Products_model->checkCatPermission($this->getUser('id'),$id);
			if($checkCatPermission or $this->getUser('type')==1)
			{
				$is_update=$this->Products_model->updateCat($request,$id);
			}
			else {
				$this->JsonOut(array('message'=>'Check Permission'),500);
			}
			
		}
		else {
			$insert_id=$this->Products_model->Product_catInsert($request);
		}

		$data_id=$id>0?$id:$insert_id;
		if($data_id>0)
		{
			if($_FILES['product_img']['name'])
			{
				$file_data['check_file_type']="image"; // image, PDF, Document
				$file_data['model_type']="product_cat";// user, asset, lead, product, service
				$file_data['related_id']=$data_id;
				$file_data['input_name']="product_img"; // $_FILE name
				$file_data['display_name']=preg_replace("/[^a-zA-Z]+/", "_", $request['name']);
				$upload_result['product_img']=$this->fileUploader($file_data);
			}
		}

		if($insert_id)
		{
			$this->JsonOut(array('message'=>'Added','insert_id'=>$insert_id));
		}
		else {
			$this->JsonOut(array('message'=>'Updated'));
		}

	}

	public function RemoveProductImage()
	{
		$request=$this->input->post();
		if(!$request['product_id'] || !$request['id'])
		{
			$this->JsonOut(array('message'=>'invalid input'),500);
		}
		else {

			$this->RemoveUploadFiles($request['id'],'products',$request['product_id']);
			$this->JsonOut(array('message'=>'success'));
		}
	}

	public function RemoveProductCatImage()
	{
		$request=$this->input->post();
		if(!$request['productCat_id'] || !$request['id'])
		{
			$this->JsonOut(array('message'=>'invalid input'),500);
		}
		else {

			$this->RemoveUploadFiles($request['id'],'product_cat',$request['productCat_id']);
			$this->JsonOut(array('message'=>'success'));
		}
	}

	public function delete() {

			$request=$this->input->post();
			if($request['id']>0)
			{

				$result = $this->Products_model->delete($request['id']);
				$this->RemoveUploadFiles('all','products',$request['id']);
			}
			 $this->JsonOut(array('message'=>'success'));
	}

	public function deleteCat() {

			$request=$this->input->post();
			if($request['id']>0)
			{

				$result = $this->Products_model->deleteCat($request['id']);
				$this->RemoveUploadFiles('all','product_cat',$request['id']);
			}

			 $this->JsonOut(array('message'=>'success'));
	}

	public function deleteSpecialProduct($id) {
			if($id>0)
			{

				$result = $this->Products_model->deleteSpecialProduct($id);
			}

			 $this->JsonOut(array('message'=>'success'));
	}

	public function details($id=0) {
		$get=$this->input->get();
		//echo "<pre>";print_r($get);exit;

		if($id>0)
		{
			$row_data=$this->Products_model->GetProductDetails($id);
			$extras=$this->Products_model->GetProductExtras($id);
			$extras_group=$this->Products_model->GetProductExtrasGroup($id);

			if($row_data['shop_id']>0)
			{
				$shop_data=$this->Shops_model->GetDetails($row_data['shop_id']);
				if($shop_data['user_id']>0)
				{
					$data['time_list']=$this->Time_sheet_model->GetShopTimeSelectionList($shop_data['user_id']);
				}
				
			}
			

			$data['extras_group_type']=$this->config->item('extras_group_type');

			foreach ($extras_group as $value) {

				$value['extras']=array();
				foreach ($extras as $extra_key=>$extra_value) {
					if($extra_value['group_id']==$value['id'])
					{
						$value['extras'][$extra_value['id']]=$extra_value;
						unset($extras[$extra_key]);
					}
				}
				$row_data['extras_group'][$value['id']]=$value;
				
			}
		}
		else {
			$row_data['category_id']=$get['cat_id'];
			$row_data['shop_id']=$get['shop_id'];
		}

		//echo "<pre>";print_r($row_data['extras_group']);exit;
		$product_cat_select_list=$this->Products_model->ProductCatSelectList(array('user_id'=>$this->getUser('id')));
		$data['type']=$this->Products_model->GetProduct_type();
		if($this->getUser('type')==5)
		{
			$data['shop_list']=$this->Shops_model->GetShopsSelectList(array('user_id'=>$this->getUser('id')));
		}
		else {
			$data['shop_list']=$this->Shops_model->GetShopsSelectList();
		}
		
		$data['data']=$row_data;
		$data['product_cat_select_list']=$product_cat_select_list;
		$data['unit_list']=$this->Products_model->UnitsList();
		
		if($id>0)
		{
			$data_file_data=$this->Generic_model->UploadFilesList('products',$id);
	        $data_file_data=reset($data_file_data);
	        if($data_file_data['file_name'])
	        {
	          $data['images']=$data_file_data;
	        }
		}
		
		//echo "<pre>";print_r($data['shop_list']);exit;
		$this->smarty->display('products/details.tpl',$data);
	}

	public function catDetails() {
		$request=$this->input->post();

		if($request['id']>0)
		{
			$row_data=$this->Products_model->GetProductCatDetails($request['id']);
		}

		//$product_cat_select_list=$this->Products_model->ProductCatSelectList();


		$data['data']=$row_data;
		//$data['product_cat_select_list']=$product_cat_select_list;
		$data['base_url']=base_url();
		$data['order_by']=[0,1,2,3,4,5,6,7,8,9,10];
		$data['user_type']=$this->getUser('type');
		if($request['id']>0)
		{
			$data_file_data=$this->Generic_model->UploadFilesList('product_cat',$request['id']);
			$data_file_data=reset($data_file_data);
	        if($data_file_data['file_name'])
	        {
	          $data['images']=$data_file_data;
	        }
		}
		
		//echo "<pre>";print_r($data);exit;
		$this->smarty->display('products/catdetails.tpl',$data);
	}

	public function moveProductCat()
	{
		$request=$this->input->post();
		$id=$request['id'];
		$cat_id=$request['cat_id'];

		if($id>0)
		{
			$checkPermission=$this->Products_model->checkPermission($this->getUser('id'),$id);
			if($this->getUser('type')==1 or $checkPermission)
			{
				$is_update=$this->Products_model->update(array('category_id'=>$cat_id),$id);
			}
			else
			{
				$this->JsonOut(array('message'=>'Check Permission'),500); 
			}
			
		}

		if($is_update)
		{
			$this->JsonOut(array('message'=>'Updated'));
		}
		else {
			$this->JsonOut(array('message'=>'Error'),500);
		}

	}


}
