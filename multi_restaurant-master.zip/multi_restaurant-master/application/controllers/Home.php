<?php
defined('BASEPATH') OR exit('No direct script access allowed');

session_start(); //we need to start session in order to access it through CI
class Home extends Iglobe_Controller {

	public function __construct() {
			parent::__construct();
			// Load form helper library
			$this->load->helper('form');
			$this->load->model('Home_model');
			$this->load->model('Orders_model');
			$this->load->model('Customer_model');
			$this->load->model('Products_model');

	}

	function __destruct() {
    parent::__destruct();
  }



	public function P404()
	{
		$this->output->set_status_header('404');
		//$this->load->view('err404');
		echo '<div style="font-size: 29px;text-align: center;margin-top: 100px;color: #c1c1c1;">Page Not Found!<br><i class="fas fa-info-circle" style="font-size:48px;color:#ddd"></i></div>';exit;
	}
	

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function index()
	{
		//$this->is_admin();
		$user=$this->getUser();
		$data['base_url']=base_url();

		$from = new DateTime();
         $to = $from->format('Y-m-d');
		 $from->modify('first day of this month');
		
		if($user['type']==1)
		{
			//$data['app_home_icons']=$this->Home_model->GetHomeIcon();

		$total_customers=$this->Customer_model->getTotalCustomers();
		$data['total_customers']=$total_customers['count'];
		$new_customers=$this->Customer_model->getNewCustomers($from->format('Y-m-d').' 00:00:00', $to.' 23:59:59');
		$data['new_customers']=$new_customers['count'];
		$today_orders=$this->Orders_model->getTodayOrders();
		$today_live_orders=$today_orders[1]['count']+$today_orders[2]['count']+$today_orders[3]['count'];
		$today_delivered_orders=$today_orders[4]['count']?$today_orders[4]['count']:0;
		$today_failed_orders=$today_orders[5]['count']+$today_orders[6]['count']+$today_orders[7]['count']+$today_orders[8]['count'];

		$data['today_orders']=array('total'=>$today_live_orders+$today_delivered_orders+$today_failed_orders, 'live'=>$today_live_orders, 'delivered'=>$today_delivered_orders, 'failed'=>$today_failed_orders);
/*
		$today_live_amount=$today_orders[1]['amount']+$today_orders[2]['amount']+$today_orders[3]['amount'];
		$today_delivered_amount=$today_orders[4]['amount']?$today_orders[4]['amount']:0;
		$today_failed_amount=$today_orders[5]['amount']+$today_orders[6]['amount']+$today_orders[7]['amount']+$today_orders[8]['amount'];

		$data['today_orders_amount']=array('total'=>$today_live_amount+$today_delivered_amount+$today_failed_amount, 'live'=>$today_live_amount, 'delivered'=>$today_delivered_amount, 'failed'=>$today_failed_amount);

		$today_live_commission=$today_orders[1]['commission']+$today_orders[2]['commission']+$today_orders[3]['commission'];
		$today_delivered_commission=$today_orders[4]['commission']?$today_orders[4]['commission']:0;
		$today_failed_commission=$today_orders[5]['commission']+$today_orders[6]['commission']+$today_orders[7]['commission']+$today_orders[8]['commission'];

		$data['today_orders_commission']=array('total'=>$today_live_commission+$today_delivered_commission+$today_failed_commission, 'live'=>$today_live_commission, 'delivered'=>$today_delivered_commission, 'failed'=>$today_failed_commission);*/


		/*$active_products=$this->Products_model->getActiveProducts();
		$data['active_products']=$active_products['count'];*/

		
        $total_orders=$this->Orders_model->getOrdersBetween($from->format('Y-m-d').' 00:00:00',$to.' 23:59:59');

        $data['this_month_orders']=$total_orders['count']?$total_orders['count']:0;

        $this_month_success_orders=$this->Orders_model->getSuccessOrdersBetween($from->format('Y-m-d').' 00:00:00',$to.' 23:59:59');
        $data['this_month_success_orders']=$this_month_success_orders['count']?$this_month_success_orders['count']:0;

		$big_order=0;

		$last12month=$this->Orders_model->getLast12MothOrder();

		foreach ($last12month as $value) {
			$data['month_name'].=($data['month_name']?',':'')."'".$value['date']."'";
			$data['monthly_orders'].=($data['monthly_orders']?',':'')."'".$value['count']."'";
			if($value['count']>$max_order)
			{
				$big_order=$value['count'];
			}
		}
		$data['chart_line']=(int)($big_order/4);
		$data['chart_line']=$data['chart_line']==0?1:$data['chart_line'];

		$current_month_Orders=$this->Orders_model->getCurrentMothOrderCountByDate();
		//print_r($current_month_Orders);exit;
		$max_order=0;
		foreach ($current_month_Orders as $value) {
			$data['current_month_Orders_date'].=($data['current_month_Orders_date']?',':'')."'".$value['date']."'";
			$data['current_month_Orders_orders'].=($data['current_month_Orders_orders']?',':'')."'".$value['count']."'";
			if($value['count']>$max_order)
			{
				$max_order=$value['count'];
			}
		}
		$data['is_current_month_orders']=$data['current_month_Orders_date']?true:false;
		$data['current_month_chart_line']=(int)($max_order/4);
		$data['current_month_chart_line']=$data['current_month_chart_line']==0?1:$data['current_month_chart_line'];
	}
		if($user['type']==5)
		{

		}


		
		//echo "<pre>";print_r($data['app_home_icons']);exit;
		$this->load->view('home.tpl',$data);
	}


}
