<?php

session_start(); //we need to start session in order to access it through CI

Class Crm extends CI_Controller {

  public function __construct() {
      parent::__construct();
      // Load form helper library
      $this->load->helper('form');
      // Load form validation library
      $this->load->library('form_validation');
      // Load session library
      $this->load->library('session');
      // Load database
      $this->load->model('User_model');
  }

  // Show login page
  public function index() {
      //echo 1213;exit;
      //$this->load->view('login_form');
  }

  public function Call_navbar() {
      //echo 1213;exit;
      $this->load->view('login_form');
  }

  // Show registration page
  public function user_registration_show() {
      $this->load->view('registration_form');
  }

  // Validate and store registration data in database
  public function new_user_registration()
  {
      // Check validation for user input in SignUp form
      $this->form_validation->set_rules('email', 'Email', 'trim|required|xss_clean');
      $this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean');
      if ($this->form_validation->run() == FALSE)
      {
          $this->load->view('registration_form');
      }
      else {

          $user_details = $this->User_model->login($this->input->post('email'),$this->input->post('password'));
          print_r($user_details);exit;
          if ($result == TRUE) {
              $data['message_display'] = 'Registration Successfully !';
              $this->load->view('login_form', $data);
          }
          else {
              $data['message_display'] = 'Username already exist!';
              $this->load->view('registration_form', $data);
          }
      }
  }

  // Check for user login process
  public function user_login_process() {

      $this->form_validation->set_rules('email', 'Email', 'trim|required');
      $this->form_validation->set_rules('password', 'Password', 'trim|required');

    if ($this->form_validation->run() == FALSE)
    {

      if(isset($this->session->userdata['logged_in'])){
        echo "already login";exit;
        $this->load->view('admin_page');
      }else{
        $this->load->view('login_form');
      }
    }
    else
    {
        $user_details = $this->User_model->login($this->input->post('email'),md5($this->input->post('password')));
        if (is_array($user_details))
        {
            $session_data = $user_details;
            // Add user data in session
            //echo 1;exit;
            $this->session->set_userdata('logged_in', $session_data);
            //$this->load->view('admin_page');
            echo "doss success";

        }
        else
        {
          $data = array(
          'error_message' => 'Invalid Username or Password'
          );
          $this->load->view('login_form', $data);
        }
    }
  }

  // Logout from admin page
  public function logout() {

  // Removing session data
  $sess_array = array(
  'username' => ''
  );
  $this->session->unset_userdata('logged_in', $sess_array);
  $data['message_display'] = 'Successfully Logout';
  $this->load->view('login_form', $data);
  }

}

?>
