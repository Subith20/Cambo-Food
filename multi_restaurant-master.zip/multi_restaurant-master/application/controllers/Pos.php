<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Pos extends Iglobe_Controller {

	public function __construct() {
			parent::__construct();
			// Load form helper library
			$this->load->helper('form');
			// Load form validation library
			$this->load->library('form_validation');
			$this->load->model('Shops_model');
			$this->load->model('Products_model');
			$this->load->model('Customer_model');
			$this->load->model('Orders_model');
	}

	function __destruct() {
		parent::__destruct();

  }

  	public function index() {

		$this->list();
	}

	public function list() {
		$data['base_url']=$this->config->item('base_url');
		if($this->getUser('type')==5)
		{
			$data['shops']=$this->Shops_model->myShopList($this->getUser('id'));
		}
		else if($this->getUser('type')==10) {
			$data['shops']=$this->Shops_model->cashierShopList($this->getUser('id'));
		}
		else {
			$this->smarty->display( '404.tpl',$data);
		}

		//echo "<pre>";print_r($data);exit;
		$this->smarty->display( 'pos/list.tpl',$data);
	}

	public function orders() {
		$data['to']=date('Y-m-d');
		$data['from']=date('Y-m-d', strtotime('-6 days'));
		$data['base_url']=$this->config->item('base_url');
		
		if($this->getUser('type')==5)
		{
			$data['shops']=$this->Shops_model->myShopList($this->getUser('id'));
		}
		else if($this->getUser('type')==10) {
			$data['shops']=$this->Shops_model->cashierShopList($this->getUser('id'));
		}
		else {
			$this->smarty->display( '404.tpl',$data);
		}

		$this->smarty->display( 'pos/orders_list.tpl',$data);
	}

	public function billing($shop_id)
	{
		
		if($this->getUser('type')==5)
		{
			$currency=$this->config->item('currency');
			$checkOwnerPermission=$this->Shops_model->checkOwnerPermission($this->getUser('id'),$shop_id);
			if(!$checkOwnerPermission)
			{
				$this->smarty->display( '404.tpl',$data);
			}
			$data['shop']=$this->Shops_model->GetDetails($shop_id);
			$data['products']=$this->Products_model->POSProductList($shop_id);
			$data['phone_code']=$this->config->item('country_code');
			$data['payment_mode']=$this->Shops_model->shop_payment_mode($shop_id);
			$data['currency']=$currency;
			//echo "<pre>";print_r($data['products']);exit;
			$this->smarty->display( 'pos/pos.tpl',$data);

		}
		else if($this->getUser('type')==10)
		{

		}
		else {
			$this->smarty->display( '404.tpl',$data);
		}


	}

	public function saveOrder()
	{
		$request=$this->input->post();
		$product_list=json_decode($request['product_list']);
		//echo "<pre>";print_r($product_list);exit;
		unset($request['ajax']);
		unset($request['product_list']);
		

		$order=array(
			'status'=>4,
			'method'=>$request['method'],
			'customer_id'=>$request['customer_id'],
			'cashier_id'=>$this->getUser('id'),
			'shop_id'=>$request['shop_id'],
			'pan'=>$request['pan'],
			'gst'=>$request['gst'],
			'shipping_name'=>$request['name'],
			'phone'=>$request['phone'],
			'email'=>$request['email'],
			'shipping_address'=>$request['shipping_address'],
			'price'=>$request['price'],
			'collect'=>$request['collect'],
			'tax_amount'=>$request['tax_amount'],
			'packing_charges'=>$request['packing_charges'],
			'total_amount'=>$request['total_amount'],
			'discount_amount'=>$request['discount_amount'],
			'notes'=>$request['notes']
		);

		$order_id=$this->Orders_model->POS_NewBill($order);
		if($order_id>0)
		{
			$order_product_list=array();
			foreach ($product_list as $value) {
				$order_product_list[]=array(
					'order_id'=>$order_id,
					'item_id'=>$value->id,
					'item_name'=>$value->name,
					'price'=>$value->sale_price,
					'qty'=>$value->qty,
					'tax_amount'=>$value->tax_amount,
					'tax'=>$value->tax,
					'packing_charges'=>$value->packing_charges,
					'total_amount'=>$value->total,
					'extras'=>json_encode($value->extras)
				);
				
				/*foreach ($value->extras as $extras_list) {
					$extras[]=array(
						'order_list_id'=>$product_insert_id,
						'extras_id'=>$extras_list->id,
						'name'=>$extras_list->name,
						'price'=>$extras_list->price,
						'qty'=>1
					);
					
				}
				//echo "<pre>";print_r($extras);exit;
				$this->Orders_model->POS_NewExtra($extras);*/
			}
			$product_insert_id=$this->Orders_model->POS_NewOrderItems($order_product_list);
			$this->JsonOut(array('message'=>'success','id'=>$order_id)); 
		}
		else
		{
			 $this->JsonOut(array('message'=>'Server error'),500); 
			
		}

		//$this->Orders_model->POS_NewOrderItems($order_product_list);
		
		
	}

	public function newCustomerForm()
	{
		$data['phone_code']=$this->config->item('country_code');
		$this->smarty->display( 'pos/new_customer.tpl',$data);
	}

	public function search_customer()
	{
		$request=$this->input->post();
		$user_id=$this->getUser('id');
		$user_type=$this->getUser('type');
		$customer_list=array();
		if($user_type==5)
		{
			$customer_list=$this->Customer_model->shop_customers_search_box(array('type'=>5,'user_id'=>$user_id,'search'=>$request['search']));
		}
		$this->JsonOut(array('message'=>'success','list'=>$customer_list)); 
	}

	public function new_customer_save()
	{

		$request=$this->input->post();
		//echo "<pre>";print_r($request);exit;
		$shop_id=$request['shop_id'];
		$phone=$request['phone'];
		$name=$request['name'];
		unset($request['ajax']);
		$this->form_validation->set_rules('name', 'Name', 'required');
		$this->form_validation->set_rules('shop_id', 'Shop ID', 'required');
		$check_phone_f=$this->CheckMobileNumber($phone);
		$this->form_validation->set_rules('phone', 'Phone number', 'required|integer|min_length[8]|max_length[13]');
		if(!$check_phone_f)
		{
			$this->JsonOut(array('message'=>'Invalid phone number format'),500); 
		}
		if ($this->form_validation->run() == FALSE)
        {
            $this->JsonOut(array('message'=>validation_errors()),500); 
        }
		$checkOwnerPermission=$this->Shops_model->checkOwnerPermission($this->getUser('id'),$shop_id);
		if(!$checkOwnerPermission)
		{
				$this->JsonOut(array('message'=>'Check Permission'),500); 
		}
		$customer_details=$this->Customer_model->Check_customer_shop($phone,$shop_id);
		//print_r($customer_details);exit;
		if(!$customer_details)
		{
			//print_r($request);exit;
			$shop_customer_id=$this->Customer_model->customer_shop_insert($request);
		}
		else {
			$this->JsonOut(array('message'=>'Customer Already Found'),500); 
		}
		$this->JsonOut(array('message'=>'Customer Added','id'=>$shop_customer_id)); 

	}

	 public function CheckMobileNumber($mobile_number)
    {
    	$code=$this->config->item('country_code');
      $number = preg_replace( '/[^0-9]/', '', $code.$mobile_number );
      
      switch ($code) {
        case '91':
            $Prefix = substr($number, 0, 2);
            $Length=strlen($number);
            if($code==$Prefix && $Length==12)
            {
              return $number;
            }
          break;

          case '855':
              $Prefix = substr($number, 0, 3);
              $Length=strlen($number);
              if($code==$Prefix && $Length<14 && $Length>10)
              {
                return $number;
              }
            break;

        default:
          return false;
          break;
      }
      return false;
    }


    public function orders_list_datatable()
    {
    	$currency=$this->config->item('currency');
		$request=$this->input->get();
		$shop_id=$request['shop_id'];
		$from=$request['from'];
		$to=$request['to'];
		$user_id=$this->getUser('id');
		$result=array();

		$orders=$this->Orders_model->POS_OrdertList(array('from'=>$from,'to'=>$to,'shop_id'=>$shop_id));
			foreach ($orders as $value) {
				$result[]=array(
					$value['id'].'<i class="fas fa-eye order-action" data-id="'.$value['id'].'"></i>',
					$value['order_date'],
					$value['shop_id'].' '.$value['shop_name'],
					$value['customer_name'].' (<a href="tel:'.$value['customer_phone'].'">'.$value['customer_phone'].'</a>)',
					$currency.' '.number_format((float)$value['total_amount'], 2, '.', ''),
				);
			}
			
		
		
		$this->JsonOut($result);
    }

    public function order_details($id)
    {
    	$data['currency']=$this->config->item('currency');
    	$json=$this->input->get('json');
    	$user_id=$this->getUser('id');
    	$data['orders']=$this->Orders_model->pos_orders_details(array('id'=>$id,'manager_id'=>$user_id));
    	if($data['orders']['id'])
    	{
	    	$data['shop']=$this->Shops_model->GetDetails($data['orders']['shop_id']);
	   		$data['title']="Order Details";
	    	$this->smarty->display( 'pos/details.tpl',$data);
    	}
    	else {
    		$this->smarty->display( '404.tpl',$data);
    	}
    	//echo "<pre>";print_r($data);
    	
    }

}
