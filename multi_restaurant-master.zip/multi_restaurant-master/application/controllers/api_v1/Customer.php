<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');


class Customer extends MY_Controller {

	public function __construct() {
			parent::__construct();

			$this->load->model('Customer_model');
			$this->load->model('Generic_model');
			$this->load->model('Settings_model');
	}


	public function Details_get() {
			$id=$this->_apiuser->user_id;
			if ($id>0) {
		        $customer_data=$this->Customer_model->GetCustomerDetails($id);
		        if($customer_data!=false)
		        {
		          $this->response([TRUE,'success',$customer_data], REST_Controller::HTTP_OK);
		        }
		        else {
		          $this->response([TRUE,'No Data',array()], REST_Controller::HTTP_OK);
		        }
	      }
	      else {
	        $this->response([TRUE,'No Data',array()], REST_Controller::HTTP_OK);
	      }

	}

	public function update_post() {
		$data=$this->httpRequest;
		$Customer_id=$this->_apiuser->user_id;
		unset($data->phone);
		$result=$this->Customer_model->update($data,$Customer_id);
		if($result!=false)
		{	$customer_data=$this->Customer_model->GetCustomerDetails($Customer_id);
		    $this->response([TRUE,'success',$customer_data], REST_Controller::HTTP_OK);
        }
		else
		{
		    $this->response([TRUE,'No Data',array()], REST_Controller::HTTP_OK);
		}

	}

	public function add_address_post()
	{

		$data=$this->httpRequest;

		$Customer_id=$this->_apiuser->user_id;

		$data->customer_id=$Customer_id;
		$result=false;
		$lat=$data->lat;
	    $long=$data->long;
	    if($lat> -90.1 and $lat<90.1 and $long> -180.1 and $long< 180.1 and is_numeric($lat) and is_numeric($long))
	    {
	    	if($Customer_id>0)
			{
				$result=$this->Customer_model->add_address($data);
			}
			
			if($result!=false)
			{	
				$price=$this->Settings_model->shipping_price_list();
				$distance_unit=$this->config->item('distance_unit');
				$shop_lat=$this->config->item('shop_lat');
				$shop_long=$this->config->item('shop_long');
				$distance=number_format($this->shop_distance($lat, $long, $shop_lat, $shop_long, $distance_unit), 2);
				$shipping_price=$this->shipping_price($distance);
			    $this->response([TRUE,'success',
			    	array(
			    		'id'=>$result,
			    		'distance'=>$distance,
			    		'shipping_price'=>$shipping_price['price'],
			    		'shipping_status'=>$shipping_price['available']?'Available':'Unavailable'
			    	)], REST_Controller::HTTP_OK);
	        }
			else
			{
			    $this->response([false,'No Data',array()], REST_Controller::HTTP_OK);
			}
	    }
	    else {
	    	$this->response([false,'invalid lat annd log',array()], REST_Controller::HTTP_OK);
	    }

		

	}

	public function address_list_get()
	{


		$customer_id=$this->_apiuser->user_id;
		$result=false;

		if($customer_id>0)
		{
			$address_list=$this->Customer_model->address_list($customer_id);
			foreach ($address_list as $value) {
				$distance_unit=$this->config->item('distance_unit');
				$shop_lat=$this->config->item('shop_lat');
				$shop_long=$this->config->item('shop_long');
				$distance=number_format($this->shop_distance($value['lat'], $value['long'], $shop_lat, $shop_long, $distance_unit), 2);
				$value['distance']=$distance;
				$value['distance_unit']=$distance_unit;

				$shipping_price=$this->shipping_price($distance);

				$value['shipping_price']=$shipping_price['price']?$shipping_price['price']:'false';
				$value['shipping_status']=$shipping_price['available']?'Available':'Unavailable';

				$result[]=$value;
			}
		}
		
		if($result!=false)
		{	
		    $this->response([TRUE,'success',$result], REST_Controller::HTTP_OK);
        }
		else
		{
		    $this->response([false,'No Data',array()], REST_Controller::HTTP_OK);
		}

	}

	public function address_delete_get($id)
	{


		$customer_id=$this->_apiuser->user_id;
		$result=false;

		if($customer_id>0)
		{
			$result=$this->Customer_model->address_delete($id,$customer_id);
		}
		
		if($result!=false)
		{	
		    $this->response([TRUE,'success',$result], REST_Controller::HTTP_OK);
        }
		else
		{
		    $this->response([false,'No Data',array()], REST_Controller::HTTP_OK);
		}

	}

	public function address_update_post() {
		$data=$this->httpRequest;
		$Customer_id=$this->_apiuser->user_id;
		$id=$data['id'];
		unset($data['id']);
		$result=$this->Customer_model->address_update($data,$Customer_id);
		if($result!=false)
		{	
		    $this->response([TRUE,'success',array()], REST_Controller::HTTP_OK);
        }
		else
		{
		    $this->response([false,'No Data',array()], REST_Controller::HTTP_OK);
		}

	}

}
