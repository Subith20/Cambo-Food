<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

// Load the Rest Controller library


class CustomerAuth extends MY_Controller {

    public function __construct() {
        parent::__construct();
        // Load the user model
        $this->load->model('customer_model');

    }

    
/*
    public function user_get($id = 0) {
        // Returns all the users data if the id not specified,
        // Otherwise, a single user will be returned.
        $con = $id?array('id' => $id):'';
        $users = $this->customer_model->getRows($con);

        // Check if the user data exists
        if(!empty($users)){
            // Set the response and exit
            //OK (200) being the HTTP response code
            $this->response($users, REST_Controller::HTTP_OK);
        }else{
            // Set the response and exit
            //NOT_FOUND (404) being the HTTP response code
            $this->response([
                'status' => FALSE,
                'message' => 'No user was found.'
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }*/

    
    private function _insert_key($key, $data)
    {
        $data['key'] = $key;
        $result = $this->customer_model->insert_token($data);
        return $result;
    }
    private function _generate_key()
  	{

  		do {
  			// Generate a random salt
  			$salt = base_convert(bin2hex($this->security->get_random_bytes(64)), 16, 36);

  			// If an error occurred, then fall back to the previous method
  			if ($salt === FALSE) {
  				$salt = hash('sha256', time() . mt_rand());
  			}

  			$new_key = substr($salt, 0, config_item('rest_key_length'));
  		} while ($this->_key_exists($new_key));

  		return $new_key;
  	}

    private function _key_exists($key)
  	{
  		return $this->rest->db
  			->where(config_item('rest_key_column'), $key)
  			->count_all_results(config_item('rest_keys_table')) > 0;
  	}

    public function otp_sms_request_post()
    {

      $phone=$this->httpRequest->phone;
      $code=$this->httpRequest->code?$this->httpRequest->code:$this->config->item('country_code');
      $test_OTP=$this->config->item('test_OTP');
      $test_OTP_number=$this->config->item('test_OTP_NO');
      $phone=$this->CheckMobileNumber($phone,$code);
			if($phone)
			{
				$db_entry=0;
        if($phone==$test_OTP_number && $test_OTP==2)
        {
          $test_OTP=1;
        }

        if($test_OTP==1)
        {
          $otp=111111;
        }
        else {
          $otp=$this->otp_generator();
        }

				$update = $this->customer_model->otp_sms_update($phone,$otp);

				if($update>0)
				{
					$db_entry=1;
					$new_user=false;
				}else {
					$insert_id = $this->customer_model->otp_sms_insert($phone,$otp);
					if($insert_id>0)
					{
						$db_entry=2;
						$new_user=true;
					}
				}
        if($test_OTP==1)
        {
          // test
          $this->response([TRUE,'OTP is 111111',array('new_user'=>$new_user,'OTP_timeout'=>$OTP_timeout)], REST_Controller::HTTP_OK);exit;
        }


				if($db_entry>0)
				{
            $otp_text=$this->config->item('otp_text');
            $sms_gateway=$this->config->item('sms_gateway');
						$msg=$otp_text." ".$otp;
            if($sms_gateway=='plasgate')
            {
              $result=$this->push_plasget_SMS($phone,$msg);
            }
            else {
              $result=$this->push_textlocal_sms($phone,$msg);
            }
						
					  $this->httpRequest->api_result=$result;
						if(is_object($result))
						{
							if($result->status=="success")
							{
                $OTP_timeout=$this->config->item('OTP_timeout');
                $this->response([TRUE,'OTP has been sent to your mobile number',array('new_user'=>$new_user,'OTP_timeout'=>$OTP_timeout)], REST_Controller::HTTP_OK);
							}
							else {
								$this->httpRequest->new_user=$new_user;
                $this->response([FALSE,'OTP sending failed - '.$result->warnings[0]->message,array('new_user'=>$new_user)], REST_Controller::HTTP_OK);
								//$this->response($this->Auth_model->model_response(false, 202, $this->httpRequest, "Server error1"), REST_Controller::HTTP_OK);
							}
						}
						else {
              $this->response([TRUE,'OTP sending failed',array('new_user'=>$new_user)], REST_Controller::HTTP_OK);
						}
				}
				else {
          $this->response([FALSE,'Server Error',array('new_user'=>$new_user)], REST_Controller::HTTP_OK);
					//$this->response($this->Auth_model->model_response(false, 202, $this->httpRequest, "Server error3"), REST_Controller::HTTP_OK);
				}
			}
			else {
        $this->response([FALSE,'Invalid ',array('new_user'=>$new_user)], REST_Controller::HTTP_OK);
				//$this->response($this->Auth_model->model_response(false, 202, $this->httpRequest, "Invalid Mobile number"), REST_Controller::HTTP_OK);
			}

			exit;


    }

    public function otp_generator() {
        $OTP_length=$this->config->item('OTP_length');
        if($OTP_length<4)
        {
          $OTP_length=4;
        }
		    $alphabet = '1234567890';
		    $pass = array(); //remember to declare $pass as an array
		    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
		    for ($i = 0; $i < $OTP_length; $i++) {
		        $n = rand(0, $alphaLength);
		        $pass[] = $alphabet[$n];
		    }
		    return implode($pass); //turn the array into a string
		}

    


    public function otp_sms_auth_post()
		{
      $OTP_timeout=$this->config->item('OTP_timeout');
      $phone=$this->httpRequest->phone;
      $otp=$this->httpRequest->otp;
      $device_token=$this->httpRequest->device_token;
      $device_details=$this->httpRequest->device_details;
			if($phone!=null && $otp>0)
			{

  			$response_query = $this->customer_model->otp_sms_auth($phone,$otp);
        $userData = $response_query->row();
      	$response = array();
          if ($userData->id > 0) {
  						$earlier = strtotime($userData->otp_time);
  						$later = strtotime(date("y-m-d H:i:s"));
  						$diff_time=$later-$earlier;
  						if($diff_time>$OTP_timeout)
  						{
                $this->response([false,'OTP timeout',array('request'=>$this->httpRequest)], REST_Controller::HTTP_OK);
  						}
              $key = $this->_generate_key();
              $apiKey_data = array(
                  'user_id' => $userData->id,
                  'level' => 1,
                  'ignore_limits' => 1,
                  'ip_addresses' => $this->input->ip_address(),
                  'device_token'=>$this->httpRequest->device_token,
                  'geolocation'=>$this->httpRequest->geolocation,
                  'user_type'=>6,
                  'device_details'=>$device_details
              );

             //print_r($apiKey_data);exit;

              $insert_token = $this->_insert_key($key, $apiKey_data);
              if ($insert_token>0) {
                  $response['api_key'] = $key;
                  $response['phone'] = $userData->phone;
                  $response['user_id'] = $userData->id;
                  $response['email'] = $userData->email;
                  $this->customer_model->remove_otp_sms($userData->id);
                  $this->response([true,'success',$response], REST_Controller::HTTP_OK);
              }
              else {
                  $this->response([false,'Server error',array('request'=>$this->httpRequest)], REST_Controller::HTTP_OK);
              }
          }
          else {
              $this->response([false,'Invalid OTP / Phone',array('request'=>$this->httpRequest)], REST_Controller::HTTP_OK);
          }
		}
		else {
      $this->response([false,'Invalid input',array('request'=>$this->httpRequest)], REST_Controller::HTTP_OK);
		}

	}


  public function CheckMobileNumber($mobile_number,$code)
    {
      $number = preg_replace( '/[^0-9]/', '', $mobile_number );

      switch ($code) {
        case '91':
            $Prefix = substr($number, 0, 2);
            $Length=strlen($number);
            if($code==$Prefix && $Length==12)
            {
              return $number;
            }
          break;

          case '855':
              $Prefix = substr($number, 0, 3);
              $Length=strlen($number);
              if($code==$Prefix && $Length<14 && $Length>10)
              {
                return $number;
              }
            break;

        default:
          return false;
          break;
      }
      return false;
    }

     public function push_plasget_SMS($mobile_number,$sms_body)
    {

      $curl = curl_init();
      $post_data= 'gw-username='.$this->config->item('plasgate_UNAME')
                  .'&gw-password='.curl_escape($curl,$this->config->item('plasgate_PASS'))
                  .'&gw-from='.$this->config->item('otp_SHORT_CODE')
                  .'&gw-to='.$mobile_number
                  .'&gw-text='.curl_escape($curl,$sms_body);
                  //return $post_data;
      curl_setopt_array($curl, array(
        CURLOPT_URL => "https://tool.plasgate.com:11041/cgi-bin/sendsms",
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_VERBOSE => true,
        CURLOPT_CAINFO => 'application/third_party/plasgate-ca-bundle.crt',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS =>$post_data,
      ));
      $response = curl_exec($curl);
      curl_close($curl);
      return $response;

    }

    public function push_textlocal_sms($phone,$msg)
    {

        $textlocal_API_KEY=$this->config->item('textlocal_API_KEY');
        // Account details
        $apiKey = urlencode($textlocal_API_KEY);
        // Message details
        $numbers = array($phone);
        $sender = urlencode('TXTLCL');
        $message = rawurlencode($msg);
        $numbers = implode(',', $numbers);
        // Prepare data for POST request
        $data = array('apikey' => $apiKey, 'numbers' => $numbers, "sender" => $sender, "message" => $message);
        //print_r($data);exit;
        // Send the POST request with cURL
        //$ch = curl_init('https://api.textlocal.in/send/');
        $ch = curl_init('https://api.textlocal.in/send/');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        //print_r($ch);exit;
        $response = curl_exec($ch);
        curl_close($ch);
        //print_r($response);exit;
        // Process your response here
        return json_decode($response);
    }

}
