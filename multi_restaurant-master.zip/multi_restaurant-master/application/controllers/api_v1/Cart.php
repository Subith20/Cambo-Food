<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

// Load the Rest Controller library


class Cart extends MY_Controller {

    public function __construct() {
        parent::__construct();

        // Load the user model
        $this->load->model('products_model');
        $this->load->model('Customer_model');
        $this->load->model('Shops_model');
        $this->load->model('Time_sheet_model');
        // Load form validation library

    }


    public function CartList_post() {
      $user_id=$this->_apiuser->user_id;
      $cartList=$this->products_model->CartList($user_id);
      $available_time_sheet=$this->Time_sheet_model->currentTimeSheet();

      if($cartList[0]['shop_id']>0)
      {
          $shop=$this->Shops_model->GetDetails($cartList[0]['shop_id']);
          if(!in_array($shop['avail_time'],$available_time_sheet) and $shop['avail_time']>0)
          {
            $shop['is_available']=0;
          }
          $lat1=$this->httpRequest->lat;
          $lon1=$this->httpRequest->long;
          $lat2=$shop['latitude'];
          $lon2=$shop['longitude'];
          $distance_unit=$this->config->item('distance_unit');
          $distance=$this->shop_distance($lat1, $lon1, $lat2, $lon2, $distance_unit);
          $shop['shipping_distance']=round($distance,2).$distance_unit;
          $shop['shipping_price']=$this->shipping_price($distance);

          foreach ($cartList as $key=>$value) {
            if(!in_array($value['avail_time'],$available_time_sheet) and $value['avail_time']>0)
            {
              $cartList[$key]['is_avail']=0;
            }
            
          }
          $shop['cart_list']=$cartList;
          $this->response([TRUE,'success',$shop], REST_Controller::HTTP_OK);
      }
      else {
          $this->response([false,'No Data',array()], REST_Controller::HTTP_OK);
      }
    }

    public function UpdateCartProduct_post() {
      $user_id=$this->_apiuser->user_id;
      $cart_id=$this->httpRequest->id;
      $qty=$this->httpRequest->qty;
      $status=$this->products_model->UpdateCartProduct($cart_id, $user_id, $qty);

      if($status!=false)
      {
          $CartList=$this->products_model->CartList($user_id);
          $this->response([TRUE,'success',$CartList], REST_Controller::HTTP_OK);
      }
      else {
          $this->response([false,'No Data',array()], REST_Controller::HTTP_OK);
      }
    }

    public function AddToCart_post() {
      $user_id=$this->_apiuser->user_id;
      $qty=$this->httpRequest->qty;
      $extras=$this->httpRequest->extras;
      sort($extras);
      $product_id=$this->httpRequest->id;

      if ($product_id>0) {
        $product_data=$this->products_model->GetProductDetails($product_id);
        if($product_data!=false)
        {
          $products_extras=$this->products_model->CheckProductExtras_array($product_id,$extras);

         
          if($qty!=0) {
            

            $insert_id=$this->products_model->AddToCart($product_id,$user_id,$qty);
          }
          else {
             $this->response([false,'Invalid Input',array()], REST_Controller::HTTP_OK);
          }

          if($insert_id>0)
          {
            foreach ($products_extras as $e_value) {
                  $this->products_model->AddExtraToCart($insert_id,$e_value['id'],$qty=1);
              }
              //$CartList=$this->products_model->CartList($user_id);
              $this->response([TRUE,'success',array()], REST_Controller::HTTP_OK);
          }
           else {
          $this->response([false,'Product Not Found',array()], REST_Controller::HTTP_OK);
        }

          
        }
        else {
          $this->response([false,'Product Not Found',array()], REST_Controller::HTTP_OK);
        }
      }
      else {
        $this->response([false,'Invalid Product ID',array()], REST_Controller::HTTP_OK);
      }

    }


    public function RemoveFromCart_post() {
      $user_id=$this->_apiuser->user_id;
      $id=$this->httpRequest->id;
      if($id>0)
      {
        $this->products_model->RemoveFromMyCart($id,$user_id);
      }
      $CartList=$this->products_model->CartList($user_id);
      $this->response([TRUE,'success',$CartList], REST_Controller::HTTP_OK);
    }

    public function ClearCartList_get() {
      $user_id=$this->_apiuser->user_id;
      $product_result=$this->products_model->ClearCartList($user_id);

      $this->response([TRUE,'success',array()], REST_Controller::HTTP_OK);

    }




}
