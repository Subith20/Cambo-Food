<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

// Load the Rest Controller library


class Products extends MY_Controller {

    public function __construct() {
        parent::__construct();

        // Load the user model
        //$this->load->model('user');
        $this->load->model('Shops_model');
        $this->load->model('Products_model');
        $this->load->model('Time_sheet_model');
        // Load form validation library

    }

    public function Category_get()
    {
      $result=$this->Products_model->ProductCatSelectList(array('active'=>true));
      $data=$result?$result:array();
      $this->response([TRUE,'success',$data], REST_Controller::HTTP_OK);
    }

    public function GetshopProducts_post() {

      $distance_unit=$this->config->item('distance_unit');
      $request=(array)$this->httpRequest;
      $lat=$request['lat'];
      $long=$request['long'];
      $shop_id=$request['shop_id'];
      $page=$request['page'];
      $request['shop_id'] = $shop_id;
      $request['extras'] = true;
      $request['page'] = $page>0?$page:1;

      if($request['shop_id']>0)
      {
       
        $shops=$this->Shops_model->GetDetails($shop_id);
        if($shops['id']>0)
        {
           $available_time_sheet=$this->Time_sheet_model->currentTimeSheet();
          if(!in_array($shops['avail_time'],$available_time_sheet) and $shops['avail_time']>0)
          {
            $shops['is_available']=0;
          }

          $shops['distance']=null;
          if($lat && $long)
          {
            $shops['distance']=number_format((float)$this->shop_distance($lat, $long,$shops['latitude'], $shops['longitude'], $distance_unit), 2, '.', '').$distance_unit;
          }
          
          $category_list=$this->Products_model->GetRestProductList($request);

          $shops['category_list']=$category_list?$category_list:array();
        }
        else {
          $this->response([false,'Invalid input',array()], REST_Controller::HTTP_OK);
        }
        
      }
      else {
        $this->response([false,'Invalid input',array()], REST_Controller::HTTP_OK);
      }
      $data=$shops?$shops:array();
      $this->response([TRUE,'success',$data], REST_Controller::HTTP_OK);
    }



    public function GetProductDetails_get($id=0) {
      $max_count=$this->config->item('max_product_count');

      if ($id>0) {
        $data=$this->Products_model->GetProductDetails($id);
        $data['extras_group']=array();
        $extras=$this->Products_model->GetActiveProductExtras($id);
        $extras_group=$this->Products_model->GetProductExtrasGroup($id);
        $extras_group_type=$this->config->item('extras_group_type');

        foreach ($extras_group as $value) {

          $value['extras']=array();
          foreach ($extras as $extra_key=>$extra_value) {
            if($extra_value['group_id']==$value['id'])
            {
              $value['extras'][]=$extra_value;
              unset($extras[$extra_key]);
            }
          }
          $value['type_name']=$extras_group_type[$value['type']];
          $data['extras_group'][]=$value;
          
        }

        $img=$this->Generic_model->UploadFilesList('products',$id);
        $img=reset($img);
        $data['img']=$img['file_name'];
        $data['count']=1;
         $cc_max=$data['max_count']>0?$data['max_count']:$max_count;
         for ($i_cc=1; $i_cc <$cc_max+1 ; $i_cc++) {
           $data_max_count[]=$i_cc;
         }

         $data['max_count']=$data_max_count;

        if($data!=false)
        {
          $this->response([TRUE,'success',$data], REST_Controller::HTTP_OK);
        }
        else {
          $this->response([TRUE,'No Data',$data], REST_Controller::HTTP_OK);
        }
      }
      else {
        $this->response([TRUE,'No Data',$data], REST_Controller::HTTP_OK);
      }

    }

    public function GetSpecialProducts_get() {
      $available_time_sheet=$this->Time_sheet_model->currentTimeSheet();
      $SpecialCatList=$this->Products_model->SpecialCatList('all');
      foreach ($SpecialCatList as $key=>$value) {
        $product_list=$this->Products_model->SpecialList($value['id']);
        $product_full_list=null;
        foreach ($product_list as $key2=>$value2) {
          if(!in_array($value2['avail_time'],$available_time_sheet) and $value2['avail_time']>0)
        {
          $product_list[$key2]['is_avail']=0;
        }
          $img_path=$this->Generic_model->UploadFilesList('products',$value2['product_id']);
         // echo "<pre>";print_r(reset($img_path));exit;
          $img_path=reset($img_path);
          $img_path=$img_path['file_name'];
          $product_list[$key2]['img']=$img_path;
          $product_list[$key2]['count']=1;
          $product_list[$key2]['extras']=array();
          $value2['extras_group']=array();
          $extras=$this->Products_model->GetActiveProductExtras($value2['id']);
          $extras_group=$this->Products_model->GetProductExtrasGroup($value2['id']);
          $extras_group_type=$this->config->item('extras_group_type');

          foreach ($extras_group as $gp_value) {

            $gp_value['extras']=array();
            foreach ($extras as $extra_key=>$extra_value) {
              if($extra_value['group_id']==$gp_value['id'])
              {
                $gp_value['extras'][]=$extra_value;
                unset($extras[$extra_key]);
              }
            }
            $gp_value['type_name']=$extras_group_type[$gp_value['type']];
            $value2['extras_group'][]=$gp_value;
            
          }

          $product_list[$key2]=$value2;

        }
       $SpecialCatList[$key]['products']=$product_list;
      }
      if ($SpecialCatList) {
          $this->response([TRUE,'success',$SpecialCatList], REST_Controller::HTTP_OK);
      }
      else {
        $this->response([TRUE,'No Data',$data], REST_Controller::HTTP_OK);
      }

    }


}
