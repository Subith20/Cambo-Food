<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

// Load the Rest Controller library


class Home extends MY_Controller {

    public function __construct() {
        parent::__construct();

        // Load the user model
        //$this->load->model('user');
        $this->load->model('Home_model');
        $this->load->model('Banner_model');
        $this->load->model('Generic_model');
        $this->load->model('Shops_model');
        $this->load->model('Products_model');
        $this->load->model('Time_sheet_model');
    }

    public function home_icon_get() {

      $data=$this->Home_model->GetHomeIcon();
      if($data!=false)
      {
        $this->response([TRUE,'success',$data], REST_Controller::HTTP_OK);
      }
      else {
        $this->response([TRUE,'No Data',$data], REST_Controller::HTTP_OK);
      }
    }

  public function getBannerList_get()
  {
      $list=$this->Banner_model->GetList();
    //$data['list']=$list;
    foreach ($list as $value) {
      $data_file_data=$this->Generic_model->UploadFilesList('banner',$value['id']);
      $data_file_data=reset($data_file_data);
      $value['image']=$data_file_data['file_name'];
       $data[]=$value;
    }
    $this->response([true,'success',$data], REST_Controller::HTTP_OK);
  }

  public function appSettings_get()
  {
    $result=$this->userApiSettings();
    
    $this->response([true,'success',$result], REST_Controller::HTTP_OK);
  }

  public function search_post()
  {
      $request=$this->httpRequest;
      $lat=$request->lat;
      $long=$request->long;
      $search_input=$request->search_input;
      if($lat>0 && $long>0 && strlen($search_input)>2)
      {
        $available_time_sheet=$this->Time_sheet_model->currentTimeSheet();
        $shops=$this->Shops_model->getSearchNearShops($lat,$long,$search_input);
        foreach ($shops as $key=>$value) {
          if(!in_array($value['avail_time'],$available_time_sheet) and $value['avail_time']>0)
          {
            $shops[$key]['is_available']=0;
          }
        }
        $data['shops']=$shops;

        $products=$this->Products_model->SearchProductNearShops($lat,$long,$search_input);
        foreach ($products as $key=>$value) {
          if(!in_array($value['avail_time'],$available_time_sheet) and $value['avail_time']>0)
          {
            $products[$key]['is_avail']=0;
          }
          if(!in_array($value['shop_time_sheet'],$available_time_sheet) and $value['shop_time_sheet']>0)
          {
            $products[$key]['is_avail']=0;
          }
        }
        $data['products']=$products;
      }
      
      if($data!=false)
      {
        $this->response([TRUE,'success',$data], REST_Controller::HTTP_OK);
      }
      else {
        $this->response([false,'Service Not Available',array()], REST_Controller::HTTP_OK);
      }
    }


}
