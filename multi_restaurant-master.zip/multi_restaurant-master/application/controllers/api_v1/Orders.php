<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

// Load the Rest Controller library


class Orders extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Orders_model');
        $this->load->model('Shops_model');
        $this->load->model('products_model');
        $this->load->model('Customer_model');
        $this->load->model('User_model');
        $this->load->model('settings_model'); 

    }


    public function GetOrdertList_get() {
      $user_id=$this->_apiuser->user_id;
      $order_list=$this->Orders_model->GetOrdertList(array('user_id'=>$user_id));
      if($order_list!=false)
      {
          $this->response([TRUE,'success',$order_list], REST_Controller::HTTP_OK);
      }
      else {
          $this->response([TRUE,'No Data',array()], REST_Controller::HTTP_OK);
      }
    }

    public function OrderCancel_post() {
      $customer_id=$this->_apiuser->user_id;
      $order_id=$this->httpRequest->order_id;
      $order_detail=$this->Orders_model->GetOrderDetail(array('id'=>$order_id,'customer_id'=>$customer_id));

      if(is_array($order_detail) )
      {
        if($order_detail['status_id']<2)
        {
          $status=6;
          $is_update=$this->Orders_model->status_update($order_detail['id'],$status);

          $order_details=$this->Orders_model->GetOrderBasicDetail($order_id);
          //echo "<pre>";print_r($order_details);exit;

          if($order_details['driver_id']>0)
          {
            $driver_token=$this->Customer_model->getDeviceToken($order_details['driver_id']);
          }

          $manager_token=$this->Customer_model->getDeviceToken($order_details['manager_id']);
          
          $message='Your order #'.$order_details['id'].' : '.$order_status[$request['status']];

          foreach ($driver_token as $key_data) {
            $fcm_result=$this->fcm_push_notification($key_data['device_token'], 'Order Updates', $message);
            $push_result[]=array('token'=>$key_data['device_token'],'response'=>$fcm_result);
          }
          
          foreach ($manager_token as $key_data) {
            $fcm_result=$this->fcm_push_notification($key_data['device_token'], 'Order Updates', $message);
            $push_result[]=array('token'=>$key_data['device_token'],'response'=>$fcm_result);
          }
          $this->response([TRUE,'Order canceled',array()], REST_Controller::HTTP_OK);
        }
        else {
          $this->response([false,'invalid status, contact shop admin',array()], REST_Controller::HTTP_OK);
        }
          
      }
      else {
          $this->response([false,'No Data',array()], REST_Controller::HTTP_OK);
      }
    }

    public function GetOrderDetail_get($order_id) {
      $customer_id=$this->_apiuser->user_id;
      $order_detail=$this->Orders_model->GetOrderDetail(array('id'=>$order_id,'customer_id'=>$customer_id));

      if(is_array($order_detail))
      {
          $this->response([TRUE,'success',$order_detail], REST_Controller::HTTP_OK);
      }
      else {
          $this->response([TRUE,'No Data',array()], REST_Controller::HTTP_OK);
      }
    }

    public function Order_post() {

      $customer_id=$this->_apiuser->user_id;
      $processed_by=$customer_id;
      $bill_master_Id=$this->bill_gen($customer_id);
      if($bill_master_Id>0)
      {
          $this->GetOrderDetail_get($bill_master_Id);
          //$this->response([TRUE,'success',array()], REST_Controller::HTTP_OK);
      }
      else {
          $this->response([FALSE,'No Data',array()], REST_Controller::HTTP_OK);
      }
    }


    public function bill_gen($customer_id) {
      
      $payment_gateway=$this->httpRequest->payment_mode?$this->httpRequest->payment_mode:1;
      
      $shipping_id= $this->httpRequest->shipping_address;
      $product_cart_list=$this->products_model->basicCartList($customer_id);
      $shop_id=$product_cart_list[0]['shop_id'];

      if($shop_id>0)
      {
        $shop_details=$this->Shops_model->GetDetails($shop_id);
      }
      
      if(!$shop_details or $shop_details['is_available']==0)
      {
        $this->response([FALSE,'Shop Unavailable',array()], REST_Controller::HTTP_OK);
      }

      $shipping_details=$this->GetShippingPrice($shipping_id,$customer_id,$shop_details['latitude'],$shop_details['longitude']);
      //print_r($shipping_details);exit;
      if(!$shipping_details['shipping_status'])
      {
        $this->response([FALSE,'Service Unavailable',array()], REST_Controller::HTTP_OK);
      }

      $shop_driver_list=$this->Shops_model->ShopActiveDriverOrderList($shop_id);

      if($shop_driver_list[0])
      {
        $driver_id=$shop_driver_list[0]['id'];
        $master_data['shipping_price']=0;
      }
      else {
        $our_driver_list=$this->User_model->getOurDrivers('active');
        if($our_driver_list[0])
        {
          $driver_id=$our_driver_list[0]['id'];
        }
        $master_data['shipping_price']=$shipping_details['shipping_price'];
      }

      $default_order_status=$this->config->item('default_order_status');
      $master_data['driver_id']=$driver_id;
      $master_data['shop_id']=$shop_id;
      $master_data['status']=$default_order_status>1?$default_order_status:($shop_details['is_auto_accept']==1?2:1);
      $master_data['customer_id']=$customer_id;
      $master_data['pan']=$this->httpRequest->pan?$this->httpRequest->pan:0;
      $master_data['gst']=$this->httpRequest->gst?$this->httpRequest->gst:0;
      $master_data['shipping_name']=$shipping_details['shipping_address']['name'];
      $master_data['shipping_address']=$shipping_details['shipping_address']['address'];
      $master_data['shipping_id']=$shipping_details['shipping_address']['id'];
      $master_data['phone']=$shipping_details['shipping_address']['phone'];
      $master_data['email']=$shipping_details['shipping_address']['email'];
      $master_data['zip']=$shipping_details['shipping_address']['zip'];
      
      $master_data['method']=$payment_gateway;

      if($this->httpRequest->notes)
      {
        $master_data['notes']=$this->httpRequest->notes;
      }

      //echo "<pre>";print_r($master_data);exit;
      if($payment_gateway==4 || $payment_gateway==5)
      {
        $transaction_id=$this->httpRequest->transaction_id;
        $payment_details=$this->Orders_model->GetPaymentsDetails($customer_id,$payment_gateway,$transaction_id);

        if($payment_details['status']==3 && $payment_details['order_id']==0)
        {
          $master_data['payment_status']='paid';
          $master_data['paid_amount']=$payment_details['price'];
        }
        else {
          $master_data['method']=0;
        }
      }

      if(count($product_cart_list)>0)
      {
        $order_Id=$this->Orders_model->NewBillMaster($master_data);
        if($payment_details['status']==3 && $payment_details['order_id']==0)
        {
          $this->Orders_model->payment_gateway_update(array('order_id'=>$order_Id),$payment_details['id']);
        }
      }
      else {
        $this->response([FALSE,'Your cart is empty',array()], REST_Controller::HTTP_OK);
      }


      if($order_Id<1)
      {
        return false;
      }

      $order_price=0;
      $order_amount_total=0;
      $order_tax_amount=0;
      $order_packing_charges=0;
      //echo "<pre>";print_r($product_cart_list);exit;
      foreach ($product_cart_list as $key => $value) {
        if($value['shop_id']==$shop_id)
        {
          $OrderItems=array(
            'order_id'=>$order_Id,
            'item_id'=>$value['product_id'],
            'item_name'=>$value['product_name'],
            'price'=>$value['sale_price'],
            'qty'=>$value['count'],
            'total_amount'=>$value['total'],
            'tax'=>$value['tax'],
            'tax_amount'=>$value['sub_tax_amount'],
            'packing_charges'=>$value['sub_packing_charges']
          );
          $list_id=$this->Orders_model->NewOrderItems($OrderItems);

          $list_id_col[]=$list_id;
          if($list_id>0)
          {
            $order_price+=$value['sub_total_amount'];
            $order_amount_total+=$value['total'];
            $order_tax_amount+=$value['sub_tax_amount'];
            $order_packing_charges+=$value['sub_packing_charges'];

            foreach ($value['extras'] as $extra_value) {
                $extras_price=$extra_value['price'];
                $extras_tax_amount=(($extra_value['price']/100)*$value['tax']);
                $order_extras_item=array(
                  'order_list_id'=>$list_id,
                  'extras_id'=>$extra_value['extras_id'],
                  'name'=>$extra_value['name'],
                  'price'=>$extras_price,
                  'tax_amount'=>$extras_tax_amount
                );
                $order_price+=$extras_price;
                $extra_id=$this->Orders_model->NewOrderExtras($order_extras_item);
            }
          }
        }

      }
      $order_update_data['discount_amount']=0;
      if($shop_details['discount_percentage']>0)
      {
        $order_update_data['discount_amount']=($order_amount_total/100)*$shop_details['discount_percentage'];
        $order_amount_total=$order_amount_total-$order_update_data['discount_amount'];
      }
      $order_update_data['price']=$order_price;
      $order_update_data['total_amount']=$order_amount_total+($shipping_details['shipping_price']>0?$shipping_details['shipping_price']:0);
      $order_update_data['tax_amount']=$order_tax_amount;
      $order_update_data['packing_charges']=$order_packing_charges;
      $order_update_data['commission_amount']=($order_amount_total/100)*$shop_details['commission'];
      



      if (count($list_id_col)>0) {

        $this->Orders_model->order_update($order_update_data,$order_Id);
        $this->products_model->ClearCartList($customer_id);

        $message='Your have new Order. Order number :'.$order_Id;

        /*shop notification*/
        $tokenlist=$this->User_model->getDeviceToken($shop_details['user_id']);
        foreach ($tokenlist as $key_data) {
          $fcm_result=$this->fcm_push_notification($key_data['device_token'], 'Order Updates', $message);
          $push_result[]=array('token'=>$key_data['device_token'],'response'=>$fcm_result);
        }

        /*Driver notification*/
        $tokenlist=$this->User_model->getDeviceToken($driver_id);
        foreach ($tokenlist as $key_data) {
          $fcm_result=$this->fcm_push_notification($key_data['device_token'], 'Order Updates', $message);
          $push_result[]=array('token'=>$key_data['device_token'],'response'=>$fcm_result);
        }

        return $order_Id;
      }
      else {
        return 'Your cart is empty';
      }

    }

    public function PaymentGatewayRequest_get()
    {
      //print_r($this->_get_args);
      //echo $this->httpRequest->total;exit;

      $customer_id=$this->_apiuser->user_id;
      $data['customer_details']=$this->Customer_model->GetCustomerDetails($customer_id);
      $total=$this->_get_args['total'];
      $data['total']=number_format((float)$total, 2, '.', '');
      $data['shipping_price']=$this->_get_args['shipping_price'];
      $data['payment_gateway']=$payment_gateway=$this->_get_args['payment_gateway'];

      if($data['total']>0 && $payment_gateway>1)
      {
        if($payment_gateway==4 || $payment_gateway==5)
        {
          //PayWay & ABA pay
          echo $body=$this->Gateway_PayWay_Request($data);
        }
        else {
          echo "Invalide input";
        }
        
      }
      else {
         echo "Invalide input";
      }
      exit;

    }

    public function GatewayResponse_post()
    {
        $customer_id=$this->_apiuser->user_id;
        $amount=$this->httpRequest->total;
        $payment_gateway=$payment_gateway=$this->httpRequest->payment_gateway;
        $gateway_entry=$this->Orders_model->CustomerLastPaymentsDetails($customer_id,$payment_gateway,$amount);
        
        if($gateway_entry['id'])
        {
          if($payment_gateway==4 || $payment_gateway==5)
          {
            //PayWay & ABA pay
            $this->Gateway_PayWay_response($gateway_entry);
            exit;
          }
        }
        else {
          $this->response([TRUE,'waiting',array('waiting'=>false,'payment'=>false,'payment_id'=>false,'error'=>'Payment Details not found')], REST_Controller::HTTP_OK);
        }
        
    }

    

    function GetShippingPrice($shipping_id,$customer_id,$shop_lat,$shop_long)
    {
      $shipping_address=$this->Customer_model->get_address($shipping_id,$customer_id);
      $distance_unit=$this->config->item('distance_unit');

      $distance=$this->shop_distance($shipping_address['lat'], $shipping_address['long'], $shop_lat, $shop_long, $distance_unit);

      $shipping_distance=round($distance,2).$distance_unit;
      $shipping_price=$this->shipping_price($distance);

      if(!$shipping_address)
      {
        return false;
      }

      $shipping_price=$this->shipping_price($distance);

      return array('shipping_address'=>$shipping_address,
                   'shipping_distance'=>$shipping_distance,
                   'shipping_price'=>$shipping_price['price'],
                   'shipping_status'=>$shipping_price['available']);
    }


    public function Gateway_PayWay_Request($data)
    {
        extract($data);
        $transactionId=$customer_details['id'].'-'.time();
        $ApiUrl=$this->config->item('payway_url');
        $merchant_id=$this->config->item('payway_merchat_id');
        $api_key=$this->config->item('payway_api_key');
        $Hash=base64_encode(hash_hmac('sha512', $merchant_id.$transactionId.$total, $api_key, true));
        $payment_option=$payment_gateway==4?'cards':'abapay';

        $gateway_entry_data['price']=$total;
        $gateway_entry_data['gateway_id']=$payment_gateway;
        $gateway_entry_data['status']=1; //status = created
        $gateway_entry_data['phone']=$customer_details['email'];
        $gateway_entry_data['email']=$customer_details['phone'];
        $gateway_entry_data['customer_id']=$customer_details['id'];
        $gateway_entry_data['transaction_id']=$transactionId;
        $gateway_entry_data['method']=$payment_option;
        $gateway_entry_data['request_params']='{"hash":"'.$Hash.'"}';
        $gateway_entry_id=$this->Orders_model->payment_gateway_insert($gateway_entry_data);

        return '<!DOCTYPE html><html lang="en"><head>
                  <title>Miimfi Payment</title>
              <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"><meta name="author" content="PayWay"><script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script> 
              <style>
              .aba-close {
              display: none;
          }
          .aba-modal-content {
              width: 100vw !important;
              margin: 0px !important;
          }</style></head> <body> <div id="aba_main_modal" class="aba-modal">
              <div class="aba-modal-content">
                  <form method="POST" target="aba_webservice" action="'.$ApiUrl.'" id="aba_merchant_request">
                      <input type="hidden" name="hash" value="'.$Hash.'" id="hash"/>
                      <input type="hidden" name="tran_id" value="'.$transactionId.'" id="tran_id"/>
                      <input type="hidden" name="amount" value="'.$total.'" id="amount"/>
                      <input type="hidden" name="firstname" value="'.$customer_details['name'].'"/>
                      <input type="hidden" name="lastname" value="'.$customer_details['last_name'].'"/>
                      <input type="hidden" name="phone" value="'.$customer_details['phone'].'"/>
                      <input type="hidden" name="email" value="'.$customer_details['email'].'"/>
                      <input type="hidden" name="payment_option" value="'.$payment_option.'">
                      <input type="hidden" name="currency" value="USD">
                  </form>
              </div>
          </div>
          <div class="container" style="margin-top: 75px;margin: 0 auto;">
              <div style="width: 200px;margin: 0 auto;">
                  <div class="wpr_payment_option">
                      <div>
                          <input type="radio" name="payment_option" id="cards" class="payment_option" style="margin: 14px;float: left;" checked value="cards">
                          <label class="paymentOption" for="cards">
                              <img class="cardType" src="logos/ic_generic_1x.png">
                              <span class="detailCard001" style="margin-left: 16px; float: right; position: absolute;">
                                     <strong><span>  Credit/Debit Card </span><br/></strong>
                              <img class="bundleCard" src="logos/A-3Card_1x.png" style="margin-top: 5px;">
                              </span>
                          </label>
                      </div>
                      <div style="margin-top: 10px">
                          <input type="radio" name="payment_option" class="payment_option" style="margin: 14px;float: left;" checked value="abapay">
                          <label class="paymentOption" for="abapay">
                              <img class="cardType" src="logos/ic_ABA PAY_1x.png">
                              <span class="detailCard002" style="margin-left: 16px; float: right; position: absolute;">
                              <strong><span class="titleCard">ABA PAY</span><br/></strong>
                              <span class="detailCard003" style="margin-top: 5px;">Tap to pay with ABA Mobile</span>
                          </span>
                          </label>
                      </div>
                  </div>
                  <h2>TOTAL: '.$total.'</h2>
                  <input type="button" id="checkout_button" value="Checkout Now">
              </div>
          </div>
          <link rel="stylesheet" href="https://payway-staging.ababank.com/checkout-popup.html?file=css"/>
          <script src="https://payway-staging.ababank.com/checkout-popup.html?file=js"></script>
          <script>
              $(document).ready(function(){
                      AbaPayway.checkout();
              });
          </script>
          </body>
          </html>';

    }

    public function Gateway_PayWay_response($data)
    {
      
      if($data['status']==3)
      {
          $this->response([TRUE,'success',array('waiting'=>false,'payment'=>true,'payment_id'=>$data['id'],'transaction_id'=>$data['transaction_id'])], REST_Controller::HTTP_OK);
      }
      else if($data['status']==1 || $data['status']==2 || $data['status']==6)
      {
          $ApiUrl=$this->config->item('payway_url').'check/transaction/';
          $merchant_id=$this->config->item('payway_merchat_id');
          $api_key=$this->config->item('payway_api_key');
          $transaction_id=$data['transaction_id'];
          //2. hash (string) - encrypt "merchant_id+tran_id, key" with hash_hmac sha512 after that
          $Hash=base64_encode(hash_hmac('sha512', $merchant_id.$transaction_id, $api_key, true));

          $postfields = array(
              'tran_id' => $transaction_id,
              'hash' => $Hash
          );
          $ch = curl_init();
          curl_setopt($ch, CURLOPT_URL, $ApiUrl);
          curl_setopt($ch, CURLOPT_PROXY, null);
          curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
          curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
          curl_setopt($ch, CURLOPT_POST, 1);
          curl_setopt($ch, CURLOPT_POSTFIELDS, $postfields);
          curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); // On dev server only!
          $result = curl_exec($ch);//Result Json
          $output = json_decode($result, true);//Result Array
          //print_r($output);
          if($output['status']==0)
          {
            $response_status=3;
          }
          else if($output['status']==1)
          {
            $response_status=1;
          }
          else if($output['status']==2)
          {
            $response_status=2;
          }
          else if($output['status']==3)
          {
            $response_status=4;
          }
          else if($output['status']==4)
          {
            $response_status=5;
          }
          else {
            $response_status=6;
          }

          $payment_update=array('status'=>$response_status,'gateway_status_code'=>$output['status'],'gateway_status'=>$output['description'],'last_response'=>$result);
          //print_r($payment_update);exit;
          $this->Orders_model->payment_gateway_update($payment_update,$data['id']);
          if($response_status==3)
          {
            $this->response([TRUE,'success',array('waiting'=>false,'payment'=>true,'payment_id'=>$data['id'],'transaction_id'=>$data['transaction_id'])], REST_Controller::HTTP_OK);
          }
          else if($response_status==1 || $response_status==2 || $response_status==6)
          {
            $this->response([TRUE,'success',array('waiting'=>true,'payment'=>false,'payment_id'=>$data['id'],'transaction_id'=>$data['transaction_id'])], REST_Controller::HTTP_OK);
          }
          else {
            $this->response([TRUE,'success',array('waiting'=>false,'payment'=>false,'payment_id'=>$data['id'],'transaction_id'=>$data['transaction_id'])], REST_Controller::HTTP_OK);
          }
      }
      else
      {
        
        $this->response([TRUE,'success',array('waiting'=>false,'payment'=>false,'payment_id'=>$data['id'],'transaction_id'=>$data['transaction_id'])], REST_Controller::HTTP_OK);
      }
    }

    public function Gateway_ICICI_india_Request($data)
    {

      $customer_id=$this->_apiuser->user_id;
      $customer_details=$this->Customer_model->GetCustomerDetails($customer_id);
      require_once 'application/third_party/bankonnect/HttpHandler.php';
      $conf = parse_ini_file('application/config/bankonnect_conf.ini');
      $http = new HttpHandler();
      $payment_gw_data=[
              'amount' => $total_price,
              'currency'  => 'INR',
              'mtx' => date('ymdhis'), // merchant reference number
              'email_id' => $customer_details['email']?$customer_details['email']:$customer_details['phone'].'@iglobesystems.com',
              'contact_number' => $customer_details['phone']
          ];
      if($total_price>0)
      {
       try { 
              $payment_token = $http->_do_post(
              $payment_token['create']['route'],
              $payment_gw_data
              );

        $gateway_entry_data['price']=$payment_token->amount;
        $gateway_entry_data['gateway_id']=$payment_token->id;
        $gateway_entry_data['status']=$payment_token->status;
        $gateway_entry_data['contact_number']=$payment_token->customer->contact_number;
        $gateway_entry_data['email_id']=$payment_token->customer->email_id;
        $gateway_entry_data['customer_request_id']=$payment_token->customer->id;
        $gateway_entry_data['server_token']=json_encode($payment_token);
        $gateway_entry_data['user_id']=$customer_id;
              $gateway_entry_id=$this->Orders_model->payment_gateway_insert($gateway_entry_data);
              ?>

          <html lang="en"><head><script type="application/javascript" src="<?php echo $conf['LAYER_JS']; ?>"></script></head>
          <body>
              <script>
                  trigger_layer();
                  function trigger_layer() {
                      Layer.checkout(
                          {
                              token: "<?php echo $payment_token->id; ?>",
                              accesskey: "<?php echo $conf['ACCESS_KEY']; ?>"
                          },
                          function (response) {

                              //window.location = "<?php echo $conf["APP_HOST"]; ?>" + "http://localhost/response.php?payment_token_id=" + "<?php echo $payment_token->id; ?>"
                          },
                          function (err) {
                              alert(err.message);
                          }
                      );
                  }
              </script>
          </body></html>

        <?php

        } catch (Exception $exception){

            echo "<pre>"; print_r($http->get_last_http_error());
            echo "<pre>"; print_r($exception->getMessage());
        }
      }
      else {
        echo "No cart list";
      }
      exit;

    }

    public function ICICI_india_response()
    {
      //print_r($this->httpRequest);exit;
        require_once 'application/third_party/bankonnect/HttpHandler.php';
        $customer_id=$this->_apiuser->user_id;
        $gateway_entry=$this->Orders_model->getUserLastGatewayDetails($customer_id);
        //print_r($gateway_entry);exit;
        if($gateway_entry['status']=='captured')
        {
          $this->response([TRUE,'success',array('waiting'=>false,'payment'=>true,'payment_id'=>$gateway_entry['id'],'order_id'=>$gateway_entry['bill_master_id'])], REST_Controller::HTTP_OK);
        }
        elseif ($gateway_entry['id']>0) {
          $payment_token_id =$gateway_entry['gateway_id'];
        $http = new HttpHandler();
        try {
              $payment_token_data = $http->_do_get(
              sprintf($payment_token['status']['route'],$payment_token_id)
            );
              if($payment_token_data->status)
              {
                $response_db_data['status']=$payment_token_data->status;
                $response_db_data['response']=json_encode($payment_token_data);
                $this->Orders_model->payment_gateway_update($response_db_data,$gateway_entry['id']);

                if($payment_token_data->status=='captured'){

                  // create order
                  $customer_id=$this->_apiuser->user_id;
                  $processed_by=$customer_id;
                  $payment_gateway=$gateway_entry['price'];
                  $bill_master_Id=$this->bill_gen($customer_id,$processed_by,$payment_gateway);

                  /*update master id in payment details*/
                  $response_db_data_1['bill_master_id']=$bill_master_Id;
                  $this->Orders_model->payment_gateway_update($response_db_data_1,$gateway_entry['id']);

                  $this->response([TRUE,'success',array('waiting'=>false,'payment'=>true,'payment_id'=>$gateway_entry['id'],'order_id'=>$bill_master_Id)], REST_Controller::HTTP_OK);
                }
                {
                  $this->response([TRUE,'Payment failed',array('waiting'=>false,'payment'=>false,'payment_id'=>false)], REST_Controller::HTTP_OK);
                }
                
              }
              else
              {
                $this->response([TRUE,'waiting',array('waiting'=>true,'payment'=>false,'payment_id'=>false)], REST_Controller::HTTP_OK);
              }


          } catch (Exception $exception){
              $this->response([TRUE,'waiting',array('waiting'=>false,'payment'=>false,'payment_id'=>false,'error'=>$http->get_last_http_error().$exception->getMessage())], REST_Controller::HTTP_OK);
              /*echo "<pre>"; print_r($http->get_last_http_error());
              echo "<pre>"; print_r($exception->getMessage());*/

          }
        }
        else {
          $this->response([TRUE,'waiting',array('waiting'=>false,'payment'=>false,'payment_id'=>false,'error'=>'Payment Details not found')], REST_Controller::HTTP_OK);
        }
        
    } 

}
