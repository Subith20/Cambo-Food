<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

// Load the Rest Controller library


class Shops extends MY_Controller {

    public function __construct() {
        parent::__construct();

        // Load the user model
        //$this->load->model('user');
        $this->load->model('Shops_model');
        $this->load->model('Generic_model');
        $this->load->model('Time_sheet_model');
    }

    public function nearShops_post() {
      $request=$this->httpRequest;
      $lat=$request->lat;
      $long=$request->long;
      $group_name=$request->group_name?$request->group_name:'Restaurant';

      $available_time_sheet=$this->Time_sheet_model->currentTimeSheet();
      //echo "<pre>";print_r($available_time_sheet);exit;
      if($lat>0 && $long>0)
      {
        $data=$this->Shops_model->getAllNearShops($lat,$long,$group_name);
      }
      
      if($data!=false)
      {
        foreach ($data as $key=>$value) {
          if(!in_array($value['avail_time'],$available_time_sheet) and $value['avail_time']>0)
          {
            $data[$key]['is_available']=0;
          }
        }
        $this->response([TRUE,'success',$data], REST_Controller::HTTP_OK);
      }
      else {
        $this->response([false,'Service Not Available',array()], REST_Controller::HTTP_OK);
      }
    }


}
