<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Customers extends Iglobe_Controller {

	public function __construct() {
			parent::__construct();
			// Load form helper library
			$this->load->helper('form');
			// Load form validation library
			$this->load->library('form_validation');
			// Load session library

			// Load database
			$this->load->model('Customer_model');
	}

	function __destruct() {
		parent::__destruct();

  }

	public function list($lead_id=null) {
		$request=$this->input->get();
		$data['request']=$request;
		$data['call_lead_detail']=$lead_id;
		$this->smarty->display( 'customers/list.tpl',$data);
	}

	public function CustomerDetails() {
		$user_type=$this->getUser('type');
		$allow_all=array(1,2,3);
		if(!in_array($user_type, $allow_all))
		{
			$this->smarty->display( '404.tpl',$data);
			exit;
		}
			$id=$this->input->post('id');
			if($id>0)
			{
				$customer_data=$this->Customer_model->GetCustomerDetails($id);
				$customer_address=$this->Customer_model->address_list($id);
			}
			$data['customer_data']=$customer_data;
			$data['customer_address']=$customer_address;
			//echo "<pre>";print_r($data['customer_address']);exit;
			$this->smarty->display( 'customers/details.tpl',$data);
	}

	public function update() {
		$request=$this->input->post();
		if(isset($request['name']))
		{
			$this->form_validation->set_rules('name', 'Name', 'required');
		}
		
		$this->form_validation->set_rules('email', 'Email', 'trim|valid_email');
		if ($this->form_validation->run() == FALSE)
        {
            $this->JsonOut(array('message'=>'Invalid Input'),500);
        }

		if($request['id'])
		{
			$Customer_id=$request['id'];
			$changes=$request['changes'];
			unset($request['id']);
			unset($request['ajax']);
			unset($request['changes']);
			$result=$this->Customer_model->update($request,$Customer_id);
			if($result)
			{
				$this->JsonOut(array('message'=>'successfully Saved'));
			}
			else {
				$this->JsonOut(array('message'=>'Invalid Input'),500);
			}
		}
		
		else {

			$this->JsonOut(array('message'=>'Invalid id'),500);
		}
	}


	public function list_datatable()
	{
		$user_type=$this->getUser('type');
		$user_id=$this->getUser('id');
		$edit_btn=FALSE;
		//$request=$this->input->post();
		$allow_all=array(1,2,3);
		if(in_array($user_type, $allow_all))
		{
			$customer_list=$this->Customer_model->GetCustomerList();
			$edit_btn=TRUE;
		}
		else if($user_type==5)
		{
			$customer_list=$this->Customer_model->shop_customers(array('type'=>5,'user_id'=>$user_id));
		}
		
		$result=array();
		foreach ($customer_list as $value) {
			$result[]=array(
				'<span class="list_row" data-id="'.$value['id'].'">'.$value['id'],
				($value['name']?$value['name']:$value['phone']),
				$value['phone'],
				$value['email'],
				'<div class="row-action-btn">
                        '.($edit_btn?'<button type="button" class="btn btn-info" onclick="ShowCustomerDetails('.$value['id'].');"><i class="fas fa-edit"></i></button><button type="button" class="btn btn-danger" onclick="'."CallDeleteModal('calldelete(".$value['id'].")');".'"><i class="fas fa-trash-alt"></i></button>':'').'
                </div>'
			);
		}
		$this->JsonOut($result);
	}

	public function deleted_list_datatable()
	{
		//$request=$this->input->post();
		$customer_list=$this->Customer_model->GetCustomerDeletedList();
		$result=array();
		foreach ($customer_list as $value) {
			$result[]=array(
				'<span class="list_row" data-id="'.$value['id'].'">'.$value['id'],
				($value['name']?$value['name']:$value['phone']),
				$value['phone'],
				$value['email'],
				'<div class="row-action-btn">
                        <button type="button" class="btn btn-success" onclick="'."movetolive('".$value['id']."');".'"> Live</button>
                </div>'
			);
		}
		$this->JsonOut($result);
	}

	public function index()
	{
		$this->list();

	}

	public function delete($id)
	{
		$data=array('deleted'=>1);
		$result=$this->Customer_model->update($data,$id);
		echo '<script>window.location.href="'.base_url().'customers";</script>';
		exit;

	}

	public function move_to_live($id)
	{
		$data=array('deleted'=>0);
		$result=$this->Customer_model->update($data,$id);
		echo '<script>window.location.href="'.base_url().'customers/?deleted=true";</script>';
		exit;

	}


}
