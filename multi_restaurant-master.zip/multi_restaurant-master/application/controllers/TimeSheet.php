<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class TimeSheet extends Iglobe_Controller {

	public function __construct() {
			parent::__construct();
			// Load form helper library
			$this->load->helper('form');
			// Load form validation library
			$this->load->library('form_validation');
			// Load session library

			// Load database
			$this->load->model('User_model');
			$this->load->model('Generic_model');
			$this->load->model('Time_sheet_model');
	}

	function __destruct() {
		parent::__destruct();

  }

	public function list() {
		$data['user_type']=$this->getUser('type');
		if($data['user_type']==1)
		{
			$data['list']=$this->Time_sheet_model->GetTimeDatatable();
		}
		else {
			$data['list']=$this->Time_sheet_model->GetTimeDatatable($this->getUser('id'));
		}
		
		$this->smarty->display('time_sheet/list.tpl',$data);
	}

	public function time_sheet_group_details($id=0)
	{
		$data['user_type']=$this->getUser('type');
		if($data['user_type']==1)
		{
			$data['user_list']=$this->User_model->getManager();
		}
		else {
			$data['user_list'][]=array("id"=>$this->getUser('id'),"first_name"=>$this->getUser('first_name'),"phone"=>$this->getUser('phone'));
		}
		if($id>0)
		{
			

			$data['timeSheet_select_day']=$this->Time_sheet_model->timeSheet_select_day();

			$data['sheet_time_data']=$this->Time_sheet_model->sheet_time_data($id);

			$data['data']=$this->Time_sheet_model->GetDetails($id);
			
		}
		//echo "<pre>";print_r($data);exit;
		$data['timeSheet_select_list']=$this->Time_sheet_model->timeSheet_select_list();
		$this->smarty->display( 'time_sheet/time_sheet_group_details.tpl',$data);
	}


	public function saveTimeSheet()
	{
		$request=$this->input->post();
		unset($request['ajax']);
		$id=$request['id'];
		unset($request['id']);
		$sheet_data=json_decode($request['sheet_data']);
		unset($request['sheet_data']);
		$this->form_validation->set_rules('name', 'Name', 'required');
		if ($this->form_validation->run() == FALSE)
        {
            $this->JsonOut(array('message'=>validation_errors()),500); 
        }

        //echo "<pre>";print_r($sheet_data);exit;
        if($id>0)
        {
        	$insert_id=$this->Time_sheet_model->update($request,$id);
        }
        else {
        	$insert_id=$this->Time_sheet_model->new($request);
        }
		

		if($insert_id)
		{
			if($id>0)
			{
				$sheet_table_data_tmp=$this->Time_sheet_model->sheet_time_data($id);
				foreach ($sheet_table_data_tmp as $value) {
					$sheet_table_data[$value['short_code']]=$value['id'];
				}

				//echo "<pre>";print_r($sheet_data);exit;
				foreach ($sheet_data as $value) {
					if($sheet_table_data[$value->short_code])
					{
						unset($sheet_table_data[$value->short_code]);
					}
					else {
						$time['group_id']=$id;
						$time['to']=$value->to;
						$time['from']=$value->from;
						$time['day']=$value->day;
						$time['short_code']=$value->short_code;
						$this->Time_sheet_model->newTime($time);
					}
					
				}
				foreach ($sheet_table_data as $value) {
					$this->Time_sheet_model->DeleteTime($value);
				}
				//echo "<pre>";print_r($sheet_table_data);exit;

			}
			

			$this->JsonOut(array('message'=>'Added','insert_id'=>$insert_id));
		}
		else {
			$this->JsonOut(array('message'=>'Server Error'),500);
		}
	}

	public function TimeSheetStatusUpdate()
	{

		$request=$this->input->post();
		$id=$request['id'];
		if($id>0)
        {
        	$request_data['id']=$id;
        	$request_data['status']=$request['status']?$request['status']:0;
        	$result=$this->Time_sheet_model->update($request_data,$id);
        	$this->JsonOut(array('message'=>'Updated'));
        }
        else {
        	$this->JsonOut(array('message'=>'Invalid Input'),500);
        }
	}

	public function TimeSheetDelete()
	{
		$request=$this->input->post();
		if($request['id']>0)
		{
			$result = $this->Time_sheet_model->sheetDelete($request['id']);

			if($result)
			{
				$this->JsonOut(array('message'=>'Deleted','insert_id'=>$insert_id));
			}
			else {
				$this->JsonOut(array('message'=>'Server Error'),500);
			}
		}
		$this->JsonOut(array('message'=>'invalid input'),500);
	}


	public function index()
	{
		$this->list();

	}
}
