<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

// Load the Rest Controller library


class Products extends MY_Controller {

    public function __construct() {
        parent::__construct();

        // Load the user model
        //$this->load->model('user');
        $this->load->model('Products_model');
        $this->load->model('Shops_model');
        $this->load->helper('form');
      // Load form validation library
      $this->load->library('form_validation');
        // Load form validation library

    }

    public function shopProductlist_get($shop_id=0) {
      $user_id=$this->_apiuser->user_id;
      $request['shop_id'] = $shop_id;
      $request['extras'] = true;
      $request['is_avail']='all';
      $request['extras_type']='all';
      $request['page'] = $this->post('page')>0?$this->post('page'):1;

      if($request['shop_id']>0)
      {
          $checkOwnerPermission=$this->Shops_model->checkOwnerPermission($user_id,$shop_id);

          if($checkOwnerPermission==false)
          {
            $this->response([false,'shop Permission Denied',false], REST_Controller::HTTP_OK);
          }

          $category_list=$this->Products_model->GetRestProductList($request);
          $shops['category_list']=$category_list?$category_list:array();
          $data=$shops?$shops:array();
          $this->response([TRUE,'success',$data], REST_Controller::HTTP_OK);
      }
      else {
        $this->response([false,'Invalid input',array()], REST_Controller::HTTP_OK);
      }
      
    }

  public function shopProductlistDetails_get($id=0)
  {
    $user_id=$this->_apiuser->user_id;
    if($id>0)
    {
      $details=$this->Products_model->myProductDetails($user_id,$id);
    }
    
    if($details)
    {
        $details['extras_group']=array();
        $extras=$this->Products_model->GetProductExtras($details['id']);
        $extras_group=$this->Products_model->GetProductExtrasGroup($details['id']);
        $data['extras_group_type']=$this->config->item('extras_group_type');

        foreach ($extras_group as $value) {

          $value['extras']=array();
          foreach ($extras as $extra_key=>$extra_value) {
            if($extra_value['group_id']==$value['id'])
            {
              $value['extras'][$extra_value['id']]=$extra_value;
              unset($extras[$extra_key]);
            }
          }
          $details['extras_group'][$value['id']]=$value;
          
        }

        $details['extras_group']=array_values($details['extras_group']);


        $this->response([TRUE,'success',$details], REST_Controller::HTTP_OK);
    }
    else {
        $this->response([false,'Invalid input',array()], REST_Controller::HTTP_OK);
    }

  }

  public function new_post()
  {
    $request=$this->input->post();
    $user_id=$this->_apiuser->user_id;
    unset($request['product_img']);
    $checkOwnerPermission=$this->Shops_model->checkOwnerPermission($user_id,$request['shop_id']);

    if($checkOwnerPermission==false)
    {
      $this->response([false,'shop Permission Denied',false], REST_Controller::HTTP_OK);
    }

    $this->form_validation->set_rules('name', 'Name', 'required');
    $this->form_validation->set_rules('shop_id', 'shop', 'required|integer');
    $this->form_validation->set_rules('category_id', 'Category', 'required|integer');
    $this->form_validation->set_rules('mrp', 'MRP', 'required|numeric');
    $this->form_validation->set_rules('sale_price', 'Sale Price', 'numeric');
    $this->form_validation->set_rules('tax', 'Tax', 'numeric');
    if ($this->form_validation->run() == FALSE)
    {
      $this->response([false,'Invalid Data',validation_errors()], REST_Controller::HTTP_OK);
    }

    $insert_id=$this->Products_model->new($request);

    if($insert_id>0)
    {
      if($_FILES['product_img']['name'])
      {

        $file_data['check_file_type']="image"; // image, PDF, Document
        $file_data['model_type']="products";// user, asset, lead, product, service
        $file_data['related_id']=$insert_id;
        $file_data['input_name']="product_img"; // $_FILE name
        $file_data['display_name']=preg_replace("/[^a-zA-Z]+/", "_", $request['name']);
        $upload_result['product_img']=$this->fileUploader($file_data);
      }
    }

    if($insert_id)
    {
      $this->response([true,'success',array('insert_id'=>$insert_id)], REST_Controller::HTTP_OK);
    }
    else {
      $this->response([false,'Server Error',array()], REST_Controller::HTTP_OK);
    }

  }

  public function update_post()
  {
    $request=$this->input->post();
    $user_id=$this->_apiuser->user_id;
    $id=$request['id'];
    unset($request['product_img']);
    if($id>0)
    {
      $product_details=$this->Products_model->myProductDetails($user_id,$id);
      if($product_details==false)
      {
        $this->response([false,'Product Permission Denied',false], REST_Controller::HTTP_OK);
      }

      $checkOwnerPermission=$this->Shops_model->checkOwnerPermission($user_id,$request['shop_id']);

      if($checkOwnerPermission==false)
      {
        $this->response([false,'shop Permission Denied',false], REST_Controller::HTTP_OK);
      }

      $this->form_validation->set_rules('id', 'Product id', 'required');
      $this->form_validation->set_rules('name', 'Name', 'required');
      $this->form_validation->set_rules('shop_id', 'shop', 'required|integer');
      $this->form_validation->set_rules('category_id', 'Category', 'required|integer');
      $this->form_validation->set_rules('mrp', 'MRP', 'required|numeric');
      $this->form_validation->set_rules('sale_price', 'Sale Price', 'numeric');
      $this->form_validation->set_rules('tax', 'Tax', 'numeric');
      if($this->form_validation->run() == FALSE)
      {
        $this->response([false,'Invalid Data',validation_errors()], REST_Controller::HTTP_OK);
      }

      $is_update=$this->Products_model->update($request,$id);

      if($is_update)
      {
        if($_FILES['product_img']['name'])
        {
          $this->RemoveUploadFiles('all','products',$product_details['id']);
         
          $file_data['check_file_type']="image"; // image, PDF, Document
          $file_data['model_type']="products";// user, asset, lead, product, service
          $file_data['related_id']=$product_details['id'];
          $file_data['input_name']="product_img"; // $_FILE name
          $file_data['display_name']=preg_replace("/[^a-zA-Z]+/", "_", $request['name']);
          $product_img=$this->fileUploader($file_data);
        }
      }

      if($is_update)
      {
        $product_details=$this->Products_model->myProductDetails($user_id,$id);
        $this->response([true,'success',$product_details], REST_Controller::HTTP_OK);
      }
      else {
        $this->response([false,'Server Error',false], REST_Controller::HTTP_OK);
      }
    }
    else
    {
      $this->response([false,'Invalid Product Id',false], REST_Controller::HTTP_OK);
    }
  }

  public function statusUpdate_post()
  {
    $request=$this->input->post();
    $user_id=$this->_apiuser->user_id;
    $id=$request['id'];
    $status=$request['is_avail']?1:0;
    if($id>0)
    {
      $product_details=$this->Products_model->myProductDetails($user_id,$id);
      if($product_details==false)
      {
        $this->response([false,'Product Permission Denied',false], REST_Controller::HTTP_OK);
      }


      $is_update=$this->Products_model->update(array('is_avail'=>$status),$id);

      if($is_update)
      {
        $product_details=$this->Products_model->myProductDetails($user_id,$id);
        $this->response([true,'success',$product_details], REST_Controller::HTTP_OK);
      }
      else {
        $this->response([false,'Server Error',false], REST_Controller::HTTP_OK);
      }
    }
    else
    {
      $this->response([false,'Invalid Product Id',false], REST_Controller::HTTP_OK);
    }
  }

  public function delete_get($id=0) {
    $user_id=$this->_apiuser->user_id;
    if($id>0)
    {
      $product_details=$this->Products_model->myProductDetails($user_id,$id);
      if($product_details==false)
      {
        $this->response([false,'Product Permission Denied',false], REST_Controller::HTTP_OK);
      }
      else
      {
        $result = $this->Products_model->delete($product_details['id']);
        if($result)
        {
          $this->RemoveUploadFiles('all','products',$product_details['id']);
          $this->response([true,'Deleted',array()], REST_Controller::HTTP_OK);
        }
        else
        {
          $this->response([false,'Server error',false], REST_Controller::HTTP_OK);
        }
        
      }
    }
    else
    {
      $this->response([false,'Invalid Product Id',false], REST_Controller::HTTP_OK);
    }

  }

  public function removeProductImage_get($id=0) {
    $user_id=$this->_apiuser->user_id;
    if($id>0)
    {
      $product_details=$this->Products_model->myProductDetails($user_id,$id);
      if($product_details==false)
      {
        $this->response([false,'Product Permission Denied',false], REST_Controller::HTTP_OK);
      }
      else
      {
          $this->RemoveUploadFiles('all','products',$product_details['id']);
          $this->response([true,'Image Deleted',array()], REST_Controller::HTTP_OK);
       
      }
    }
    else
    {
      $this->response([false,'Invalid Product Id',false], REST_Controller::HTTP_OK);
    }

  }


  public function GetCategory_get() {
      $CatList=$this->Products_model->GetProductCat();
      if ($CatList) {
          $this->response([TRUE,'success',$CatList], REST_Controller::HTTP_OK);
      }
      else {
        $this->response([TRUE,'No Data',array()], REST_Controller::HTTP_OK);
      }

  }

  public function ProductAddSettings_get() {
      $data['status']=array(0=>'Inactive',1=>'Active');
      $data['type']=$this->Products_model->GetProduct_type();
      $data['unit_list']=$this->Products_model->UnitsList();
      if ($data) {
          $this->response([TRUE,'success',$data], REST_Controller::HTTP_OK);
      }
      else {
        $this->response([TRUE,'No Data',array()], REST_Controller::HTTP_OK);
      }

  }


}
