<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

// Load the Rest Controller library


class Tickets extends MY_Controller {

    public function __construct() {
        parent::__construct();

        // Load the user model
        $this->load->model('Generic_model');
        $this->load->model('Tickets_model');

    }

    public function GetCustomerTickets_post() {
      $request=$this->httpRequest;
      $params['from']=$request->form;
      $params['to']=$request->to;
      $params['customer_id']=$this->_apiuser->user_id;
      $params['ticket_status']=$request->ticket_status;
      $list=$this->Tickets_model->GetCustomerTickets($params);
      if($list!=false)
      {
        $this->response([TRUE,'success',$list], REST_Controller::HTTP_OK);
      }
      else {
        $this->response([false,'No Data',array()], REST_Controller::HTTP_OK);
      }
    }



    public function NewCustomerTickets_post() {
      $request=$this->httpRequest;
      $params['customer_id']=$this->_apiuser->user_id;
      $params['order_id']=$this->httpRequest->order_id;
      $params['details']=$request->details;
      $result=$this->Tickets_model->NewTicket($params);
      if($result!=false)
      {
        $this->response([TRUE,'success',array()], REST_Controller::HTTP_OK);
      }
      else {
        $this->response([false,'No Data',$data], REST_Controller::HTTP_OK);
      }
    }


}
