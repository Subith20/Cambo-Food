<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');


class User extends MY_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('User_model');
		/*$this->load->model('Generic_model');
		$this->load->model('Settings_model');*/
	}


	public function details_get()
    {
      $user_id=$this->_apiuser->user_id;
      $result=$this->User_model->Details($user_id);
      if ($result) 
      {
        $this->response([true,'Success',$result], REST_Controller::HTTP_OK);
      }
      else {
        $this->response([false,'Server error',array('request'=>$this->httpRequest)], REST_Controller::HTTP_OK);
      }
    }
   

	public function update_post() {
		$data=$this->httpRequest;
		$Customer_id=$this->_apiuser->user_id;
		$result=$this->Customer_model->update($data,$Customer_id);
		if($result!=false)
		{	$customer_data=$this->Customer_model->GetCustomerDetails($Customer_id);
		    $this->response([TRUE,'success',$customer_data], REST_Controller::HTTP_OK);
        }
		else
		{
		    $this->response([TRUE,'No Data',array()], REST_Controller::HTTP_OK);
		}

	}


}
