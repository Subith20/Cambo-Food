<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

// Load the Rest Controller library


class Orders extends MY_Controller {

    public function __construct() {
        parent::__construct();

        // Load the user model
        
        $user_type= $this->_apiuser->user_type;
        if($user_type!=5)
        {
            $this->response([false,'Access Denied',array()], REST_Controller::HTTP_OK);
        }
        $this->load->model('Orders_model');

    }


    public function list_get() {
      $user_id=$this->_apiuser->user_id;
      $order_list=$this->Orders_model->GetOrdertList(array('manager_id'=>$user_id));
      if($order_list!=false)
      {
          $this->response([TRUE,'success',$order_list], REST_Controller::HTTP_OK);
      }
      else {
          $this->response([false,'No Data',array()], REST_Controller::HTTP_OK);
      }
    }

    public function statusUpdate_post() {
      
      $user_id=$this->_apiuser->user_id;
      $order_id=$this->httpRequest->order_id;
      $status=$this->httpRequest->status;
      $status_list_details=$this->Orders_model->OrderStatus($this->_apiuser->user_type);
      foreach ($status_list_details as $value) {
        $status_list[]=$value['id'];
      }
      
      $order_detail=$this->Orders_model->checkManagerOrder(array('manager_id'=>$user_id,'id'=>$order_id));
      //print_r($order_detail);
      if($order_detail['id'])
      {
        if(($order_detail['status']==1 or $order_detail['status']==2) and (in_array($status, $status_list)))
        {
          $is_update=$this->Orders_model->status_update($order_detail['id'],$status);
          $this->response([TRUE,'updated',array()], REST_Controller::HTTP_OK);
        }
        else {
          $this->response([false,'invalid status',array()], REST_Controller::HTTP_OK);
        }
          
      }
      else {
          $this->response([false,'No Data',array()], REST_Controller::HTTP_OK);
      }
    }

    public function GetOrderStatus_get()
    {
        $status_list_details=$this->Orders_model->OrderStatus($this->_apiuser->user_type);
        $this->response([TRUE,'order_status',$status_list_details], REST_Controller::HTTP_OK);
    }

    public function GetOrderDetail_get($order_id) {
      $user_id=$this->_apiuser->user_id;
      $order_detail=$this->Orders_model->GetOrderDetail(array('manager_id'=>$user_id,'id'=>$order_id));

      if(is_array($order_detail))
      {
          $this->response([TRUE,'success',$order_detail], REST_Controller::HTTP_OK);
      }
      else {
          $this->response([TRUE,'No Data',array()], REST_Controller::HTTP_OK);
      }
    }
}
