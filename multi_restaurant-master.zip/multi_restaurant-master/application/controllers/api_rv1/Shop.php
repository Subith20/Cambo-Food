<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

// Load the Rest Controller library


class Shop extends MY_Controller {

    public function __construct() {
        parent::__construct();

        // Load the user model
        //$this->load->model('user');
        $this->load->model('Shops_model');
        $this->load->model('Generic_model');
    }

    public function myShop_get() {
      $user_id=$this->_apiuser->user_id;


      if($user_id>0)
      {
        $shop_list=$this->Shops_model->myShopList($user_id);
        foreach ($shop_list as $value) {
            
        }
        
        $this->response([TRUE,'success',$shop_list], REST_Controller::HTTP_OK);
      }
      else {
        $this->response([false,'Invalid input',array()], REST_Controller::HTTP_OK);
      }
    }
/*
    public function update_post($id=null) {
      $user_id=$this->_apiuser->user_id;

      if($user_id>0)
      {

        $this->response([TRUE,'success',$data], REST_Controller::HTTP_OK);
      }
      else {
        $this->response([false,'Invalid input',array()], REST_Controller::HTTP_OK);
      }
    }*/

    public function status_post() {
      $id=$this->httpRequest->shop_id;
      $status=$this->httpRequest->status;
      $user_id=$this->_apiuser->user_id;
      $status=$status==1?1:0;
      //echo $status;exit;
      if($user_id>0 && $id>0)
      {
        $result=$this->Shops_model->myShopStatusUpdate($id, $user_id, $status);
        if($result)
        {
          $this->response([TRUE,'success',array()], REST_Controller::HTTP_OK);
        }else {
          $this->response([false,'Permission denied ',array()], REST_Controller::HTTP_OK);
        }
        
      }
      else {
        $this->response([false,'Invalid input',array()], REST_Controller::HTTP_OK);
      }
    }


}
