<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Banner extends Iglobe_Controller {

	public function __construct() {
			parent::__construct();
			// Load form helper library
			$this->load->helper('form');
			// Load form validation library
			$this->load->library('form_validation');
			// Load session library
			
			// Load database
			$this->load->model('Banner_model');
			$this->load->model('Generic_model');

	}

	function __destruct() {
		parent::__destruct();

  }

	public function list() {

		$list=$this->Banner_model->GetList();
		//$data['list']=$list;
		foreach ($list as $value) {
			$data_file_data=$this->Generic_model->UploadFilesList('banner',$value['id']);
			$value['image']=reset($data_file_data);
			$data['data'][]=$value;
		}
		//echo "<pre>";print_r($data['list']);exit;
		$this->smarty->display( 'banner/list.tpl',$data);
	}

	public function new_form($id=null) {
			if($id>0)
			{
				$details=$this->Banner_model->GetBannerDetails($id);
				$data_file_data=$this->Generic_model->UploadFilesList('banner',$id);
				$data['images']=reset($data_file_data);
			}
			$data['data']=$details;
			$data['base_url']=base_url();
			//echo "<pre>";print_r($data);exit;
			$this->smarty->display( 'banner/details.tpl',$data);
	}

	public function delete($id=null) {

			if($id>0)
			{

				$result=$this->Banner_model->Delete($id);
				$this->RemoveUploadFiles('all','banner',$id);
			}
			$this->JsonOut(array('message'=>'success'));
	}


	public function update() {

		$inputdata=$this->input->post();
		
		//print_r($inputdata);exit;
		$this->form_validation->set_rules('name', 'Banner Name', 'required');
		$this->form_validation->set_rules('from', 'From Date', 'required');
		$this->form_validation->set_rules('to', 'To Date', 'required');


		$id=$inputdata['id'];
		$is_ajax=$inputdata['ajax'];
		unset($inputdata['image']);
		unset($inputdata['ajax']);

		if ($this->form_validation->run() == FALSE)
		{
		    $this->JsonOut(array('message'=>validation_errors()),500); 
		}
		if($id>0)
		{

			$this->Banner_model->update($inputdata);
		}
		else
		{
			unset($inputdata['id']);
			$insert_id=$this->Banner_model->new($inputdata);
		}

		$data_id=$id>0?$id:$insert_id;
		if($data_id>0)
		{
			if($_FILES['image']['name'])
			{
				$file_data['check_file_type']="image"; // image, PDF, Document
				$file_data['model_type']="banner";// user, asset, lead, product, service
				$file_data['related_id']=$data_id;
				$file_data['input_name']="image"; // $_FILE name
				$file_data['display_name']=preg_replace("/[^a-zA-Z]+/", "_", $request['name']);
				$upload_result['product_img']=$this->fileUploader($file_data);
			}
		}

		if($is_ajax)
		{
			if($insert_id)
			{
				$this->JsonOut(array('message'=>'success'));
			}
			else {
				$this->JsonOut(array('message'=>'Error'));
			}
			
		}
		echo "<script>window.location.href='/banner/list/';</script>";exit;
		//$this->list();
	}

	


	public function index()
	{
		$this->list();
	}

	public function RemoveImage()
	{
		$request=$this->input->post();
		if(!$request['banner_id'] || !$request['id'])
		{
			$this->JsonOut(array('message'=>'invalid input'),500);
		}
		else {

			$this->RemoveUploadFiles($request['id'],'banner',$request['banner_id']);
			$this->JsonOut(array('message'=>'success'));
		}
	}
}
