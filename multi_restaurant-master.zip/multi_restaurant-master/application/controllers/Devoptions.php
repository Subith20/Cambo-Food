<?php
defined('BASEPATH') OR exit('No direct script access allowed');

session_start(); //we need to start session in order to access it through CI
class Devoptions extends Iglobe_Controller {

	public function __construct() {
			parent::__construct();
			// Load form helper library
			$this->load->helper('form');

			// Load form validation library
			$this->load->library('form_validation');
			// Load session library
			// Load database
			$this->load->model('Settings_model');

	}

	function __destruct() {
    parent::__destruct();
  }


	public function index()
	{
		$domainName = $_SERVER['HTTP_HOST'];
		$ip_server = $_SERVER['SERVER_ADDR']; 
		if($this->session->userdata['logged_in']['id']==1 && $domainName=='localhost' && $ip_server=='127.0.0.1')
		{
			/*$list=$this->Settings_model->list();
			foreach ($list as $value) {
					$value['data_type_option']=json_decode($value['data_type_option']);
					$value['data_type_option']=(array)$value['data_type_option'];
					$data_list[$value['type']][]=$value;
				}*/
			//echo "<pre>";print_r($data);exit;

			$data['base_url']=base_url();
			$this->load->view('DevOption.tpl',$data);
				
			
		}
		else {
			echo "Access Denied";
		}
		
	}



	public function create_update_file()
	{
		$domainName = $_SERVER['HTTP_HOST'];
		$ip_server = $_SERVER['SERVER_ADDR']; 
		if($this->session->userdata['logged_in']['id']==1 && $domainName=='localhost' && $ip_server=='127.0.0.1')
		{
			$request=$this->input->post();
			$update_file_list=preg_split('/\r\n|[\r\n]/', $request['update_file_list']);	
			//echo "<pre>";print_r($update_file_list);exit;
			$sql_file_name = 'update.sql';
			$sql_data = $request['update_query_list'];
			$this->load->library('zip');

			if($sql_data)
			{
				$this->zip->add_data($sql_file_name, $sql_data);
			}
			

			foreach ($update_file_list as $filename) {
				if(file_exists($filename))
				{
					$this->zip->read_file($filename,true);
				}
				
			}
			$today = date("Ymd_His");
			$this->zip->download('restarent_update_'.$today.'.zip');
			exit;


		}
		else {
			echo "Access Denied";
		}
		
	}
}
