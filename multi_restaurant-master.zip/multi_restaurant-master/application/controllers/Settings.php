<?php
defined('BASEPATH') OR exit('No direct script access allowed');

session_start(); //we need to start session in order to access it through CI
class Settings extends Iglobe_Controller {

	public function __construct() {
			parent::__construct();
			// Load form helper library
			$this->load->helper('form');

			// Load form validation library
			$this->load->library('form_validation');
			// Load session library
			// Load database
			$this->load->model('Settings_model');

	}

	function __destruct() {
    parent::__destruct();
  }


	public function index()
	{

		if($this->session->userdata['logged_in']['type']==1)
		{
			$list=$this->Settings_model->list();
			foreach ($list as $value) {
					$value['data_type_option']=json_decode($value['data_type_option']);
					$value['data_type_option']=(array)$value['data_type_option'];
					$data_list[$value['type']][]=$value;
				}
			//echo "<pre>";print_r($data);exit;
			$lhs_cout=0;
			$rhs_cout=0;
			foreach ($data_list as $key=>$value) {
				if($lhs_cout<=$rhs_cout)
				{
					$data['list1'][$key]=$value;
					$lhs_cout+=count($value);
				}
				else
				{
					$data['list2'][$key]=$value;
					$rhs_cout+=count($value);
				}
					
			}

			$data['base_url']=base_url();
			$this->load->view('crm_settings.tpl',$data);
				
			
		}
		else {
			echo "Access Denied";
		}
		
	}

	public function update()
	{
		if($this->session->userdata['logged_in']['type']==1)
		{
			$request=$this->input->post();
			foreach ($request as $key=>$value) {
				$post_data['id']=$key;
				$post_data['value']=$value;
				$this->Settings_model->update($post_data);
			}
			echo "<pre>";//print_r($request['44']);
						// update payment mode (on/off)
			if(isset($request['44']))
			{
				//PayWay
				$this->Settings_model->PaymentModeUpdate(4,$request['44']);
			}
			if(isset($request['45']))
			{
				//ABA pay
				$this->Settings_model->PaymentModeUpdate(5,$request['45']);
			}

			if(isset($request['46']))
			{
				//COD pay
				$this->Settings_model->PaymentModeUpdate(1,$request['46']);
			}

			echo "<script>window.location.href ='".base_url()."settings/';</script>";
		}
		else {
			echo "Access Denied";
		}
		
	}

	public function ShopStatusUpdate($status)
	{
		$this->is_admin();
		$result=$this->Settings_model->shop_status_update($status);
		$this->JsonOut(array('status'=>$result));
	}

	public function ShippingPriceList()
	{
		
		if($this->session->userdata['logged_in']['type']==1)
		{
			$data['distance_unit']= $this->config->item('distance_unit');
			$data['list']=$this->Settings_model->shipping_price_list();
			$this->smarty->display( 'shipping/list.tpl',$data);
		}
		else {
			echo "Access Denied";
		}
	}

	public function ShippingPriceDelete($id)
	{
		if($this->session->userdata['logged_in']['type']==1)
		{
			$data['list']=$this->Settings_model->shipping_price_delete($id);
			echo "<script>window.location.href ='".base_url()."settings/ShippingPriceList';</script>";
		}
		else {
			echo "Access Denied";
		}
	}

	public function ShippingPriceDetails() {
		$request=$this->input->post();
		if($request['id']>0)
		{
			$datails=$this->Settings_model->shipping_price_details($request['id']);
		}
		$data['data']=$datails;
		$data['distance_unit']= $this->config->item('distance_unit');
		//echo "<pre>";print_r($data);exit;
		$this->smarty->display( 'shipping/details.tpl',$data);
	}

	public function db_backup()
	{
		$request=$this->input->get();
		if($this->session->userdata['logged_in']['type']==1)
		{
			$today = date("Ymd_His");
			// Load the DB utility class
			$this->load->dbutil();
			$prefs = array(
			        'format'        => 'txt',                       // gzip, zip, txt
			        'filename'      => 'db.sql',              // File name - NEEDED ONLY WITH ZIP FILES
			        'add_drop'      => TRUE,                        // Whether to add DROP TABLE statements to backup file
			        'add_insert'    => TRUE,                        // Whether to add INSERT data to backup file
			        'newline'       => "\n"                         // Newline character used in backup file
			);
			// Backup your entire database and assign it to a variable
			$backup = $this->dbutil->backup($prefs);
			//$this->load->helper('download');
			//force_download($prefs['filename'], $backup);

			// Load the file helper and write the file to your server
			//$this->load->helper('file');
			//write_file($prefs['filename'], $backup);
			// Load the download helper and send the file to your desktop
			
			$this->load->library('zip');
			//$this->zip->add_data('mybackup.sql');
			//echo $prefs['filename'];exit;
			$this->zip->read_file($prefs['filename']);
			$this->zip->read_dir('storage',true);
			if($request['local_backup']==true)
			{
				$this->zip->archive('multi_shops_crm_last_backup.zip');
			}

			$this->zip->download('multi_shops_crm_backup_'.$today.'.zip');
			exit;

			
		}
		else {
			echo "Access Denied";
		}
	}

	public function appUpdate()
	{
		echo '<div style="padding: 30px;text-transform: uppercase;">';
		if($this->session->userdata['logged_in']['type']==1)
		{
			if (!is_dir('update')) {
		     mkdir('update', 0755, TRUE);
			}

			if (file_exists('update.sql')) {
			   unlink('update.sql');
			}

			$last_update=$this->Settings_model->updated_list();
			$last_update=$last_update['last_update'];
			//echo "<pre>";print_r($last_update);exit;
			$update_server_url=$this->config->item('crm_update_url');
			$data = file_get_contents($update_server_url);
			$update_list = json_decode($data, true);
			if($update_list[$last_update])
			{
				$full_path=$update_server_url.$update_list[$last_update];
				$filename = substr($full_path, strrpos($full_path, '/') + 1);
				file_put_contents('update/'.$filename, file_get_contents($full_path));
				$zip = new ZipArchive;
				if ($zip->open('update/'.$update_list[$last_update]) === TRUE) 
		        {
		            $download_update=$zip->extractTo('.');
		            $zip->close();
		        }

		        $sql = file_get_contents("update.sql");
				$sqls = explode(';', $sql);
				array_pop($sqls);
				foreach($sqls as $statement){
					$sql_query_number+=1;
					if (!$this->Settings_model->crm_updates($statement))
					{
						echo 'Query faild line :'.$sql_query_number.'<br>';
					}
				      
				}
				echo 'sql update<br>';
		        if($download_update)
		        {
		        	echo "files updated";
		        	$insert = $this->db->insert('crm_updates', array('filename'=>$update_list[$last_update]));
		        }
			}
			else {
				echo "there are not update available";
			}
		}
		else {
			echo "Access Denied";
		}
		echo '</div>';
	}

	public function ShippingPriceupdate()
	{
		if($this->session->userdata['logged_in']['type']==1)
		{
			$request=$this->input->post();
			$id=$request['id'];
			unset($request['ajax']);
			unset($request['id']);
			$this->form_validation->set_rules('distance', 'Shipping Distance', 'required|numeric');
			$this->form_validation->set_rules('price', 'Shipping Price', 'required|numeric');
			if ($this->form_validation->run() == FALSE)
	        {
	            $this->JsonOut(array('message'=>validation_errors()),500); 
	        }
			if($id>0)
			{
				$is_update=$this->Settings_model->shipping_price_update($request,$id);
			}
			else {
					$insert_id=$this->Settings_model->shipping_price_insert($request);
			}

			if($insert_id)
			{
				$this->JsonOut(array('message'=>'updated','insert_id'=>$insert_id));
			}
			else {
				$this->JsonOut(array('message'=>'success'));
			}
		}
		else {
			echo "Access Denied";
		}
		

	}
}
