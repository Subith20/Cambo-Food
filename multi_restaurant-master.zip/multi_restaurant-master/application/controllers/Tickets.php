<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Tickets extends Iglobe_Controller {

	public function __construct() {
			parent::__construct();
			// Load form helper library
			$this->load->helper('form');
			// Load form validation library
			$this->load->library('form_validation');
			// Load session library

			// Load database
			$this->load->model('Customer_model');
			$this->load->model('User_model');
			$this->load->model('Generic_model');
			$this->load->model('Tickets_model');
	}

	function __destruct() {
		parent::__destruct();

  }

	public function list($myticket=null) {
		$request=$this->input->post();
		if($myticket=='my')
		{
			$request['FL_assign_to']=$this->session->userdata['logged_in']['id'];;
		}
		if(!isset($request['FL_ticket_status']))
		{
			$request['FL_ticket_status']=1;
		}
		if(!isset($request['FL_ticket_type']))
		{
			$request['FL_ticket_type']=1;
		}
		$ticket_list=$this->Tickets_model->GetTicketList($request);
		//$assign_to=$this->User_model->getAssign_to();
		$ticket_status=$this->Tickets_model->ticket_status();
		//$ticket_type=$this->Tickets_model->ticket_type();

		$data['request']=$request;
		$data['data']=$ticket_list;
		//$data['assign_to']=$assign_to;
		$data['ticket_status']=$ticket_status;
		//$data['ticket_type']=$ticket_type;
		/*echo "<pre>";
		print_r($data['data'][0]);exit;*/
		$this->smarty->display( 'tickets/list.tpl',$data);
	}

	public function TicketDetails() {
			$id=$this->input->post('id');
			$customer_id=$this->input->post('customer_id');

			if($id>0)
			{
				$ticket_data=$this->Tickets_model->GetTicketDetails($id);
			}elseif ($customer_id>0) {
				$customer_data=$this->Customer_model->GetCustomerDetails($customer_id);
				$ticket_data['lead_id']=$customer_data['id'];
				$ticket_data['lead_name']=$customer_data['name'];
				$ticket_data['lead_phone']=$customer_data['phone'];
				$ticket_data['lead_phone2']=$customer_data['phone2'];
			}


			$assign_to=$this->User_model->getAssign_to();
			$ticket_status=$this->Tickets_model->ticket_status();
			$ticket_type=$this->Tickets_model->ticket_type();
			$ticket_priority=$this->Tickets_model->ticket_priority();

			$ServicesCat_rq['name_only']=TRUE;
			$ServicesCat_rq['status']='all';
			$ServicesCat_rq['crm_only']=1;

			$data['request']=$request;
			$data['data']=$ticket_data;
			$data['assign_to']=$assign_to;
			$data['ticket_status']=$ticket_status;
			$data['ticket_type']=$ticket_type;
			$data['history']=$this->Tickets_model->getTicketHistory($id);
			//echo "<pre>";print_r($data['history'][0]);echo "</pre>";exit;
			$this->smarty->display( 'tickets/details.tpl',$data);
	}


	public function update() {
		$request=$this->input->post();
		$user_id=$this->session->userdata['logged_in']['id'];
		$changes=$request['changes'];
		$ticket_id=$request['id'];
		$customer_id=$request['customer_id'];
		$notes=$request['notes'];
		unset($request['ajax']);
		unset($request['changes']);
		unset($request['id']);
		unset($request['notes']);
		unset($request['customer_id']);

		$history_request['related_table']=1;
		$history_request['related_id']=$ticket_id;
		$history_request['notes']=$changes;
		$history_request['user_id']=$user_id;

		if($ticket_id>0)
		{
			$result=$this->Tickets_model->update($request,$ticket_id);

			if($result>0)
			{
				$history_result=$this->Tickets_model->InsertTicketHistory($history_request);
				$this->JsonOut(array('message'=>'updated'));
			}
			else {
				$this->JsonOut(array('message'=>'faild'),500);
			}
		}
		else if($customer_id>0)
		{
				$request['detail']=$notes;
				$request['lead_id']=$customer_id;
				$isert_id=$this->Tickets_model->NewTicket($request);
				if($isert_id>0)
				{
					$history_request['related_id']=$isert_id;
					$history_result=$this->Tickets_model->InsertTicketHistory($history_request);
					$this->JsonOut(array('message'=>'Ticket created','insert_id'=>$isert_id));
				}
				else {
					$this->JsonOut(array('message'=>'invalid customer details'),500);
				}

		}
		else {

			$this->JsonOut(array('message'=>'invalid id'),500);
		}
	}






	public function index()
	{
		$this->list();

	}
}
