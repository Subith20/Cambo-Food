<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Orders extends Iglobe_Controller {

	public function __construct() {
			parent::__construct();
			// Load form helper library
			$this->load->helper('form');
			// Load form validation library
			$this->load->library('form_validation');
			// Load session library

			// Load database
			$this->load->model('Customer_model');
			$this->load->model('User_model');
			$this->load->model('Generic_model');
			$this->load->model('Products_model');
			$this->load->model('Orders_model');
			$this->load->model('Shops_model');
	}

	function __destruct() {
		parent::__destruct();

  }



	function clearCart($customer_id)
	{
		$this->Products_model->ClearCartList($customer_id);
		$this->JsonOut(array('message'=>'success'));
	}

	public function list($shop_id=null)
	{
		$request=$this->input->get();
		$request['status']=$request['status']?$request['status']:1;
		$data['request']=$request;
		$data['order_status_list']=$this->Orders_model->OrderStatus();
		$data['to']=date('Y-m-d');
		$data['from']=date('Y-m-d', strtotime('-6 days'));
		$data['shop_id']=$shop_id;
		$data['user_type']=$this->getUser('type');

		//echo"<pre>";print_r($data['order_status_list']);exit;
		$this->smarty->display( 'orders/list.tpl',$data);
	}



	public function list_datatable()
	{
		$request=$this->input->get();
		$status=$request['status'];
		$shop_id=$request['shop_id'];
		$from=$request['from'];
		$to=$request['to'];
		$user_id=$this->getUser('id');
		
		$result=array();

		if($this->getUser('type')==1)
		{
			$orders=$this->Orders_model->GetOrdertList(array('status'=>$status,'from'=>$from,'to'=>$to,'shop_id'=>$shop_id));
			foreach ($orders as $value) {
				$result[]=array(
					'<span class="order_row" data-id="'.$value['id'].'">'.$value['id'].'  <i class="fas fa-eye order-action"></i></span><i class="fas fa-print order-action" data-id="'.$value['id'].'"></i><i class="fas order-edit fa-edit order-action" data-id="'.$value['id'].'"></i>',
					$value['order_date'],
					$value['shop_id'].' '.$value['shop_name'],
					$value['customer_name'].' (<a href="tel:'.$value['customer_phone'].'">'.$value['customer_phone'].'</a>) <i class="far fa-arrow-alt-circle-right pointer" onclick="ShowCustomerDetails('."'".$value['customer_id']."'".');"></i>',
					
					'<button type="button" rw_id="'.$value['id'].'" class="btn '.$value['status_btn_class'].' status-ed btn-sm">'.$value['status_name'].'<i  class="fas fa-edit"></i></button>',
					'<span class="currency-sym">'.number_format((float)$value['total_amount'], 2, '.', '').'</span>',
					'<span class="currency-sym">'.number_format((float)$value['shipping_price'], 2, '.', '').'</span>',
					'<span class="currency-sym">'.number_format((float)$value['commission_amount'], 2, '.', '').'</span>',
					$value['payment_mode'],
					$value['driver_name'].' (<a href="tel:'.$value['driver_phone'].'">'.$value['driver_phone'].'</a>)'
				);
			}

		}
		else if($this->getUser('type')==5)
		{
			$orders=$this->Orders_model->GetOrdertList(array('status'=>$status,'from'=>$from,'to'=>$to,'shop_id'=>$shop_id,'manager_id'=>$user_id));
			foreach ($orders as $value) {
				$result[]=array(
					'<span class="order_row" data-id="'.$value['id'].'">'.$value['id'].'  <i class="fas fa-eye order-action"></i></span><i class="fas fa-print order-action" data-id="'.$value['id'].'"></i>',
					$value['order_date'],
					$value['shop_id'].' '.$value['shop_name'],
					$value['customer_name'].' (<a href="tel:'.$value['customer_phone'].'">'.$value['customer_phone'].'</a>)',
					
					$value['status']<3?'<button type="button" rw_id="'.$value['id'].'" class="btn '.$value['status_btn_class'].' status-ed btn-sm">'.$value['status_name'].'<i  class="fas fa-edit"></i></button>':'<button type="button" class="btn '.$value['status_btn_class'].' btn-sm status-ned">'.$value['status_name'].'</button>',
					'<span class="currency-sym">'.number_format((float)$value['total_amount'], 2, '.', '').'</span>',
					$value['driver_name'].' (<a href="tel:'.$value['driver_phone'].'">'.$value['driver_phone'].'</a>)'
				);
			}
			
		}
		
		$this->JsonOut($result);
	}

	public function order_details($id)
	{
		$request=$this->input->get();
		$user_id=$this->getUser('id');
		if($this->getUser('type')<4)
		{
			$data['orders_details']=$this->Orders_model->GetOrderDetail(array('id'=>$id));
		}
		else if($this->getUser('type')==5)
		{
			$data['orders_details']=$this->Orders_model->GetOrderDetail(array('id'=>$id,'manager_id'=>$user_id));
		}
		

		$data['shop_name']=$this->config->item('shop_name');
		$data['shop_address']=$this->config->item('shop_address');
		$data['shop_zip']=$this->config->item('shop_zip');
		$data['shop_phone']=$this->config->item('shop_phone');
		$data['shop_tax_no']=$this->config->item('shop_tax_no');
		$data['shop_email']=$this->config->item('shop_email');
		$data['shop_website']=$this->config->item('shop_website');
		$data['shop_order_notes']=$this->config->item('shop_order_notes');
		$data['currency']=$this->config->item('currency');

		$data['base_url']=base_url();

		if(!$data['orders_details']['id'])
		{
			echo '<div style="text-align: center;margin-top: 100px;font-size: 30px;color: #7d7d7d;">Invoice Not Found!</div>';exit;
		}
		//echo "<pre>";print_r($data['orders_details']);exit;
		if($request['print']==true)
		{
			$this->smarty->display( 'orders/details_print.tpl',$data);
		}
		else {
			$this->smarty->display( 'orders/details.tpl',$data);
		}
		
	}

	public function call_order_status($id)
	{
		$user_id=$this->getUser('id');
		if($this->getUser('type')<4)
		{
			$data['orders_details']=$this->Orders_model->GetOrderDetail(array('id'=>$id));
		}
		else if($this->getUser('type')==5)
		{
			$data['orders_details']=$this->Orders_model->GetOrderDetail(array('id'=>$id,'manager_id'=>$user_id));
		}

		if($data['orders_details'])
		{
			$data['order_status']=$this->Orders_model->OrderStatus($this->getUser('type'));
			$this->smarty->display( 'orders/status_update.tpl',$data);
		}
		else {
			echo '<div style="text-align: center;margin-top: 100px;font-size: 30px;color: #7d7d7d;">Order Not Found!</div>';exit;
		}
		
		
	}

	public function call_order_edit($id)
	{
		$this->is_admin();
		$data['orders_details']=$this->Orders_model->GetOrderDetail(array('id'=>$id,'deleted_list'=>true));
		$data['driver_list']=$this->User_model->getOurDrivers();
		$data['order_status']=$this->Orders_model->OrderStatus();
		$data['shop_driver_list']=$this->Shops_model->ShopDriverList($data['orders_details']['shop_id']);
		$data['getPaymentMode']=$this->Orders_model->getPaymentMode();
		$data['currency']=$this->config->item('currency');
		//echo "<pre>";print_r($data);exit;
		$this->smarty->display( 'orders/edit.tpl',$data);
	}

	public function update_order_status()
	{
		$request=$this->input->post();

		$id=$request['id'];
		$status=$request['status'];

		$user_id=$this->getUser('id');
		if($this->getUser('type')<4 and $id>0)
		{
			$is_update=$this->Orders_model->status_update($id,$status);
		}
		else if($this->getUser('type')==5 and ($status<3 || $status==8))
		{
			$orders_details=$this->Orders_model->GetOrderBasicDetail($id);
			if($orders_details['manager_id']==$user_id)
			{
				$is_update=$this->Orders_model->status_update($id,$status);
			}
			
		}

		if($is_update)
		{
			$order_details=$this->Orders_model->GetOrderBasicDetail($id);
			//echo "<pre>";print_r($order_details);exit;
			$customer_token=$this->Customer_model->getDeviceToken($order_details['customer_id']);

			if($order_details['driver_id']>0)
			{
				$driver_token=$this->Customer_model->getDeviceToken($order_details['driver_id']);
			}

			$manager_token=$this->Customer_model->getDeviceToken($order_details['manager_id']);
			
			$message='Your order #'.$order_details['id'].' : '.$order_details['status_name'];
			foreach ($customer_token as $key_data) {
				$fcm_result=$this->fcm_push_notification($key_data['device_token'], 'Order Updates', $message);
				$push_result[]=array('token'=>$key_data['device_token'],'response'=>$fcm_result);
			}

			foreach ($driver_token as $key_data) {
				$fcm_result=$this->fcm_push_notification($key_data['device_token'], 'Order Updates', $message);
				$push_result[]=array('token'=>$key_data['device_token'],'response'=>$fcm_result);
			}

			foreach ($manager_token as $key_data) {
				$fcm_result=$this->fcm_push_notification($key_data['device_token'], 'Order Updates', $message);
				$push_result[]=array('token'=>$key_data['device_token'],'response'=>$fcm_result);
			}
			//echo "<pre>";print_r($push_result);exit;
			//$this->JsonOut($tokenlist);
			//$this->fcm_push_notification($deviceToken, 'Order Updates', $message)
			$this->JsonOut(array('message'=>'updated','fcm_resul'=>$push_result));
		}
		else {
			$this->JsonOut(array('message'=>'success'));
		}

	}

	public function countOrders()
	{
		if($this->getUser('type')==5)
		{
			$count=$this->Orders_model->countMangerOrders($this->getUser('id'));
		}
		else {
			$count=$this->Orders_model->countOrders();
		}
		
		$this->JsonOut(array('total_orders'=>(int)$count['count']));
	}


	public function update()
	{
		$this->is_admin();
		$request=$this->input->post();
		$id=$request['id'];
		unset($request['ajax']);
		unset($request['id']);
		$deleted_list=$request['deleted_list'];
		unset($request['deleted_list']);
		//echo "<pre>";
		//print_r($request);exit;
		$this->form_validation->set_rules('shipping_name', 'Shipping Name', 'required');
		$this->form_validation->set_rules('phone', 'Shipping Phone Number', 'required');
		$this->form_validation->set_rules('shipping_address', 'shipping Address', 'required');
		$this->form_validation->set_rules('admin_notes', 'Admin Notes', 'required');
		if ($this->form_validation->run() == FALSE)
        {
            $this->JsonOut(array('message'=>validation_errors()),500); 
        }

        if($id>0)
		{
			$is_update=$this->Orders_model->order_update($request,$id);
		}

		$is_update2=$this->Orders_model->deleteOrderFoodItem($deleted_list,$id);

		if($is_update or $is_update2)
		{
			$rebill=$this->billReCalculate($id);

			$this->JsonOut(array('message'=>'Updated'));
		}
		else {
			$this->JsonOut(array('message'=>'No Changes Found!'),500);
		}


	}

	public function index()
	{
		$this->list();

	}

	public function billReCalculate($order_Id)
	{
		$this->is_admin();
      	if($order_Id<1)
      	{
        	return false;
      	}

	  	$orders_details=$this->Orders_model->GetOrderDetail(array('id'=>$order_Id));

	  	//echo "<pre>";print_r($orders_details);exit;

	      $order_price=0;
	      $order_amount_total=0;
	      $order_tax_amount=0;
	      foreach ($orders_details['items'] as $key => $value) {
	            $order_price+=$value['total_amount'];
	            $order_tax_amount+=$value['tax_amount'];
	      }
      
      $order_update_data['price']=$order_price-$orders_details['discount_amount'];
      $order_update_data['total_amount']=($order_price-$orders_details['discount_amount'])+$orders_details['shipping_price']+$orders_details['packing_charges'];
      $order_update_data['tax_amount']=$order_tax_amount;
      

        $this->Orders_model->order_update($order_update_data,$order_Id);

        $message='Your Order Was Changed. Order number :'.$order_Id;

        /*shop notification*/
        $tokenlist=$this->User_model->getDeviceToken($shop_details['user_id']);
        foreach ($tokenlist as $key_data) {
          $fcm_result=$this->fcm_push_notification($key_data['device_token'], 'Order Updates', $message);
          $push_result[]=array('token'=>$key_data['device_token'],'response'=>$fcm_result);
        }

        /*Driver notification*/
        $tokenlist=$this->User_model->getDeviceToken($driver_id);
        foreach ($tokenlist as $key_data) {
          $fcm_result=$this->fcm_push_notification($key_data['device_token'], 'Order Updates', $message);
          $push_result[]=array('token'=>$key_data['device_token'],'response'=>$fcm_result);
        }

        $customer_token=$this->Customer_model->getDeviceToken($order_details['customer_id']);

        foreach ($customer_token as $key_data) {
			$fcm_result=$this->fcm_push_notification($key_data['device_token'], 'Order Updates', $message);
			$push_result[]=array('token'=>$key_data['device_token'],'response'=>$fcm_result);
		}

        return true;


    }
}
