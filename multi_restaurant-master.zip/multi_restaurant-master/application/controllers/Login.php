<?php

session_start(); //we need to start session in order to access it through CI

Class Login extends CI_Controller {

  public function __construct() {
      parent::__construct();
      // Load form helper library
      $this->load->helper('form');
      // Load form validation library
      $this->load->library('form_validation');
      // Load session library
      $this->load->library('session');
      // Load database
      if (isset($this->session->userdata['logged_in'])) {
        header("location: ".$this->config->item('base_url'));
      }
      $this->load->model('User_model');
      $this->smarty->display( 'header.tpl');
  }

  // Show login page
  public function index() {
    $inputdata=$this->input->get();
    $data['base_url'] =$this->config->item('base_url');
    $data['redirect'] =$inputdata['redirect'];
    $data['country_code'] =$this->config->item('country_code');
    $data['weatherwidget_url']=$this->config->item('weatherwidget_url');
    $data['weatherwidget_lable']=$this->config->item('weatherwidget_lable');
    
     $this->smarty->display( 'login_form.tpl',$data);

  }

  // Check for user login process
  public function user_login_process() {
      $inputdata=$this->input->get();
      $this->form_validation->set_rules('phone', 'Phone', 'trim|required|numeric|min_length[7]|max_length[10]');
      $this->form_validation->set_rules('password', 'Password', 'trim|required');
      $data['redirect'] =$inputdata['redirect'];
      $data['country_code'] =$this->config->item('country_code');
      $data['weatherwidget_url']=$this->config->item('weatherwidget_url');
      $data['weatherwidget_lable']=$this->config->item('weatherwidget_lable');
      $data['base_url'] =$this->config->item('base_url');

    if ($this->form_validation->run() == FALSE)
    {

      if(isset($this->session->userdata['logged_in'])){
        //  echo 'sucess'.$this->config->item('base_url');
         header("location: ".$this->config->item('base_url'));
         // echo "<script>window.location.href='".$this->config->item('base_url')."';</script>";

          exit;
      }else{
        $data['error_msg']="Invalid Mobile Number / Password";
        //$this->load->view('login_form',$data);

        $this->smarty->display( 'login_form.tpl',$data);
      }
    }
    else
    {
      $phone=$this->config->item('country_code').$this->input->post('phone');
      $user_details = $this->User_model->login($phone,md5($this->input->post('password')));


        if (is_array($user_details))
        {
            $session_data = $user_details;
            // Add user data in session
            //echo 1;exit;
            $redirect_url=$this->input->post('redirect_url');
            $this->session->set_userdata('logged_in', $session_data);

            if($redirect_url)
            {
              
              echo "<script>window.location.href='".$redirect_url."';</script>";
              header("location: ".$redirect_url);
            }
            else
            {
              echo "<script>window.location.href='".$this->config->item('base_url')."';</script>";
              header("location: ".$this->config->item('base_url'));
            }
            

            exit;

        }
        else
        {
          $data['error_msg']="Invalid Mobile Number / Password";
           $this->smarty->display( 'login_form.tpl',$data);
        }
    }
  }

  // Logout from admin page
  public function logout() {

    // Removing session data
    $sess_array = array(
    'username' => ''
    );
    $this->session->unset_userdata('logged_in', $sess_array);
    $data['error_msg'] = 'Successfully Logout';
    $data['base_url'] =$this->config->item('base_url');
     $this->smarty->display( 'login_form.tpl',$data);
    //$this->load->view('login_form', $data);
  }


}

?>
