<?php

class JsonMapper_Exception extends Exception
{
}

?>