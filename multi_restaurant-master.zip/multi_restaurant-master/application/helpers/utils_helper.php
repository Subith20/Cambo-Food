<?php
/**
 * Created by PhpStorm.
 * User: enginef
 * Date: 2/2/19
 * Time: 11:17 AM
 */

function isAssoc($arr){
    // return array_keys($arr) !== range(0, count($arr) - 1);
}
