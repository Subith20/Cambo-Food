<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Orders_model extends CI_Model {

    public function __construct() {
        parent::__construct();

        // Load the database library
        $this->load->database();

        $this->load->model('Shops_model');
        $this->load->model('User_model');
    }

    /*
     * Get rows from the users table
     */

    public function deleteOrderFoodItem($deleted_list,$order_id)
    {
      $deleted_list=explode(',', $deleted_list);
      $this->db->where_in('id',$deleted_list);
      $this->db->where('order_id', $order_id);
      $this->db->set('is_deleted', 1);
      $this->db->update('orders_list');
      //echo $this->db->last_query();exit;
      return $this->db->affected_rows();
    }

     
    public function GetOrdertList($request)
     {
       $order_status=$this->config->item('order_status');
       // $this->db->select('A.*, COUNT(B.id) AS item_count, SUM(B.sale_price*B.qty) AS amount,SUM(B.sale_price*B.qty) AS total, SUM(((B.sale_price/100)*B.tax)*B.qty) AS tax, C.name AS customer_name, C.phone AS customer_phone');
       $this->db->select('A.*,B.name as status_name,B.status_btn_class, C.name AS customer_name, C.phone AS customer_phone, D.name as shop_name, E.name as payment_mode,E.code as payment_mode_code,F.id as driver_id, F.first_name as driver_name,F.phone as driver_phone');
       $this->db->from('orders A');
       $this->db->join('order_status B','B.id=A.status','inner');
       $this->db->join('customers C','C.id=A.customer_id','inner');
       $this->db->join('shops D','D.id=A.shop_id','inner');
       $this->db->join('payment_mode E','E.id=A.method','left');
       $this->db->join('users F','F.id=A.driver_id','left');
       $this->db->group_by('A.id');
       $this->db->order_by('A.id', 'DESC');
       if($request['user_id']>0)
       {
         $this->db->where('A.customer_id', $request['user_id']);
       }

       if($request['status'])
       {
          $request['status']=str_replace(","," or A.status=",$request['status']);
          $this->db->where('(A.status='.$request['status'].')');
       }

       if($request['driver_id']>0)
       {
          $this->db->where('A.driver_id', $request['driver_id']);
       }

       if($request['shop_id']>0)
       {
          $this->db->where('A.shop_id', $request['shop_id']);
       }

       if($request['manager_id']>0)
       {
          $this->db->where('D.user_id', $request['manager_id']);
       }

       if($request['from'] && $request['to'])
       {
          
          $this->db->where("(A.order_date BETWEEN '".$request['from']." 00:00:00' AND '".$request['to']." 23:59:59')");
       }

       $query = $this->db->get();
       //echo $this->db->last_query();exit;
       $data = $query->result_array();
       return $data;
     }

     public function GetDriverOrdertList($request)
     {
       
       $this->db->select('A.id,A.order_date,A.delivery_date,A.status,A.driver_reached,A.method,A.total_amount,A.customer_id,A.shop_id,A.driver_id,A.shipping_id,A.shipping_name,A.phone,A.shipping_address,A.zip,A.notes,B.name as status_name,B.status_btn_class, C.lat AS customer_latitude, C.long AS customer_longitude,D.name as shop_name,D.address as shop_address,D.latitude as shop_latitude, D.longitude as shop_longitude,D.phone as shop_phone,D.mobile as shop_mobile,D.is_available shop_available, E.name as payment_mode,E.code as payment_mode_code');

       $this->db->from('orders A');
       $this->db->join('order_status B','B.id=A.status','inner');
       $this->db->join('customer_address C','C.id=A.shipping_id','left');
       $this->db->join('shops D','D.id=A.shop_id','left');
       $this->db->join('payment_mode E','E.id=A.method','left');
       $this->db->group_by('A.id');
       $this->db->order_by('A.id', 'DESC');

       if($request['status'])
       {
          $request['status']=str_replace(","," or A.status=",$request['status']);
          $this->db->where('(A.status='.$request['status'].')');
       }

       if($request['driver_id']>0)
       {
          $this->db->where('A.driver_id', $request['driver_id']);
       }

       if($request['from'] && $request['to'])
       {
          
          $this->db->where("(A.order_date BETWEEN '".$request['from']." 00:00:00' AND '".$request['to']." 23:59:59')");
       }

       $query = $this->db->get();
       //echo $this->db->last_query();exit;
       $data = $query->result_array();

       if($request['status'])
       {
          foreach ($data as $key=>$value) {
            $data[$key]['food_list']=$this->GetOrdertItemList($value['id']);
          }

       }

       return $data;
     }

     function GetOrdertItemList($order_id)
     {
       $this->db->select('A.*');
       $this->db->from('orders_list A');
       $this->db->join('orders C','C.id=A.order_id','inner');
       $this->db->where('A.order_id', $order_id);
       $this->db->where('A.is_deleted', 0);
       $query = $this->db->get();
       $data= $query->result_array();
       foreach ($data as $key=>$value) {
         $data[$key]['extras']=array();
         $extras_data=$this->GetOrdertItemExtrasList($value['id']);
         $data[$key]['extras']=$extras_data;
         $extras_price=0;
         $extras_name=array();
         $extras_tax=0;
         foreach ($extras_data as $extras_value) {
           $extras_price+=$extras_value['price'];
           $extras_tax+=$extras_value['tax_amount'];
           $extras_name[]=$extras_value['name'];
         }

         $data[$key]['extras_name_list']=$extras_data?implode(', ', $extras_name):null;
         $data[$key]['extras_total_price']=$extras_data?$extras_price:0;

       }
       return $data;
     }

     function GetOrdertFullItemList($request)
     {
       $this->db->select('A.*');
       $this->db->from('orders_list A');
       $this->db->join('orders C','C.id=A.order_id','inner');
       $this->db->where('A.order_id', $request['id']);
       $query = $this->db->get();
       $data= $query->result_array();
       foreach ($data as $key=>$value) {
         $data[$key]['extras']=array();
         $extras_data=$this->GetOrdertItemExtrasList($value['id']);
         $data[$key]['extras']=$extras_data;
         $extras_price=0;
         $extras_name=array();
         $extras_tax=0;
         foreach ($extras_data as $extras_value) {
           $extras_price+=$extras_value['price'];
           $extras_tax+=$extras_value['tax_amount'];
           $extras_name[]=$extras_value['name'];
         }

         $data[$key]['extras_name_list']=$extras_data?implode(', ', $extras_name):null;
         $data[$key]['extras_total_price']=$extras_data?$extras_price:0;

       }
       return $data;
     }

     function GetOrdertItemExtrasList($order_list_id)
     {
       $this->db->select('A.*');
       $this->db->from('orders_extra_list A');
       $this->db->where('A.order_list_id', $order_list_id);
       $query = $this->db->get();
       $data= $query->result_array();
       return $data;
     }

     public function GetOrderDetail($request)
     {
       $payment_mode=$this->config->item('payment_mode');
       $order_status=$this->config->item('order_status');
       $this->db->select('A.*, C.name AS customer_name, C.phone AS customer_phone,E.name as payment_mode_name,F.lat AS shipping_latitude, F.long AS shipping_longitude,G.name as shop_name');
       $this->db->from('orders A');
       $this->db->join('customers C','C.id=A.customer_id','inner');

       $this->db->join('payment_mode E','E.id=A.method','left');
       $this->db->join('customer_address F','F.id=A.shipping_id','left');
       $this->db->join('shops G','G.id=A.shop_id','inner');
       if($request['customer_id']>0)
       {
         $this->db->where('A.customer_id', $request['customer_id']);
       }

       if($request['manager_id']>0)
       {
         $this->db->where('G.user_id', $request['manager_id']);
       }
       
       $this->db->where('A.id', $request['id']);

       $query = $this->db->get();
       //echo $this->db->last_query();exit;
       $data = $query->row_array();
       if(is_array($data))
       {
          if($request['deleted_list'])
          {
            $data['items']=$this->GetOrdertFullItemList($request);
          }
          else {
            $data['items']=$this->GetOrdertItemList($request['id']);
          }
          
          $data['shop_details']=$this->Shops_model->getProductsShopDetails($data['items'][0]['item_id']);
          $data['driver_details']=$this->User_model->Details($data['driver_id']);
       }
       return $data;
     }

     public function checkManagerOrder($request)
     {
       $this->db->select('A.*');
       $this->db->from('orders A');
       $this->db->join('shops G','G.id=A.shop_id','inner');
       if($request['manager_id']>0)
       {
         $this->db->where('G.user_id', $request['manager_id']);
       }
       $this->db->where('A.id', $request['id']);
       $query = $this->db->get();
       //echo $this->db->last_query();exit;
       $data = $query->row_array();
       return $data;
     }

     public function GetOrderBasicDetail($order_id)
     {
       $payment_mode=$this->config->item('payment_mode');
       $this->db->select('A.*,B.name as status_name,C.user_id as manager_id');
       $this->db->from('orders A');
       $this->db->join('order_status B','B.id=A.status','inner');
       $this->db->join('shops C','C.id=A.shop_id','inner');
       $this->db->where('A.id', $order_id);
       $query = $this->db->get();
       $data = $query->row_array();
       return $data;
     }


     public function status_update($id,$status)
     {
       $this->db->where('id', $id);
       $this->db->set('status', $status);
       $this->db->update('orders');
       return $this->db->affected_rows();
     }


     public function driverReachedUpdate($id,$driver_id,$status)
     {
       $this->db->where('id', $id);
       $this->db->where('driver_id', $driver_id);
       $this->db->where('status<3');
       $this->db->set('driver_reached', $status);
       $this->db->update('orders');
      //echo $this->db->last_query();
       return $this->db->affected_rows();
     }

     public function DriverStatusUpdate($driver_id,$id,$status,$payment_mode=null)
     {
       $this->db->where('id', $id);
       $this->db->where('driver_id', $driver_id);
       $this->db->where('(status < '.$status.' or status=5)');
       if($payment_mode)
       {
          $this->db->set('method', $payment_mode);
       }
       $this->db->set('status', $status);
       $this->db->update('orders');
       return $this->db->affected_rows();
     }

    /*
     * Insert user data
     */
    public function NewBillMaster($data){
        //insert user data to users table
        $insert = $this->db->insert('orders', $data);
        //return the status
        return $insert?$this->db->insert_id():false;
    }

    public function POS_NewBill($data){
        //insert user data to users table
        $insert = $this->db->insert('pos_orders', $data);
        //return the status
        return $insert?$this->db->insert_id():false;
    }

    public function order_update($data,$id){
       $update = $this->db->update('orders', $data, array('id'=>$id));
      // echo $this->db->last_query();exit;
       return $this->db->affected_rows();
    }

    public function payment_gateway_insert($data){
        $insert = $this->db->insert('payments', $data);
        return $insert?$this->db->insert_id():false;
    }

    public function payment_gateway_update($data,$id){
        $update = $this->db->update('payments', $data, array('id'=>$id));
        return $update?true:false;
    }

    public function CustomerLastPaymentsDetails($customer_id,$payment_gateway,$amount)
    {
       $this->db->select('*');
       $this->db->from('payments');
       $this->db->where('customer_id', $customer_id);
       $this->db->where('gateway_id', $payment_gateway);
       $this->db->where('price', $amount);
       $this->db->order_by('id', 'DESC');
       $query = $this->db->get();
       $result= $query->row_array();
       return $result;
    }

    public function GetPaymentsDetails($customer_id,$payment_gateway,$transaction_id)
    {
       $this->db->select('*');
       $this->db->from('payments');
       $this->db->where('customer_id', $customer_id);
       $this->db->where('gateway_id', $payment_gateway);
       $this->db->where('transaction_id', $transaction_id);
       $this->db->order_by('id', 'DESC');
       $query = $this->db->get();
       $result= $query->row_array();
       return $result;
    }

    public function NewOrderItems($data){
        //insert user data to users table
        $insert = $this->db->insert('orders_list', $data);
        //return the status
        return $insert?$this->db->insert_id():false;
    }

    public function POS_NewOrderItems($data){
        //insert user data to users table
         $insert = $this->db->insert_batch('pos_orders_list', $data);
       //$insert = $this->db->insert('pos_orders_list', $data);
        //return the status
        return $insert?$this->db->insert_id():false;
    }

    public function POS_NewExtra($data){
         $insert = $this->db->insert_batch('pos_orders_extra_list', $data);
        return $insert?true:false;
    }

    public function NewOrderExtras($data){
        //insert user data to users table
        $insert = $this->db->insert('orders_extra_list', $data);
        //return the status
        return $insert?$this->db->insert_id():false;
    }

    function getTodayOrders()
    {
      $this->db->select('A.id, A.name, COUNT(B.id) AS `count`');
       $this->db->from('order_status A');
       $this->db->join('orders B','B.status = A.id','left');
       $this->db->where('DATE(B.`order_date`) = CURDATE()');
       $this->db->group_by('A.name,A.id');
       $this->db->order_by('A.id');
       $query = $this->db->get();
      // echo $this->db->last_query();exit;
       $data = $query->result_array();
       foreach ($data as $value) {
         $result[$value['id']]=$value;
       }
       return $result;
    }

    function getPaymentMode()
    {
       $this->db->select('*');
       $this->db->from('payment_mode');
       $query = $this->db->get();
       $result = $query->result_array();
       return $result;
    }

    function getOrdersBetween($from,$to)
    {

      if($from && $to)
      {
       $this->db->select('count(id) as count');
       $this->db->from('orders');
       $this->db->where("(order_date BETWEEN '".$from."' AND '".$to."')");
       $query = $this->db->get();
       //echo $this->db->last_query();exit;
       $result = $query->row_array();
      }
       
      return $result;
    }

    function getSuccessOrdersBetween($from,$to)
    {

      if($from && $to)
      {
       $this->db->select('count(id) as count');
       $this->db->from('orders');
       $this->db->where("status=4 and (order_date BETWEEN '".$from."' AND '".$to."')");
       $query = $this->db->get();
      // echo $this->db->last_query();exit;
       $result = $query->row_array();
      }
       
      return $result;
    }

    function getLast12MothOrder()
    {
      $this->db->select("DATE_FORMAT(A.order_date,'%Y-%m ( %M )') as date,count(*) as count");
      $this->db->from('orders A');
      $this->db->where("A.order_date> now() - INTERVAL 12 month");
      $this->db->group_by("DATE_FORMAT(A.order_date,'%Y-%m ( %M )')");
      //$this->db->order_by("DATE_FORMAT(A.order_date,'%Y-%m ( %M )') desc");
      $query = $this->db->get();
      //echo $this->db->last_query();
      $result = $query->result_array();
      return $result;
    }

    function getCurrentMothOrderCountByDate()
    {
      $this->db->select('DATE(A.order_date) as date,count(*) as count');
      $this->db->from('orders A');
      $this->db->where("MONTH(A.order_date)=MONTH(now()) and YEAR(A.order_date)=YEAR(now())");
      $this->db->group_by('DATE(A.order_date)');
      $query = $this->db->get();
      //echo $this->db->last_query();
      $result = $query->result_array();
      return $result;
    }

    function countOrders($status=1)
    {
      $this->db->select('count(id) as count');
      $this->db->from('orders');
      $this->db->where('status',1);
      $query = $this->db->get();
      $result = $query->row_array();
      return $result;
    }

    function countMangerOrders($user_id,$status=1)
    {
      $this->db->select('count(A.id) as count');
      $this->db->from('orders A');
      $this->db->join('shops B','B.id=A.shop_id','inner');
      $this->db->where('A.status',$status);
      $this->db->where('B.user_id',$user_id);
      $query = $this->db->get();
      $result = $query->row_array();
      return $result;
    }

    function OrderStatus($user_type=null)
    {
      $this->db->select('*');
      $this->db->from('order_status');
      if($user_type>0)
      {
        $this->db->where('FIND_IN_SET( '.$user_type.', user_access)');
      }
      $query = $this->db->get();
      //echo $this->db->last_query();
      $result = $query->result_array();
      return $result;
    }

    public function POS_OrdertList($request)
    {
       $this->db->select('A.*,B.name as customer_name,B.phone as customer_phone,C.name as shop_name,D.first_name as cashier');
       $this->db->from('pos_orders A');
       $this->db->join('shop_customers B','B.id=A.customer_id','inner');
       $this->db->join('shops C','C.id=A.shop_id','inner');
       $this->db->join('users D','D.id=A.cashier_id','left');
       //$this->db->group_by('A.id');
       $this->db->order_by('A.id', 'DESC');


       if($request['shop_id']>0)
       {
          $this->db->where('A.shop_id', $request['shop_id']);
       }

       if($request['manager_id']>0)
       {
          $this->db->where('C.user_id', $request['manager_id']);
       }

       if($request['from'] && $request['to'])
       {
          
          $this->db->where("(A.order_date BETWEEN '".$request['from']." 00:00:00' AND '".$request['to']." 23:59:59')");
       }

       $query = $this->db->get();
       //echo $this->db->last_query();exit;
       $data = $query->result_array();
       return $data;
     }

     function pos_orders_details($request)
     {

      $this->db->select('A.*,B.name as customer_name,B.phone as customer_phone,C.name as shop_name,D.first_name as cashier');
       $this->db->from('pos_orders A');
       $this->db->join('shop_customers B','B.id=A.customer_id','inner');
       $this->db->join('shops C','C.id=A.shop_id','inner');
       $this->db->join('users D','D.id=A.cashier_id','left');
       //$this->db->group_by('A.id');
       $this->db->order_by('A.id', 'DESC');

       if($request['cashier_id']>0)
       {
          $this->db->where('A.cashier_id', $request['cashier_id']);
       }
       if($request['manager_id']>0)
       {
          $this->db->where('C.user_id', $request['manager_id']);
       }

       $this->db->where('A.id', $request['id']);
       $query = $this->db->get();
       //echo $this->db->last_query();exit;
        $result = $query->row_array();
        if($result['id'])
        {
          $result['items']=$this->pos_orders_items($result['id']);
        }
        
        return $result;
     }

     function pos_orders_items($order_id)
     {

        $this->db->select('A.*');
        $this->db->from('pos_orders_list A');
        $this->db->where('A.order_id', $order_id);
        $query = $this->db->get();
       //echo $this->db->last_query();exit;
       $data = $query->result_array();
       return $data;

     }


}
