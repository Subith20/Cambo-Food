<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class User_model extends CI_Model {

    public function __construct() {
        parent::__construct();

        // Load the database library
        $this->load->database();

        $this->userTbl = 'users';
    }

    /*
     * Get rows from the users table
     */
    function getUserList(){
        $this->db->select('A.id,A.first_name,A.last_name,A.email,A.phone,A.`type`,A.`status`,A.lastlogin,A.cluster_id, A.is_shop_driver, B.name AS type_name ');
        $this->db->from('users A');
        $this->db->join('user_type B','B.id=A.type','inner');
        $query = $this->db->get();
        $result = ($query->num_rows() > 0)?$query->result_array():false;
        return $result;
    }

    function Details($id){
        $this->db->select('A.id,A.first_name,A.last_name,A.email,A.phone,A.type,A.status,A.lastlogin,A.cluster_id,A.is_shop_driver, B.name AS type_name ');
        $this->db->from('users A');
        $this->db->join('user_type B','B.id=A.type','inner');
        $this->db->where('A.id',$id);
        $query = $this->db->get();
        $result = ($query->num_rows() > 0)?$query->row_array():false;
        return $result;
    }

    function getAssign_to()
    {
      $this->db->select('id,first_name,phone');
      $this->db->from($this->userTbl);
      $query = $this->db->get();
      $data = $query->result_array();
      foreach ($data as $key => $value) {
        $result[$value['id']]=$value;
      }
      return $result;
    }

    function getManager()
    {
      $this->db->select('id,first_name,phone');
      $this->db->from($this->userTbl);
      $this->db->where('type',5);
      $query = $this->db->get();
      $data = $query->result_array();
      return $data;
    }

    function getAllDrivers()
    {
      $this->db->select('id,first_name,phone');
      $this->db->from($this->userTbl);
      $this->db->where('type',4);
      $query = $this->db->get();
      $data = $query->result_array();
      return $data;
    }

    function getOurDrivers($status='all')
    {
      $this->db->select('A.id,A.first_name as driver_name,A.is_shop_driver, A.phone, count(B.id) as order_count,A.status');
      $this->db->from('users A');
      $this->db->join('orders B', 'B.driver_id = A.id', 'left');

      if($status=='active')
      {
        $this->db->where('A.status',1);
      }
      else if($status=='inactive') 
      {
        $this->db->where('A.status',0);
      }

      $this->db->where('A.is_shop_driver',0);
      $this->db->where('type',4);
      $this->db->group_by('A.id');
      $this->db->order_by('count(B.id)');
      $query = $this->db->get();
      //echo $this->db->last_query();
      $data = $query->result_array();
      return $data;
    }

    function user_type()
    {
      $this->db->select('*');
      $this->db->from('user_type');
      $query = $this->db->get();
      $data = $query->result_array();
      foreach ($data as $key => $value) {
        $result[$value['id']]=$value['name'];
      }
      return $result;
    }

    /*
     * Insert user data
     */
    public function insert($data){
        //add created and modified date if not exists
        if(!array_key_exists("created", $data)){
            $data['created'] = date("Y-m-d H:i:s");
        }
        if(!array_key_exists("modified", $data)){
            $data['modified'] = date("Y-m-d H:i:s");
        }

        //insert user data to users table
        $insert = $this->db->insert($this->userTbl, $data);

        //return the status
        return $insert?$this->db->insert_id():false;
    }

    /*
     * Update user data
     */
    public function update($data, $id){
      
        //update user data in users table
        $update = $this->db->update($this->userTbl, $data, array('id'=>$id));

        //return the status
        return $update?true:false;
    }

    /*
     * Delete user data
     */
    /*
    public function delete($id){
        //update user from users table
        $delete = $this->db->delete('users',array('id'=>$id));
        //return the status
        return $delete?true:false;
    }*/

    public function login($phone,$password){
      $this->db->select('id,first_name,last_name,email,phone,type,imgpath');
      $this->db->where(array('phone' => $phone, 'password' => $password,'status'=>1));
			$query = $this->db->get("users");
      $result = $query->row_array();
			return $result;
    }


    public function GetUserKey($id){

      $this->db->select('key');
      $this->db->where(array('user_id' => $id));
			$query = $this->db->get("keys");
      $result = $query->row_array();
			return $result;
    }


    public function otp_sms_auth($phone,$otp)
    {
    //	echo $httpRequest->otp;exit;
      $this->db->where(array('phone' => $phone, 'otp' => $otp));
      $query = $this->db->get("users");
      //echo $this->db->affected_rows();
      return $query;
      //return $this->db->affected_rows();
    }

    public function otp_sms_update($phone,$otp)
    {
    //	echo 123;exit;
      $this->db->where('phone', $phone);
      $this->db->set('otp', $otp);
      $this->db->set('otp_time',  date('Y/m/d H:i:s'));
      $this->db->update('users');
      return $this->db->affected_rows();
    }

    public function remove_otp_sms($id)
    {
    //	echo 123;exit;
      $this->db->where('id', $id);
      $this->db->set('otp', null);
      $this->db->set('otp_time', null);
      $this->db->update('users');
      return $this->db->affected_rows();
    }

    public function otp_sms_insert($phone,$otp)
    {
      $data['phone']=$phone;
      $data['otp']=$otp;
      $data['otp_time']=date('Y/m/d H:i:s');
      $insert_result= $this->db->insert('users', (object)$data);
      $insert_id=$this->db->insert_id();
      return $insert_id;
    }

    public function CheckUser($data)
    {
      $this->db->select('id,phone');
      $this->db->where($data);
      $query = $this->db->get("users");
      $result = $query->row_array();
			return $result;
    }

    public function insert_token($data)
    {

      $insert_result= $this->db->insert('keys', (object)$data);
      $insert_id=$this->db->insert_id();

      return $insert_id;
    }

     public function deleteKey($user_id,$key){
        //update user from users table
      if($user_id>0)
        {
          if($key)
          {
            $delete = $this->db->delete('keys',array('key'=>$key,'user_id'=>$user_id));
            //echo  $this->db->last_query();
          }
          else {
              $delete = $this->db->delete('key',array('key'=>$key,'user_id'=>$user_id));
           
          }
        }
        
        return $delete?true:false;
    }

    public function getDeviceToken($user_id)
    {

      $this->db->select('A.`key`, A.`user_id`, A.`device_token`,A.`date_created`, B.first_name');
      $this->db->from('keys A');
      $this->db->join('users B', 'B.id=A.user_id', 'inner');
      $this->db->where('A.user_id',$user_id);
      $this->db->where('A.device_token IS NOT NULL');
      $this->db->where('A.user_type<>6');
      $this->db->order_by('A.id', 'DESC');
      $this->db->limit(4);
      $query = $this->db->get();
      $data = $query->result_array();
      return $data;
    }

}
