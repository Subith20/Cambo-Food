<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Customer_model extends CI_Model {

    public function __construct() {
        parent::__construct();

        // Load the database library
        $this->load->database();

        $this->customerTBL = 'customers';
    }


    public function update($data,$Customer_id){
      //echo "<pre>";print_r($data);exit();
        $update = $this->db->update($this->customerTBL, $data, array('id'=>$Customer_id));

        //return the status
        return $update?true:false;
    }

    public function new_customer($data){
      //  print_r($data);exit;
        //insert user data to users table
        $insert = $this->db->insert($this->customerTBL, $data);
        //return the status
        return $insert?$this->db->insert_id():false;
    }

    public function customer_shop_insert($data){
        $insert = $this->db->insert('shop_customers', $data);
        return $insert?$this->db->insert_id():false;
    }

    function Check_customer_shop($phone,$shop_id)
    {
      $this->db->select('*');
      $this->db->from('shop_customers');
      $this->db->where('phone',$phone);
      $this->db->where('shop_id',$shop_id);
      $query = $this->db->get();
      $data = $query->row_array();
      return $data;
    }

    function shop_customers($request)
    {
      $this->db->select('A.*');
      $this->db->from('shop_customers A');
      $this->db->join('shops B','A.shop_id=B.id','inner');
      if($request['shop_id']>0)
      {
        $this->db->where('A.shop_id',$request['shop_id']);
      }

      if($request['type']==5)
      {
        $this->db->where('B.user_id',$request['user_id']);
      }
      
      
      if($request['search'])
      {
        $this->db->like('A.phone', $search);
        $this->db->like('A.name', $search);
      }
      $query = $this->db->get();
      $data = $query->result_array();
      return $data;
    }

    function shop_customers_search_box($request)
    {
      $this->db->select("CONCAT(A.name,' (',A.phone,')') as label,A.id as value,A.*");
      $this->db->from('shop_customers A');
      $this->db->join('shops B','A.shop_id=B.id','inner');
      if($request['shop_id']>0)
      {
        $this->db->where('A.shop_id',$request['shop_id']);
      }

      if($request['type']==5)
      {
        $this->db->where('B.user_id',$request['user_id']);
      }
      
      
      if($request['search'])
      {
        $this->db->where("(`A`.`phone` LIKE '%".$request['search']."%' ESCAPE '!' OR `A`.`name` LIKE '%".$request['search']."%' ESCAPE '!')");
        //$this->db->like('A.phone', $request['search']);
        //$this->db->or_like('A.name', $request['search']);
      }
      $query = $this->db->get();
      //echo $this->db->last_query();exit;
      $data = $query->result_array();
      return $data;
    }

    function GetCustomerDetails($id)
    {
      $this->db->select('A.*');
      $this->db->order_by('A.id');
      //$this->db->join('Customer_bank C', 'C.Customer_id = A.id', 'left');
      $this->db->from($this->customerTBL.' A');
      $this->db->where('A.id',$id);
      $query = $this->db->get();
      $data = $query->row_array();
      return $data;
    }

    function CheckPhone($phone)
    {
      $this->db->select('A.*');
      $this->db->order_by('A.id');
      //$this->db->join('Customer_bank C', 'C.Customer_id = A.id', 'left');
      $this->db->from($this->customerTBL.' A');
      $this->db->where('A.phone',$phone);
      $query = $this->db->get();
      $data = $query->row_array();
      return $data;
    }

    function GetCustomerList($request=null)
    {
      $this->db->select('A.`id`,A.`name`,A.`phone`,A.`email`');
      $this->db->order_by('A.id');
      $this->db->from($this->customerTBL.' A');
      $this->db->where('A.deleted',0);
      $query = $this->db->get();
      $data = $query->result_array();
      return $data;
    }

    function GetCustomerDeletedList($request=null)
    {
      $this->db->select('A.`id`,A.`name`,A.`phone`,A.`email`');
      $this->db->order_by('A.id');
      $this->db->from($this->customerTBL.' A');
      $this->db->where('A.deleted',1);
      $query = $this->db->get();
      $data = $query->result_array();
      return $data;
    }




    /*
     * Delete user data
     */
    /*public function delete($id){
        //update user from users table
        $delete = $this->db->delete('customers',array('id'=>$id));
        return $delete?true:false;
    }*/

    public function deleteKey($user_id,$key){
        //update user from users table
      if($user_id>0)
        {
          if($id && $user_id>0)
          {
            $delete = $this->db->delete('key',array('key'=>$key,'user_id'=>$user_id));
          }
          else {
              $delete = $this->db->delete('key',array('key'=>$key,'user_id'=>$user_id));
           
          }
        }
        
        return $delete?true:false;
    }

    public function otp_sms_update($phone,$otp)
    {
    //	echo 123;exit;
      $this->db->where('phone', $phone);
      $this->db->set('otp', $otp);
      $this->db->set('otp_time',  date('Y/m/d H:i:s'));
      $this->db->update($this->customerTBL);
      return $this->db->affected_rows();
    }

    public function otp_sms_insert($phone,$otp)
    {
      $data['phone']=$phone;
      $data['otp']=$otp;
      $data['otp_time']=date('Y/m/d H:i:s');
      $insert_result= $this->db->insert($this->customerTBL, (object)$data);
      $insert_id=$this->db->insert_id();
      return $insert_id;
    }

    public function otp_sms_auth($phone,$otp)
    {
    //	echo $httpRequest->otp;exit;
      $this->db->where(array('phone' => $phone, 'otp' => $otp,'deleted'=>0));
      $query = $this->db->get($this->customerTBL);
      //echo $this->db->affected_rows();
      return $query;
    }

    public function insert_token($data)
    {

      $insert_result= $this->db->insert('keys', (object)$data);
      $insert_id=$this->db->insert_id();

      return $insert_id;
    }

    public function remove_otp_sms($id)
    {
    //	echo 123;exit;
      $this->db->where('id', $id);
      $this->db->set('otp', null);
      $this->db->set('otp_time', null);
      $this->db->update($this->customerTBL);
      return $this->db->affected_rows();
    }

    public function add_address($data)
    {
      $insert_result= $this->db->insert('customer_address', (object)$data);
      $insert_id=$this->db->insert_id();
      return $insert_id;
    }

    function address_list($customer_id)
    {
      $this->db->select('A.*');
      $this->db->from('customer_address A');
      $this->db->where('A.customer_id',$customer_id);
      $this->db->order_by('A.id', 'DESC');
      $query = $this->db->get();
      $data = $query->result_array();
      return $data;
    }

    function get_address($id,$customer_id)
    {
      $this->db->select('A.*');
      $this->db->from('customer_address A');
      $this->db->where('A.customer_id',$customer_id);
      $this->db->where('A.id',$id);
      $this->db->order_by('A.id', 'DESC');
      $query = $this->db->get();
      $data = $query->row_array();
      return $data;
    }

    public function address_delete($id,$customer_id){
        //update user from users table
        $delete = $this->db->delete('customer_address',array('id'=>$id,'customer_id'=>$customer_id));
        //return the status
        return $this->db->affected_rows();
    }

    public function address_update($id,$customer_id,$data)
    {
      $this->db->where('id', $id);
      $this->db->where('customer_id', $customer_id);
      $this->db->set($data);
      $this->db->update('customer_address');
      return $this->db->affected_rows();
    }

    function getTotalCustomers()
    {
       $this->db->select('count(id) as count');
       $this->db->from('customers');
       if($from and $to)
       {
          $this->db->where("(create_on BETWEEN '".$from."' AND '".$to."')");
       }


       $query = $this->db->get();
       $result = $query->row_array();

       return $result;
    }

    function getNewCustomers($from,$to)
    {
       $this->db->select('count(id) as count');
       $this->db->from('customers');
       if($from and $to)
       {
          $this->db->where("(create_on BETWEEN '".$from."' AND '".$to."')");
       }
       $query = $this->db->get();
       $result = $query->row_array();

       return $result;
    }

    public function getDeviceToken($customer_id)
    {

      $this->db->select('A.`key`, A.`user_id`, A.`device_token`,A.`date_created`, B.name');
      $this->db->from('keys A');
      $this->db->join('customers B', 'B.id=A.user_id', 'inner');
      $this->db->where('A.user_id',$customer_id);
      $this->db->where('A.user_type',6);
      $this->db->where('A.device_token IS NOT NULL');
      $this->db->order_by('A.id', 'DESC');
      $this->db->limit(4);
      $query = $this->db->get();
      $data = $query->result_array();
      return $data;
    }



}
