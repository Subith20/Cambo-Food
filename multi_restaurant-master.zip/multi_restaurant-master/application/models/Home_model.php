<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Home_model extends CI_Model {

    public function __construct() {
        parent::__construct();

        // Load the database library
        $this->load->database();
    }

    /*
     * Get rows from the users table
     */

     function GetHomeIcon($limit=null)
     {

       $bash_url=$this->config->item('base_url');
       $this->db->select('id,name,order_by');
       $this->db->from('products_cat');
       $this->db->where('is_home',1);
       $this->db->order_by("order_by", "asc");
       $query = $this->db->get();
       $menu_list = $query->result_array();

       foreach ($menu_list as $key => $value) {
         $image_details=$this->Generic_model->UploadFilesList('product_cat',$value['id']);
         $image_details=reset($image_details);
         //print_r($image_details);exit;
         $data['name']=$value['name'];
         $data['id']=$value['id'];
         $data['order_by']=$value['order_by'];
         $data['img']=$image_details['file_name']?$image_details['file_name']:null;
         $result[]=$data;

       }
       return ($result?$result:false);
     }

     function GetAppSettings()
     {
         $bash_url=$this->config->item('base_url');
         $this->db->select('*');
         $this->db->from('app_settings');
         $this->db->where('type="App Settings" or type="Shop Details"');
         $this->db->order_by("type", "asc");
         $query = $this->db->get();
         $settings = $query->result_array();


         return $settings;
     }

    
}
