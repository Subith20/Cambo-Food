<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Settings_model extends CI_Model {

    public function __construct() {
        parent::__construct();

        // Load the database library
        $this->load->database();
    }




    public function update($data){

        //insert user data to users table
        $id=$data['id'];
        unset($data['id']);
        //update user data in users table
        $update = $this->db->update('app_settings', $data, array('id'=>$id));
        return $update?true:false;
    }

    public function shop_status_update($status)
    {
      $update = $this->db->update('app_settings', array('value'=>$status), array('key'=>'shop_status'));
      return $update?true:false;
    }


    function list()
    {
      $this->db->select('*');
      $this->db->from('app_settings');
      $this->db->order_by('order_by');
      $query = $this->db->get();
      $data = $query->result_array();
      return $data;
    }

    function GetShopsTypeList()
     {
       $this->db->select('*');
       $this->db->from('shop_type');
       $this->db->where('is_deleted',0);
       $query = $this->db->get();
       $data = $query->result_array();
       return $data;
     }

    public function shipping_price_insert($data){
        $insert = $this->db->insert('shipping_price', $data);
        return $insert?$this->db->insert_id():false;
    }

    public function shipping_price_update($data, $id){
        $update = $this->db->update('shipping_price', $data, array('id'=>$id));
        return $update?true:false;

    }

    public function shipping_price_delete($id){
        $delete = $this->db->delete('shipping_price',array('id'=>$id));
        return $delete?true:false;
    }

    public function shipping_price_list()
    {
       $this->db->select('A.*');
       $this->db->from('shipping_price A');
       $this->db->order_by('distance');
       $query = $this->db->get();
       $result= $query->result_array();
       return $result;
    }

    public function maximum_shipping_distance()
    {
       $this->db->select('A.*');
       $this->db->from('shipping_price A');
       $this->db->order_by('distance','DESC');
       $query = $this->db->get();
       $result= $query->row_array();
       return $result;
    }

    public function shipping_price_details($id)
    {
       $this->db->select('A.*');
       $this->db->from('shipping_price A');
       $this->db->where('A.id',$id);
       $query = $this->db->get();
       $result= $query->row_array();
       return $result;
    }

    public function updated_list()
    {
      $this->db->select('count(id) as last_update');
       $this->db->from('crm_updates');
       $query = $this->db->get();
       $result= $query->row_array();
       return $result;
    }

    public function crm_updates($query)
    {

      return $this->db->query($query); 

    }

    public function PaymentModeList()
    {
      $this->db->select('id,code,name');
      $this->db->from('payment_mode');
      $this->db->where('is_deleted',0);
      $query = $this->db->get();
      $result = $query->result_array();
      return $result;
    }

    public function PaymentModeUpdate($id,$status)
    {
      //UPDATE `payment_mode` SET `is_deleted`='1' WHERE  `id`=5;
      $status=($status==1?0:1);
      $update = $this->db->update('payment_mode', array('is_deleted'=>$status), array('id'=>$id));
      //echo ">".$this->db->last_query();exit;
      return $update?true:false;
    }


}
