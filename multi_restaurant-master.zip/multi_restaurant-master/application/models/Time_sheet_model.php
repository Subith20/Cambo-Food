<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Time_sheet_model extends CI_Model {

    public function __construct() {
        parent::__construct();

        // Load the database library
        $this->load->database();

    }

     function timeSheet_select_list()
     {
       $this->db->select('A.*');
       $this->db->from('time_sheet_list A');
       $this->db->where('status',1);
       $query = $this->db->get();
       $data = $query->result_array();
       return $data;

     }

     function sheet_time_data($id)
     {
       $this->db->select('A.*');
       $this->db->from('time_sheet A');
       $this->db->where('group_id',$id);
       $query = $this->db->get();
       $data = $query->result_array();
       return $data;

     }

     function GetTimeDatatable($user_id=0)
     {
       $this->db->select('A.*');
       $this->db->from('time_sheet_group A');
       if($user_id>0)
       {
        $this->db->where('manager_id',$user_id);
       }
       $query = $this->db->get();
       $data = $query->result_array();
       return $data;

     }

     function GetShopTimeSelectionList($user_id=0)
     {
       $this->db->select('A.*');
       $this->db->from('time_sheet_group A');
       if($user_id>0)
       {
        $this->db->where('manager_id='.$user_id.' or manager_id=0');
        
       }
       else {
         $this->db->where('manager_id',0);
       }
       

       $query = $this->db->get();
       $data = $query->result_array();
       return $data;

     }


    function currentTimeSheet($time=null)
    {
      $today_day=strtolower(date('D'));
      $avail_days[]=$today_day;
      $avail_days[]="all";
      if($today_day=='sat')
      {
        $avail_days[]="sat-sun";
        $avail_days[]="week_full";
      }
      else if($today_day=='sun')
      {
        $avail_days[]="sat-sun";
      }
      else {
        $avail_days[]="week";
        $avail_days[]="week_full";
      }

       $this->db->select('DISTINCT(A.group_id) AS time_sheet');
       $this->db->from('time_sheet A');

       if(!empty($avail_days))
       {
         $this->db->where_in('A.day',$avail_days);
       }

       if($time==null)
       {
          $this->db->where('(CURTIME() >= A.`from` and CURTIME() <= A.`to`) or A.`from`=A.`to`');
       }
       
       $query = $this->db->get();
       //echo $this->db->last_query();exit;
       $data = $query->result_array();
       foreach($data as $value)
       {
          $result[]=$value['time_sheet'];
       }
       return $result;

    }


    function timeSheet_select_day()
    {
      return array('all'=>'All Days','week'=>'Monday to Friday','week_full'=>'Monday to Saturday','sat-sun'=>'Saturday & Sunday',
        'sun'=>'Sunday','mon'=>'Monday','tue'=>'Tuesday','wed'=>'Wednesday','thu'=>'Thursday','fri'=>'Friday','sat'=>'Saturday'

      );
    }


    function GetDetails($id)
     {
       $this->db->select('*');
       $this->db->from('time_sheet_group');
       $this->db->where('id',$id);
       $query = $this->db->get();
       $data = $query->row_array();
       return $data;
     }




     public function new($request)
     {

       $insert = $this->db->insert('time_sheet_group', $request);
       //return the status
       return $insert?$this->db->insert_id():false;
     }

     public function newTime($request)
     {

       $insert = $this->db->insert('time_sheet', $request);
       //return the status
       return $insert?$this->db->insert_id():false;
     }


    public function update($data, $id){

     //echo "<pre>".$id;print_r($data);exit;

        $update = $this->db->update('time_sheet_group', $data, array('id'=>$id));
        //echo $this->db->last_query();exit;
        //return the status
        return $update?true:false;

    }

    public function myShopStatusUpdate($id, $user_id, $status){
        $update = $this->db->update('shops', array('is_available'=>$status), array('id'=>$id,'user_id'=>$user_id));
       // echo $this->db->last_query();exit;
        return $update?true:false;

    }


    public function sheetDelete($id){

        $delete = $this->db->delete('time_sheet_group',array('id'=>$id));
        //return the status
        return $delete?true:false;
    }

     public function DeleteTime($id){

        $delete = $this->db->delete('time_sheet',array('id'=>$id));
        //return the status
        return $delete?true:false;
    }



}
