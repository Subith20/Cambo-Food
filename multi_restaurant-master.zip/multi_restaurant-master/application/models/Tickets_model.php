<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Tickets_model extends CI_Model {

    public function __construct() {
        parent::__construct();

        // Load the database library
        $this->load->database();

        $this->ticketTbl = 'ticket';
    }

    function GetTicketList($request=null)
    {
      $this->db->select('A.*, B.name as customer_name, B.phone as customer_phone,
      E.name as ticket_status_name');
      $this->db->from($this->ticketTbl.' A');
      $this->db->join('customers B', 'B.id = A.customer_id', 'inner');
      $this->db->join('ticket_status E','E.id=A.status','left');

      $this->db->order_by('A.id');
      if($request['from']&&$request['to'])
      {
        $this->db->where('A.job_date>=',$request['from']);
        $this->db->where('A.job_date<=',$request['to']);
      }

      if($request['FL_ticket_status']>0)
      {
        $this->db->where('A.status=',$request['FL_ticket_status']);
      }
      if($request['FL_ticket_type']>0)
      {
        $this->db->where('A.type=',$request['FL_ticket_type']);
      }


      $query = $this->db->get();
      $data = $query->result_array();
      return $data;
    }

    function GetCustomerTickets($request)
    {
      $this->db->select('A.*');
      $this->db->from($this->ticketTbl.' A');
      $this->db->join('orders B', 'B.id = A.order_id', 'inner');
      $this->db->join('ticket_status E','E.id=A.status','left');
      $this->db->order_by('A.id', 'DESC');
      if($request['from'] && $request['to'])
      {
        $this->db->where('A.create_on>=',$request['from']);
        $this->db->where('A.create_on<=',$request['to']);
      }

      if($request['ticket_status']>0)
      {
        $this->db->where('A.status=',$request['ticket_status']);
      }
      $query = $this->db->get();
      $data = $query->result_array();
      return $data;
    }


    public function GetTicketDetails($id)
    {
      $this->db->select('A.*, B.name as lead_name, B.phone as lead_phone,B.phone2 as lead_phone2, B.address, B.city, B.area, B.zip, E.name as ticket_status_name,F.name as ticket_head_name,H.name as ticket_priority_name');
      $this->db->from($this->ticketTbl.' A');
      $this->db->join('customers B', 'B.id = A.customer_id', 'inner');
      $this->db->join('ticket_status E','E.id=A.`status`','left');
      $this->db->join('services_cat F','F.id=A.head','left');
      $this->db->join('ticket_priority H','H.id=A.priority','left');
      $this->db->where('A.id=',$id);
      $query = $this->db->get();
      $data = $query->result_array();
      return $data[0];
    }

     
    /*
     * Insert user data
     */
    public function NewTicket($data){
        $insert = $this->db->insert('ticket', $data);
        //return the status
        return $insert?$this->db->insert_id():false;
    }

    public function InsertTicketHistory($data){
        //insert user data to users table
        $insert = $this->db->insert('ticket_history', $data);
        //return the status
        return $insert?$this->db->insert_id():false;
    }

    public function getTicketHistory($id)
    {
      $this->db->select('A.notes,A.date,B.first_name');
      $this->db->from('ticket_history A');
      $this->db->join('users B','B.id=A.user_id','left');
      $this->db->where('related_id', $id);
      $this->db->where('related_table', 1);
      $this->db->order_by('A.id', 'DESC');
      $query = $this->db->get();
      $data = $query->result_array();
      return $data;
    }

    
    public function GetCustomerTicketDetails($customer_id)
    {
      $this->db->select('A.id,A.detail,A.create_on,A.job_date,B.name AS status,C.name AS head,D.first_name AS assign_to, E.first_name AS executive,F.name AS type, G.name AS priority');
      $this->db->from('ticket A');
      $this->db->join('ticket_status B','B.id=A.`status`','left');
      $this->db->join('services_cat C','C.id=A.head','left');
      $this->db->join('users D','D.id=A.assign_to','left');
      $this->db->join('users E','E.id=A.executive','left');
      $this->db->join('ticket_type F','F.id=A.type','left');
      $this->db->join('ticket_priority G','G.id=A.priority','left');
      $this->db->where('customers', $customer_id);
      $this->db->order_by('A.id', 'DESC');
      $query = $this->db->get();
      $data = $query->result_array();
      return $data;
    }

    public function ticket_status()
    {
      $this->db->select('*');
      $this->db->from('ticket_status');
      $query = $this->db->get();
      $data = $query->result_array();
      foreach ($data as $key => $value) {
        $result[$value['id']]=$value;
      }
      return $result;
    }

    public function ticket_type()
    {
      $this->db->select('*');
      $this->db->from('ticket_type');
      $query = $this->db->get();
      $data = $query->result_array();
      foreach ($data as $key => $value) {
        $result[$value['id']]=$value;
      }
      return $result;
    }

    public function ticket_priority()
    {
      $this->db->select('*');
      $this->db->from('ticket_priority');
      $query = $this->db->get();
      $data = $query->result_array();
      foreach ($data as $key => $value) {
        $result[$value['id']]=$value;
      }
      return $result;
    }


    public function update($data, $id){
      //print_r($data);exit;

        $update = $this->db->update('ticket', $data, array('id'=>$id));
        //echo $this->db->last_query();
        //return the status
        return $update?true:false;

    }


}
