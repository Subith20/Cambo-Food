<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Banner_model extends CI_Model {

    public function __construct() {
        parent::__construct();

        // Load the database library
        $this->load->database();

        $this->tbl = 'banners';
    }

    public function new($data){
        //insert user data to users table
        $insert = $this->db->insert($this->tbl, $data);
        //return the status
        return $insert?$this->db->insert_id():false;
    }

    public function update($data){

        //insert user data to users table
        $id=$data['id'];
        unset($data['id']);
        //update user data in users table
        $update = $this->db->update($this->tbl, $data, array('id'=>$id));

        //return the status
        return $update?true:false;
    }



    function GetList()
    {
      $this->db->select('*');
      $this->db->from($this->tbl);
      $query = $this->db->get();
      $data = $query->result_array();
      return $data;
    }

    function GetBannerDetails($id)
    {
      $this->db->select('*');
      $this->db->from($this->tbl);
      $this->db->where('id', $id);
      $query = $this->db->get();
      $data = $query->row_array();
      return $data;
    }

    public function delete($id){
        $delete = $this->db->delete($this->tbl,array('id'=>$id));
        //return the status
        return $delete?true:false;
    }

}
