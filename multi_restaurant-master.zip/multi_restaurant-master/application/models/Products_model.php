<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Products_model extends CI_Model {

    public function __construct() {
        parent::__construct();

        // Load the database library
        $this->load->database();
        $this->load->model('Generic_model');
        $this->load->model('Settings_model');
        $this->load->model('Time_sheet_model');
    }


     function getProductCount()
     {
       $this->db->select('DISTINCT(category_id)');
       $this->db->from('products');
       $this->db->order_by('category_id');
       $query = $this->db->get();
       $data = $query->result_array();

       foreach ($data as $key => $value) {
         $this->db->select('count(*)');
         $this->db->from('products');
         $this->db->where('category_id', $value['category_id']);
         $query1 = $this->db->get();
         $data2 = $query1->result_array();
         $data2[0]['ID']=$value['category_id'];
         $value['category_id'].",";
         $data2[0]['count(*)']."\n";
       }

       return $result;
     }

     function listViewProductCat($request=null)
     {
       $this->db->select('A.*, B.name AS master_name, COUNT(C.id) AS product_count');
       $this->db->from('products_cat A');
       $this->db->join('products_cat B', 'B.id = A.master_id', 'left');
       $this->db->join('products C', 'C.category_id=A.id', 'left');
       $this->db->group_by('A.id');
       if($request['owner_id'])
       {
        //echo $request['owner_id'];exit;
         $this->db->where('A.user_id', $request['owner_id']);
       }
       $query = $this->db->get();
       $data = $query->result_array();
       return $data;

     }

     function SpecialCatList($active=false)
     {
       $this->db->select('A.*');
       $this->db->from('special_cat A');
       if($active!='all')
       {
         $this->db->where('A.status', 1);
       }
       $query = $this->db->get();
       $data = $query->result_array();
       return $data;

     }

     function SpecialList($spl_cat_id=null)
     {
       $this->db->select('A.*, B.name as special_cat_name, B.status as special_cat_status, C.name as name,C.sale_price,C.mrp, C.is_avail');
       $this->db->from('special_product A');
       $this->db->join('special_cat B', 'B.id = A.special_cat_id', 'left');
       $this->db->join('products C', 'C.id = A.product_id', 'left');
       if($spl_cat_id>0)
       {
         $this->db->where('A.special_cat_id',$spl_cat_id);
       }
       $query = $this->db->get();
       $data = $query->result_array();
       return $data;

     }

     function SpeciaDetails($id)
     {
       $this->db->select('A.*, B.name as special_cat_name, B.status as special_cat_status, C.name as name');
       $this->db->from('special_product A');
       $this->db->join('special_cat B', 'B.id = A.special_cat_id', 'left');
       $this->db->join('products C', 'C.id = A.product_id', 'left');
       $this->db->where('A.id',$id);
       $query = $this->db->get();
       $data = $query->row_array();
       return $data;

     }

     function ProductCatSelectList($request=null)
     {
       $this->db->select('A.id,A.name,A.status,A.user_id, B.name AS master_name');
       $this->db->from('products_cat A');
       $this->db->join('products_cat B', 'B.id = A.master_id', 'left');
       if($request['active']==true)
       {
          $this->db->where('A.status',1);
       }

       if($request['user_id']==true)
       {
          $this->db->where('A.user_id='.$request['user_id'].' or A.user_id=0');
       }

       $this->db->group_by('A.id');
       $query = $this->db->get();
       $data = $query->result_array();
       return $data;
     }

     function ManagerProductCatList($request=null)
     {
       $this->db->select('A.id,A.name,A.status,A.user_id, count(B.id) as total_product');
       $this->db->from('products_cat A');
       $this->db->join("products B","B.category_id = A.id AND B.shop_id = '".$request['shop_id']."'",'left');
       $this->db->group_by('A.id');
       if($request['active']==true)
       {
          $this->db->where('A.status',1);
       }

       $this->db->where('A.user_id='.$request['user_id'].' or A.user_id=0');
       $this->db->group_by('A.id');
       $this->db->order_by('total_product','desc');
       $query = $this->db->get();
       //echo $this->db->last_query();exit;
       $data = $query->result_array();
       return $data;
     }



      
     public function new($request)
     {

       $insert = $this->db->insert('products', $request);
       //return the status
       return $insert?$this->db->insert_id():false;
     }

     public function special_product_new($request)
     {

       $insert = $this->db->insert('special_product', $request);
       //return the status
       return $insert?$this->db->insert_id():false;
     }

     public function extras_new($request)
     {

       $insert = $this->db->insert('extras', $request);
       //return the status
       return $insert?$this->db->insert_id():false;
     }

     public function extras_group_new($request)
     {

       $insert = $this->db->insert('extras_group', $request);
       //return the status
       return $insert?$this->db->insert_id():false;
     }

     function GetProductCat($request=null)
     {

       $this->db->select('id,name,details,status,order_by,master_id');
       $this->db->from('products_cat');
       //$this->db->order_by('order_by');
       if($request['status']!='all')
       {
             $this->db->where('status', 1);
       }

       if($request['product_cat_id']>0)
       {
         //$this->db->where_in('master_id', $request['product_cat_id']);
         $this->db->where("find_in_set('".$request['product_cat_id']."', master_id)");

       }
       elseif($request['product_cat_id']!='all' || !$request['product_cat_id'] ) {
         $this->db->where('master_id', 0);
       }

       
       $query = $this->db->get();
       $data = $query->result_array();
       $result=null;
       foreach ($data as $key => $value) {
         $value['type']="products_cat";
         $img_list=$this->Generic_model->UploadFilesList('product_cat',$value['id']);
         $img_list=reset($img_list);
         $value['img']=$img_list['file_name'];
         $result[]=$value;
       }
       return $result;
     }

     function GetProduct_type()
     {

       $this->db->select('*');
       $this->db->from('product_type');
       $this->db->order_by('id');
       $query = $this->db->get();
       $data = $query->result_array();
       return $data;

     }

     function GetRestProductList($request=null)
     {
       $base_url=$this->config->item('base_url');
       $extras_group_type=$this->config->item('extras_group_type');
       $max_count=$this->config->item('max_product_count');
       $this->db->select('A.id,A.name,A.details,A.is_avail,A.sale_price,A.mrp,A.category_id, A.quantity,A.unit, A.max_count,A.type,A.avail_time,B.name as type_name, C.name as cat_name, CONCAT('."'".$base_url."'".',D.file_name) AS img');
       $this->db->from('products A');
       $this->db->join('product_type B', 'B.id = A.type', 'left');
       $this->db->join('products_cat C', 'C.id = A.category_id', 'left');
       $this->db->join('media D', "D.related_id = A.id and D.model_type='products'", 'left');
       $this->db->order_by('id');

       if(!$request['is_avail'])
       {
             $this->db->where('A.is_avail', 1);
       }


       if($request['shop_id']>0)
       {

             $this->db->where('A.shop_id', $request['shop_id']);
       }

       if($request['product_cat_id']>0)
       {
         //$this->db->where('category_id', $request['product_cat_id']);
         $this->db->where("find_in_set('".$request['product_cat_id']."', A.category_id)");
       }
       elseif(($request['product_cat_id']!='all' || !$request['product_cat_id']) && $request!=null && !$request['shop_id']) {
         $this->db->where('A.category_id', 0);
       }


       $query = $this->db->get();
       //echo $this->db->last_query();
       $data = $query->result_array();
       $available_time_sheet=$this->Time_sheet_model->currentTimeSheet();
       //echo "<pre>";print_r($available_time_sheet);exit;
       foreach ($data as $key => $value) {
        //echo "<pre>";print_r($value);
        if(!in_array($value['avail_time'],$available_time_sheet) and $value['avail_time']>0)
        {
          $data[$key]['is_avail']=0;
          $value['is_avail']=0;
        }
       // echo "<pre>";print_r($data[$key]);exit;

         $value['count']=0;
         $value['max_count']=$value['max_count'];

         $value['extras_group']=array();
         if($request['extras']==true)
         {

            $extras_group=$this->GetProductExtrasGroup($value['id']);
            if($request['extras_type']=='all')
            {
                $extras=$this->GetProductExtras($value['id']);
            }
            else {
              $extras=$this->GetActiveProductExtras($value['id']); 
            }
             
            
            foreach ($extras_group as $gp_value) {
              $gp_value['type_name']=$extras_group_type[$gp_value['type']];
              foreach ($extras as $extra_key=>$extra_value) {
                if($extra_value['group_id']==$gp_value['id'])
                {
                  $gp_value['extras'][]=$extra_value;
                  unset($extras[$extra_key]);
                }
              }
              
              $value['extras_group'][]=$gp_value;
              
            }
         }
         

         $item_list[$value['category_id']][]=$value;
         $category_list[$value['category_id']]=$value['cat_name'];
       }
       //echo "<pre>";print_r($data);exit;

       foreach ($category_list as $key=>$value) {
         $catimg=$this->Generic_model->UploadFilesList('product_cat',$key);
         $catimg=reset($catimg);
         $cat_img_path=$catimg['file_name'];
         $cat_tmp=array(
          'category_id'=>$key,
          'category_name'=>$value,
          'img'=>$cat_img_path,
          'list'=>$item_list[$key]
          );
         $result[]=$cat_tmp;
       }

       return $result;
     }

     function GetProductListDatatable($shop_id=null)
     {
      $base_url=$this->config->item('base_url');
       $this->db->select('A.*, B.name as shop_name, C.name as cat_name, D.name as type_name,, CONCAT('."'".$base_url."'".',E.file_name) AS img');
       $this->db->from('products A');
       $this->db->join('shops B', 'B.id = A.shop_id', 'inner');
       $this->db->join('products_cat C', 'C.id = A.category_id', 'left');
       $this->db->join('product_type D', 'D.id = A.type', 'left');
       $this->db->join('media E', "E.related_id = A.id and E.model_type='products'", 'left');
       if($shop_id>0)
       {
         $this->db->where('A.shop_id', $shop_id);
       }
       $this->db->order_by('id');
       $query = $this->db->get();
       $data = $query->result_array();
       return $data;
     }

     function MangerProductListDatatable($shop_id,$cat_id=null)
     {
      $base_url=$this->config->item('base_url');
       $this->db->select('A.*, B.name as shop_name, C.name as cat_name, D.name as type_name,, CONCAT('."'".$base_url."'".',E.file_name) AS img');
       $this->db->from('products A');
       $this->db->join('shops B', 'B.id = A.shop_id', 'inner');
       $this->db->join('products_cat C', 'C.id = A.category_id', 'left');
       $this->db->join('product_type D', 'D.id = A.type', 'left');
       $this->db->join('media E', "E.related_id = A.id and E.model_type='products'", 'left');
       $this->db->where('A.shop_id', $shop_id);
       if($cat_id)
       {
          $this->db->where('A.category_id', $cat_id);
       }
       
       $this->db->order_by('id');
       $query = $this->db->get();
       $data = $query->result_array();
       return $data;
     }

     function POSProductList($shop_id,$cat_id=null)
     {
       $this->db->select('A.*,count(B.id) as extra_count,C.name as cat_name, D.name as type_name');
       $this->db->from('products A');
       $this->db->join("extras B","B.product_id = A.id ",'left');
       $this->db->join('products_cat C', 'C.id = A.category_id', 'left');
       $this->db->join('product_type D', 'D.id = A.type', 'left');
       $this->db->where('A.shop_id', $shop_id);
       if($cat_id)
       {
          $this->db->where('A.category_id', $cat_id);
       }
       $this->db->group_by('A.id');
       $this->db->order_by('id');
       $query = $this->db->get();
       $data = $query->result_array();
       foreach ($data as $value) {
         $result[$value['category_id']]['name']=$value['cat_name'];
         /////////////////////
            $extras_group=$this->GetProductExtrasGroup($value['id']);
            $extras=$this->GetActiveProductExtras($value['id']); 
          
            foreach ($extras_group as $gp_value) {
              $gp_value['type_name']=$extras_group_type[$gp_value['type']];
              foreach ($extras as $extra_key=>$extra_value) {
                if($extra_value['group_id']==$gp_value['id'])
                {
                  $gp_value['extras'][]=$extra_value;
                  unset($extras[$extra_key]);
                }
              }
              
              $value['extras_group'][]=$gp_value;
              
            }
         
         ////////////////////
         $result[$value['category_id']]['list'][$value['id']]=$value;
        // $all_product[$value['id']]=$value;
       }
       return $result;
     }

     function GetActiveProductList()
     {
       $this->db->select('A.id,A.name,A.is_avail,C.name as cat_name');
       $this->db->from('products A');
       $this->db->join('products_cat C', 'C.id = A.category_id', 'left');
       $this->db->order_by('id');
       $this->db->where('A.is_avail', 1);
       $query = $this->db->get();
       $data = $query->result_array();
       return $data;
     }

     function GetProductExtras($id)
     {
       $this->db->select('id,name,mrp,price,product_id,status,maximum_order,group_id');
       $this->db->from('extras');
       $this->db->order_by('group_id');
       $this->db->where('product_id', $id);
       $query = $this->db->get();
       $data = $query->result_array();
       return $data;
     }

     function GetProductExtrasGroup($id)
     {
       $this->db->select('*');
       $this->db->from('extras_group');
       $this->db->where('product_id', $id);
       $query = $this->db->get();
       $data = $query->result_array();
       return $data;
     }

     function extras_details($id)
     {
       $this->db->select('id,name,mrp,price,product_id,status,maximum_order,group_id');
       $this->db->from('extras');
       $this->db->where('id', $id);
       $query = $this->db->get();
       $data = $query->row_array();
       return $data;
     }

     function extras_group_details($id)
     {
       $this->db->select('*');
       $this->db->from('extras_group');
       $this->db->where('id', $id);
       $query = $this->db->get();
       $data = $query->row_array();
       return $data;
     }

     function GetActiveProductExtras($id)
     {
       $this->db->select('id,name,mrp,price,product_id,status,maximum_order,group_id');
       $this->db->from('extras');
       $this->db->order_by('group_id');
       $this->db->where('product_id', $id);
       $this->db->where('status',1);
       $query = $this->db->get();
       $data = $query->result_array();
       return $data;
     }

     function CheckProductExtras_array($id,$extras_array)
     {
       if(!empty($extras_array) and $id>0)
       {
         $this->db->select('id,name,mrp,price,product_id,status,maximum_order,group_id');
       $this->db->from('extras');
       $this->db->where('product_id', $id);
       $this->db->where('status',1);
       foreach ($extras_array as $value) {
         $where_array[]="id=".$value;
       }

       if($where_array)
       {
        $this->db->where('('.implode(' or ', $where_array).')');
       }
       $query = $this->db->get();
       $data = $query->result_array();
       return $data;
       }
       else
       {
         return array();
       }
       
     }

     function extrasStatusUpdate($id,$status)
     {
       $this->db->where('id', $id);
       $this->db->set('status', $status);
       $this->db->update('extras');
       return $this->db->affected_rows();
     }

     

     function GetProductCatDetails($id)
     {  
       $this->db->select('*');
       $this->db->from('products_cat');
       $this->db->where('id', $id);
       $query = $this->db->get();
       $data = $query->row_array();
       return $data;
     }

     function GetProductDetails($id)
     { 
       $this->db->select('A.*,B.name as type_name, C.name as cat_name, D.name as shop_name');
       $this->db->from('products A');
       $this->db->join('product_type B', 'B.id = A.type', 'left');
       $this->db->join('products_cat C', 'C.id = A.category_id', 'left');
       $this->db->join('shops D', 'D.id=A.shop_id', 'inner');
       $this->db->where('A.id', $id);
       $query = $this->db->get();
       $data = $query->row_array();
       return $data;
     }

     function myProductDetails($user_id,$id)
     {
       $base_url=$this->config->item('base_url');
       $this->db->select('A.*,B.name as type_name, C.name as cat_name, D.name as shop_name, CONCAT('."'".$base_url."'".',E.file_name) AS img');
       $this->db->from('products A');
       $this->db->join('product_type B', 'B.id = A.type', 'left');
       $this->db->join('products_cat C', 'C.id = A.category_id', 'left');
       $this->db->join('shops D', 'D.id=A.shop_id', 'inner');
       $this->db->join('media E', "E.related_id = A.id and E.model_type='products'", 'left');
       $this->db->where('A.id', $id);
       $this->db->where('D.user_id', $user_id);
       $query = $this->db->get();
       $data = $query->row_array();
       return $data;

     }

     function CartExtrasList($id)
     {
       $this->db->select('A.*,B.name,B.mrp,B.price,B.status,C.name as extras_group');
       $this->db->from('cart_extras A');
       $this->db->join('extras B','B.id = A.extras_id','inner');
       $this->db->join('extras_group C','C.id = B.group_id','inner');
       $this->db->where('A.cart_list_id', $id);
       //$this->db->where('B.status', 1);
       $query = $this->db->get();
       return $query->result_array();

     }

     function AllCartExtrasList($user_id)
     {
       $this->db->select('A.*,B.name,B.mrp,B.price,B.status,C.name as extras_group');
       $this->db->from('cart_extras A');
       $this->db->join('extras B','B.id = A.extras_id','inner');
       $this->db->join('extras_group C','C.id = B.group_id','inner');
       $this->db->join('cart D','D.id = A.cart_list_id','inner');
       $this->db->where('D.user_id', $user_id);
       $query = $this->db->get();
       $data=$query->result_array();
       $result=array();
       foreach ($data as $value) {
        // $value['subtotal']=$value['price']*$value['count'];
         $result[$value['cart_list_id']][]=$value;
       }
       return $result;

     }

     function checkPermission($user_id,$product_id)
    {
      $this->db->select('A.id');
       $this->db->from('products A');
       $this->db->join('shops B','B.id = A.shop_id','inner');
       $this->db->where('B.user_id',$user_id);
       $this->db->where('A.id',$product_id);
       $query = $this->db->get();
       $data = $query->row_array();
       return $data['id']?true:false;
    }

    function checkCatPermission($user_id,$cat_id)
    {
      $this->db->select('A.id');
       $this->db->from('products_cat A');
       $this->db->where('A.user_id',$user_id);
       $this->db->where('A.id',$cat_id);
       $query = $this->db->get();
       $data = $query->row_array();
       return $data['id']?true:false;
    }

     function CartList($user_id)
     {

       $total_amount=0;
       $total_tax_amount=0;
       $packing_charges=0;

       $this->db->select('A.*,B.name as product_name,B.mrp,B.sale_price, B.quantity as product_quantity,B.avail_time, B.tax, B.packing_charges,B.type,C.name as type_name,B.is_avail,B.shop_id,D.file_name as img');
       $this->db->from('cart A');
       $this->db->join('products B','B.id = A.product_id','inner');
       $this->db->join('product_type C', 'C.id = B.type', 'left');
       $this->db->join('media D', "D.related_id = B.id and model_type='products'", 'left');
       $this->db->where('A.user_id', $user_id);
       $query = $this->db->get();
       $data = $query->result_array();

       $all_extras=$this->AllCartExtrasList($user_id);
       foreach ($data as $value) {
        $extras_total=0;
        $cart_extras_list=$all_extras[$value['id']];
        foreach ($cart_extras_list as $extrs_value)
        {
          $extras_total+=$extrs_value['price']*$value['count'];
        }

        $value['extras_impload']=array_column($cart_extras_list, 'extras_id');
        $value['extras_impload']=implode(',', $value['extras_impload']);
        $value['extras']=$cart_extras_list?$cart_extras_list:array();
          
        
        $value['extras_total_amount']=$extras_total;
        $value['sub_total_amount']=$value['sale_price']*$value['count'];
        $value['sub_tax_amount']=round(((($value['sub_total_amount']+$value['extras_total_amount'])/100)*$value['tax']),2);
        $value['sub_packing_charges']=$value['packing_charges']*$value['count'];
        $value['total']=$value['extras_total_amount']+$value['sub_packing_charges']+$value['sub_total_amount']+$value['sub_tax_amount'];
        $value['mrp']=(float)$value['mrp'];
        $value['sale_price']=(float)$value['sale_price'];
        $value['tax']=(float)$value['tax'];
        $value['count']=(int)$value['count'];
         $result[]=$value;
       }
       return $result;
     }

     function basicCartList($user_id)
     {

       $total_amount=0;
       $total_tax_amount=0;
       $packing_charges=0;

       $this->db->select('A.*,B.name as product_name,B.mrp,B.sale_price, B.quantity as product_quantity, B.tax, B.packing_charges,B.type,B.is_avail,B.shop_id');
       $this->db->from('cart A');
       $this->db->join('products B','B.id = A.product_id','inner');
       $this->db->where('A.user_id', $user_id);
       $query = $this->db->get();
       $data = $query->result_array();

       $all_extras=$this->AllCartExtrasList($user_id);
       foreach ($data as $value) {
        $extras_total=0;
        $cart_extras_list=$all_extras[$value['id']];
        foreach ($cart_extras_list as $extrs_value)
        {
          $extras_total+=$extrs_value['price']*$value['count'];
        }

        $value['extras_impload']=array_column($cart_extras_list, 'extras_id');
        $value['extras_impload']=implode(',', $value['extras_impload']);
        $value['extras']=$cart_extras_list?$cart_extras_list:array();
          
        
        $value['extras_total_amount']=$extras_total;
        $value['sub_total_amount']=$value['sale_price']*$value['count'];
        $value['sub_tax_amount']=round(((($value['sub_total_amount']+$value['extras_total_amount'])/100)*$value['tax']),2);
        $value['sub_packing_charges']=$value['packing_charges']*$value['count'];
        $value['total']=$value['extras_total_amount']+$value['sub_packing_charges']+$value['sub_total_amount']+$value['sub_tax_amount'];
        
         $result[]=$value;
       }
       return $result;
     }


     public function AddToCart($product_id,$user_id,$qty=1){
         $data['product_id']=$product_id;
         $data['user_id']=$user_id;
         $data['count']=$qty>0?$qty:1;
         //insert user data to users table
         $insert = $this->db->insert('cart', $data);
         return $insert?$this->db->insert_id():false;
     }

     public function AddExtraToCart($cart_id,$extras_id,$qty=1){
         $data['cart_list_id']=$cart_id;
         $data['extras_id']=$extras_id;
         $data['count']=$qty>0?$qty:1;
         //insert user data to users table
         $insert = $this->db->insert('cart_extras', $data);
         return $insert?$this->db->insert_id():false;
     }

     public function UpdateCart($id,$qty=1){

       $this->db->where('id', $id);
       $this->db->set('count', $qty);
       $this->db->update('cart');
       return $this->db->affected_rows();
     }

     public function RemoveFromCart($id){
       $this->db->where('id', $id);
       $this->db->delete('cart');
       return $this->db->affected_rows();
     }

     public function RemoveFromMyCart($id,$user_id){
       $this->db->where('id', $id);
       $this->db->where('user_id', $user_id);
       $this->db->delete('cart');
       return $this->db->affected_rows();
     }

     public function ClearCartList($user_id){
       $this->db->where('user_id', $user_id);
       $this->db->delete('cart');
       return $this->db->affected_rows();
     }

     public function CheckInCart($product_id,$user_id){
       $this->db->select('*');
       $this->db->from('cart');
       $this->db->where('user_id', $user_id);
       $this->db->where('product_id', $product_id);
       $query = $this->db->get();
       $data = $query->row_array();
       /*
       if($data['id']>0)
       {
          $extras_list=$this->getcartextra($data['id']);
          $extras_ids =implode(',', array_column($extras_list, 'extras_id'));
       }
       $data['extras']=$extras_ids?$extras_ids:null;*/
       return $data;
     }

/*
     public function getcartextra($cart_id=0)
     {
        $this->db->select('*');
        $this->db->from('cart_extras');
        $this->db->where('cart_list_id', $cart_id);
        $query = $this->db->get();
        $data = $query->result_array();
        return $data;
     }*/

    /*
     * Insert user data
     */
    public function insert($data){
        //insert user data to users table
        $insert = $this->db->insert('products', $data);
        //return the status
        return $insert?$this->db->insert_id():false;
    }

    public function Product_catInsert($data){
        //insert user data to users table
        $insert = $this->db->insert('products_cat', $data);
        //return the status
        return $insert?$this->db->insert_id():false;
    }



    public function update($data, $id){

        //update user data in users table
        $update = $this->db->update('products', $data, array('id'=>$id));

        //return the status
        return $update?true:false;

    }

    public function UpdateCartProduct($cart_id, $user_id, $qty){

        //update user data in users table
      $data=array('count'=>$qty);
        $update = $this->db->update('cart', $data, array('id'=>$cart_id,'user_id'=>$user_id));

        //return the status
        return $update?true:false;

    }

    public function extras_update($data, $id){
        $update = $this->db->update('extras', $data, array('id'=>$id));
        return $update?true:false;
    }

    public function extras_group_update($data, $id){
        $update = $this->db->update('extras_group', $data, array('id'=>$id));
        return $update?true:false;
    }

    public function product_extras_auto_off($id)
    {
      $data['is_stackable']=0;
      $data['stock_count']=0;
      $update = $this->db->update('extras', $data, array('product_id'=>$id,'is_stackable'=>2));
      echo $this->db->last_query();exit;
        return $update?true:false;
    }

    public function special_product_update($data, $id){

        //update user data in users table
        $update = $this->db->update('special_product', $data, array('id'=>$id));

        //return the status
        return $update?true:false;

    }

    public function updateCat($data, $id){

        //update user data in users table
        $update = $this->db->update('products_cat', $data, array('id'=>$id));

        //return the status
        return $update?true:false;

    }

    public function delete($id){
        //update user from users table
        $delete = $this->db->delete('products',array('id'=>$id));
        //return the status
        return $delete?true:false;
    }

    public function extrasDelete($id){
        //update user from users table
        $delete = $this->db->delete('extras',array('id'=>$id));
        //return the status
        return $delete?true:false;
    }
    public function extras_group_delete($id){
        //update user from users table
        $delete = $this->db->delete('extras_group',array('id'=>$id));
        //return the status
        return $delete?true:false;
    }

    public function deleteCat($id){
        //update user from users table
        $delete = $this->db->delete('products_cat',array('id'=>$id));
        //return the status
        return $delete?true:false;
    }

    public function deleteSpecialProduct($id){
        //update user from users table
        $delete = $this->db->delete('special_product',array('id'=>$id));
        //return the status
        return $delete?true:false;
    }


    function UnitsList()
     {
       $this->db->select('*');
       $this->db->from('product_units');
       $query = $this->db->get();
       $data = $query->result_array();
       return $data;
     }

    function getActiveProducts()
    {

       $this->db->select('count(id) as count');
       $this->db->from('products');
       $this->db->where('is_avail',1);
       $query = $this->db->get();
       $result = $query->row_array();

       return $result;
    }


    function SearchProductNearShops($lat,$long,$search_input)
    {
      $base_url=$this->config->item('base_url');
      $max_distance=$this->Settings_model->maximum_shipping_distance();
      $max_distance=$max_distance['distance'];

      $query="`A`.`id`, `A`.`name`,  `A`.`type`,A.mrp,A.sale_price,B.name AS shop_name,A.shop_id,A.is_avail,A.avail_time,B.avail_time as shop_time_sheet,D.name AS category_name,E.name AS type_name, CONCAT('".$base_url."',C.file_name) AS img, ROUND(SQRT( POW(69.1 * (B.latitude - ".$lat."), 2) + POW(69.1 * (".$long." - B.longitude) * COS(B.latitude / 57.3), 2)),2) AS distance";

       $this->db->select($query);
       $this->db->from('products A');
       $this->db->join('shops B', 'B.id = A.shop_id', 'inner');
       $this->db->join('media C', "C.related_id = A.id and C.model_type='products'", 'inner');
       $this->db->join('products_cat D', 'D.id = A.category_id', 'left');
       $this->db->join('product_type E', 'E.id = A.type', 'left');
       $this->db->where('A.is_avail',1);
       $this->db->where('B.is_available',1);
       $this->db->where('B.is_deleted',0);
       if($search_input)
       {
         $this->db->where("(A.name LIKE '%".$search_input."%' or D.name LIKE '%".$search_input."%')");
       }
       $this->db->HAVING('distance<'.$max_distance);
       $this->db->order_by('distance');
       $query = $this->db->get();
       $data = $query->result_array();
       return $data;
    }

}
