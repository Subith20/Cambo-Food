<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Shops_model extends CI_Model {

    public function __construct() {
        parent::__construct();

        // Load the database library
        $this->load->database();
        $this->load->model('Settings_model');
    }

    function shop_payment_mode($shop_id)
    {
       $this->db->select('*');
       $this->db->from('shop_payment_mode A');
       $this->db->where('A.shop_id = '.$shop_id.' or A.shop_id =0');
       $query = $this->db->get();
       $data = $query->result_array();
       return $data;
    }

    function getAvailableShops($lat,$long)
    {
      $base_url=$this->config->item('base_url');
      $max_distance=$this->Settings_model->maximum_shipping_distance();
      $max_distance=$max_distance['distance'];

      $query="A.id,A.name,A.description,A.is_available,A.discount_percentage,A.address,A.type,A.avail_time,A.is_time_sheet, B.name as type_name, CONCAT('".$base_url."',C.file_name) AS img, ROUND(SQRT( POW(69.1 * (A.latitude - ".$lat."), 2) + POW(69.1 * (".$long." - A.longitude) * COS(A.latitude / 57.3), 2)),2) AS distance";

       $this->db->select($query);
       $this->db->from('shops A');
       $this->db->join('product_type B', 'B.id = A.type', 'left');
       $this->db->join('media C', "C.related_id = A.id and C.model_type='shop'", 'left');
       $this->db->where('A.is_deleted',0);
       $this->db->where('A.is_available',1);
       
       $this->db->HAVING('distance<'.$max_distance);
       $this->db->order_by('distance');
       $query = $this->db->get();
       $data = $query->result_array();
       return $data;
    }

    function getAllNearShops($lat,$long,$group_type)
    {
      $distance_unit= $this->config->item('distance_unit');
      $base_url=$this->config->item('base_url');
      $max_distance=$this->Settings_model->maximum_shipping_distance();
      $max_distance=$max_distance['distance'];

      if($distance_unit=='Km')
      {
        $query="A.id,A.name,A.description,A.is_available,A.discount_percentage,A.address,A.type,A.type_name,A.avail_time,A.is_time_sheet, CONCAT('".$base_url."',C.file_name) AS img, ROUND((SQRT( POW(69.1 * (A.latitude - ".$lat."), 2) + POW(69.1 * (".$long." - A.longitude) * COS(A.latitude / 57.3), 2))*1.609344),2) AS distance";
      }
      else {
        $query="A.id,A.name,A.description,A.is_available,A.discount_percentage,A.address,A.type,A.type_name,A.avail_time,A.is_time_sheet, CONCAT('".$base_url."',C.file_name) AS img, ROUND(SQRT( POW(69.1 * (A.latitude - ".$lat."), 2) + POW(69.1 * (".$long." - A.longitude) * COS(A.latitude / 57.3), 2)),2) AS distance";
      }
      

       $this->db->select($query);
       $this->db->from('shops A');
       $this->db->join('media C', "C.related_id = A.id and C.model_type='shop'", 'left');
       $this->db->where('A.is_deleted',0);
       $this->db->like("A.type_group_name",$group_type);
       $this->db->HAVING('distance<'.$max_distance);
       $this->db->order_by('distance');
       $query = $this->db->get();
       //echo $this->db->last_query();exit;
       $data = $query->result_array();
       return $data;
    }

    function getSearchNearShops($lat,$long,$search_input=null)
    {
      $base_url=$this->config->item('base_url');
      $max_distance=$this->Settings_model->maximum_shipping_distance();
      $max_distance=$max_distance['distance'];

      $query="A.id,A.name,A.description,A.is_available,A.discount_percentage,A.address,A.type,A.type_name,A.avail_time,A.is_time_sheet, CONCAT('".$base_url."',C.file_name) AS img, ROUND(SQRT( POW(69.1 * (A.latitude - ".$lat."), 2) + POW(69.1 * (".$long." - A.longitude) * COS(A.latitude / 57.3), 2)),2) AS distance";

       $this->db->select($query);
       $this->db->from('shops A');
       $this->db->join('media C', "C.related_id = A.id and C.model_type='shop'", 'left');
       $this->db->where('A.is_deleted',0);
       if($search_input)
       {
         //$this->db->like("A.name",$search_input);
        // $this->db->like("A.type_name",$search_input);
         $this->db->where("(A.name LIKE '%".$search_input."%' or A.type_name LIKE '%".$search_input."%' or A.type_group_name LIKE '%".$search_input."%')");
       }
       $this->db->HAVING('distance<'.$max_distance);
       $this->db->order_by('distance');
       $query = $this->db->get();
       //echo $this->db->last_query();
       $data = $query->result_array();
       return $data;
    }

    function checkOwnerPermission($user_id,$shop_id)
    {
      $this->db->select('A.id');
       $this->db->from('shops A');
       $this->db->where('A.user_id',$user_id);
       $this->db->where('A.id',$shop_id);
       $query = $this->db->get();
       $data = $query->row_array();
       //echo $this->db->last_query();
       return $data['id']?true:false;
    }

    function ShopDriverList($shop_id)
    {
       $this->db->select('*');
       $this->db->from('shop_driver');
       $this->db->where('shop_id',$shop_id);
       $query = $this->db->get();
       $data = $query->result_array();
       return $data;
    }

    function ShopActiveDriverOrderList($shop_id)
    {
       $this->db->select('B.id,B.first_name as driver_name,B.is_shop_driver, count(C.id) as order_count');
       $this->db->from('shop_driver A');
       $this->db->join('users B', 'B.id = A.user_id', 'inner');
       $this->db->join('orders C', 'C.driver_id = B.id', 'left');
       $this->db->where('A.shop_id',$shop_id);
       $this->db->where('B.status',1);
       $this->db->group_by('A.id');
       $this->db->order_by('count(C.id)');
       $query = $this->db->get();
       //echo $this->db->last_query();
       $data = $query->result_array();
       return $data;
    }

    function removeShopDrivers($shop_id)
    {
        $delete = $this->db->delete('shop_driver',array('shop_id'=>$shop_id));
        //return the status
        return $delete?true:false;
    }

    function insert_shop_driver($request)
    {
      $insert = $this->db->insert_batch('shop_driver', $request);
       //return the status
       return $insert?$this->db->insert_id():false;

    }

     function GetShopsDatatable()
     {
       $this->db->select('A.id,A.name,A.phone,A.mobile,A.is_available,A.discount_percentage,A.type,A.commission,A.type_name');
       $this->db->from('shops A');
       $this->db->where('is_deleted',0);
       $query = $this->db->get();
       $data = $query->result_array();
       return $data;

     }

     function GetShopsList()
     {
       $this->db->select('*');
       $this->db->from('shops');
       $this->db->where('is_deleted',0);
       $query = $this->db->get();
       $data = $query->result_array();
       return $data;
     }

     function GetShopsTypeList()
     {
       $this->db->select('*');
       $this->db->from('shop_type');
       $this->db->where('is_deleted',0);
       $query = $this->db->get();
       $data = $query->result_array();
       return $data;
     }

     function GetShopsTypeDetails($id_list=null)
     {
       if($id_list)
       {
         $result['type_id']=$id_list;
         $id_list=array_map('intval', explode(',', $id_list));
         $id_list = implode("','",$id_list);
         $this->db->select('*');
         $this->db->from('shop_type');
         $this->db->where('is_deleted',0);
         $this->db->where("id IN ('".$id_list."')");
         $query = $this->db->get();
         $data = $query->result_array();
         //$data=array_map('reset',$data);
         //return implode(' | ', $data);
         foreach ($data as $value) {
           $result_name[]=$value['name'];
           $result_gname[$value['group_id']]=$value['group_name'];
           $result_gid[$value['group_id']]=$value['group_id'];
         }

         $result['type_name']=implode(' | ', $result_name);
         
         $result['type_group_name']=implode(' | ', $result_gname);
         $result['type_group_id']=implode(',', $result_gid);
         
         return $result;
       }
       else {
         return '';
       }
       
       
     }

     function GetShopsSelectList($request=null)
     {
       $this->db->select('id,name,phone');
       $this->db->from('shops');
       if($request['user_id'])
       {
         $this->db->where('user_id',$request['user_id']);
       }
       $this->db->where('is_deleted',0);
       $query = $this->db->get();
       $data = $query->result_array();
       return $data;
     }


     function GetRestDetails($id)
     {
        $base_url=$this->config->item('base_url');
      

       $this->db->select("A.id,A.name,A.description,A.discount_percentage,A.address,A.phone,A.mobile,A.is_available,A.type, A.type_name, A.latitude,A.longitude, CONCAT('".$base_url."',C.file_name) AS img");
       $this->db->from('shops A');
       $this->db->join('media C', "C.related_id = A.id and C.model_type='shop'", 'left');
       $this->db->where('A.is_deleted',0);
       $this->db->where('A.id',$id);
       $query = $this->db->get();
       $data = $query->row_array();
       return $data;
     }

     function GetDetails($id)
     {
      $base_url=$this->config->item('base_url');
       $this->db->select("A.*,CONCAT('".$base_url."',C.file_name) AS img");
       $this->db->from('shops A');
       $this->db->join('media C', "C.related_id = A.id and C.model_type='shop'", 'left');
       $this->db->where('A.id',$id);
       $query = $this->db->get();
       //echo $this->db->last_query();exit;
       $data = $query->row_array();
       return $data;
     }

     function myShopList($user_id)
     {
       $base_url=$this->config->item('base_url');
       $this->db->select("A.*,CONCAT('".$base_url."',C.file_name) AS img, B.name as type_name");
       $this->db->from('shops A');
       $this->db->join('product_type B', 'B.id = A.type', 'left');
       $this->db->join('media C', "C.related_id = A.id and C.model_type='shop'", 'left');
       $this->db->where('user_id',$user_id);
       $this->db->where('is_deleted',0);
       $query = $this->db->get();
       $data = $query->result_array();
       return $data;
     }


     public function new($request)
     {

       $insert = $this->db->insert('shops', $request);
       //return the status
       return $insert?$this->db->insert_id():false;
     }


    public function update($data, $id){

     //echo "<pre>".$id;print_r($data);exit;

        $update = $this->db->update('shops', $data, array('id'=>$id));
        //echo $this->db->last_query();exit;
        //return the status
        return $update?true:false;

    }

    public function myShopStatusUpdate($id, $user_id, $status){
        $update = $this->db->update('shops', array('is_available'=>$status), array('id'=>$id,'user_id'=>$user_id));
       // echo $this->db->last_query();exit;
        return $update?true:false;

    }


    public function delete($id){

        $delete = $this->db->delete('shops',array('id'=>$id));
        //return the status
        return $delete?true:false;
    }


    function getActiveListCount()
    {

       $this->db->select('count(id) as count');
       $this->db->from('shops');
       $this->db->where('is_avail',1);
       $query = $this->db->get();
       $result = $query->row_array();

       return $result;
    }

    function getProductsShopDetails($product_id)
    {
      $this->db->select('A.*');
      $this->db->from('shops A');
      $this->db->join('products B', "B.shop_id = A.id", 'inner');
      $this->db->where('B.id',$product_id);
      $query = $this->db->get();
      $data = $query->row_array();
      return $data;
    }

}
