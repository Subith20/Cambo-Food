<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Generic_model extends CI_Model {

    public function __construct() {
        parent::__construct();

        // Load the database library
        $this->load->database();

        //$this->userTbl = 'users';
    }



/*
    public function new($data){
        //insert user data to users table
        $insert = $this->db->insert('vendor', $data);
        //return the status
        return $insert?$this->db->insert_id():false;
    }

    public function update($data){

        //insert user data to users table
        $vendor_id=$data['id'];
        unset($data['id']);
        //update user data in users table
        $update = $this->db->update('vendor', $data, array('id'=>$vendor_id));

        //return the status
        return $update?true:false;
    }

    public function new_owner($data){
        //insert user data to users table
        $insert = $this->db->insert('vendor_owner', $data);
        //return the status
        return $insert?$this->db->insert_id():false;
    }

    public function new_bank($data){
        //insert user data to users table
        $insert = $this->db->insert('vendor_bank', $data);
        //return the status
        return $insert?$this->db->insert_id():false;
    }

    function GetVendorDetails($id)
    {
      $this->db->select('A.*,C.ifc,C.ac,C.name account_name,C.bank_name,C.branch,C.ac_type as bank_ac_type');
      $this->db->order_by('A.id');
      $this->db->join('vendor_bank C', 'C.vendor_id = A.id', 'left');
      $this->db->from('vendor A');
      $this->db->where('A.id',$id);
      $query = $this->db->get();
      $data = $query->row_array();
      $data['service_type']=explode(',',$data['service_type']);
      return $data;
    }

    function GetVendorList()
    {
      $this->db->select('A.*,B.id as owner_id,B.name as owner_name,C.id as bank_id,C.ifc,C.ac,C.name account_name,C.bank_name,C.branch,D.first_name as create_by');
      $this->db->order_by('A.id');
      $this->db->join('vendor_owner B', 'B.id = A.owner_id', 'inner');
      $this->db->join('vendor_bank C', 'C.vendor_id = A.id', 'left');
      $this->db->join('users D', 'D.id = A.create_by', 'inner');
      $this->db->from('vendor A');
      $query = $this->db->get();
      $data = $query->result_array();
      return $data;
    }*/

    function citylist($avail=null)
    {
      $this->db->select('id,name,district');
      $this->db->order_by('district');
      $this->db->order_by('name');


      if($avail)
      {
        $this->db->where('is_avail',1);
      }
      $this->db->from('city');
      $query = $this->db->get();
      $data = $query->result_array();
      foreach ($data as $key => $value) {
        $result[$value['id']]=$value;
      }
      return $result;
    }

    function UploadFilesList($ModelType,$RelatedId)
    {
      $base_url=$this->config->item('base_url');
      $this->db->select('*');
      $this->db->where('model_type',$ModelType);
      $this->db->where('related_id',$RelatedId);
      $this->db->from('media');
      $query = $this->db->get();
      $data = $query->result_array();
      foreach ($data as $key => $value) {
        $value['file_name']=$base_url.$value['file_name'];
        $result[]=$value;
      }
      return $result;
    }

    function UploadFilesList_for_delete($ModelType,$RelatedId)
    {
      $base_url=$this->config->item('base_url');
      $this->db->select('*');
      $this->db->where('model_type',$ModelType);
      $this->db->where('related_id',$RelatedId);
      $this->db->from('media');
      $query = $this->db->get();
      $data = $query->result_array();
      return $data;
    }

    function menu_list($user_type)
    {
      $this->db->select('*');
      //$this->db->order_by('menu_index');
      $this->db->where('status',1);
      $this->db->where('is_menu',1);
      $this->db->where("FIND_IN_SET('$user_type', cast(can_view as char)) > 0");
      $this->db->from('access_controll');
      $query = $this->db->get();
      $data = $query->result_array();
      foreach ($data as $key => $value) {
        //$type_access_list=explode(',',$value['can_view'])
        if($value['master_id']==0)
        {
          foreach ($data as $key1 => $value1) {
            if($value['id']==$value1['master_id'])
            {
              $value['sub_menu'][]=$value1;
            }

          }

          $result[$value['id']]=$value;
        }

      }
      return $result;
    }

    public function fileUploaderInsert($data){
        //insert user data to users table
        $insert = $this->db->insert('media', $data);
        //return the status
        return $insert?$this->db->insert_id():false;
    }

    public function RemoveUploadFiles($id)
    {
      $delete = $this->db->delete('media',array('id'=>$id));
      return $delete?true:false;
    }
}
